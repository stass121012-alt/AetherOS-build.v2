# Сервис уведомлений создаётся системой по имени из манифеста.
-keep class com.aether.os.system.AetherNotificationListener { *; }
# ViewModel создаётся через рефлексию (AndroidViewModel с Application).
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel {
    <init>(android.app.Application);
}
