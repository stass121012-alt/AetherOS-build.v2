package com.aether.os.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppInfo
import com.aether.os.data.BuiltinApps
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import java.util.Locale

/**
 * Диспетчер приложений оболочки: все приложения, скрытие, док, сведения и удаление.
 * Удаление выполняет сама система после вашего подтверждения.
 */
@Composable
fun AppManagerApp(state: HomeState, actions: HomeActions, onClose: () -> Unit) {
    val p = LocalAetherPalette.current
    var query by rememberSaveable { mutableStateOf("") }
    var expandedPkg by rememberSaveable { mutableStateOf<String?>(null) }

    val hiddenSet = remember(state.hidden) { state.hidden.map { it.packageName }.toSet() }
    val dockSet = remember(state.dock) { state.dock.map { it.packageName }.toSet() }
    val q = query.trim().lowercase(Locale.getDefault())
    val apps = remember(state.all, q) {
        state.all
            .filter { q.isEmpty() || it.label.lowercase(Locale.getDefault()).contains(q) }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    AppFrame(title = "Диспетчер приложений", onClose = onClose) {
        Text(
            "Всего ${state.all.size} · скрыто ${hiddenSet.size} · в доке ${dockSet.size}",
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
        )
        Row(
            Modifier.fillMaxWidth().aetherGlass(RoundedCornerShape(16.dp)).padding(horizontal = 14.dp),
        ) {
            BasicTextField(
                value = query,
                onValueChange = { query = it.take(40) },
                singleLine = true,
                textStyle = AetherType.body.copy(color = p.textPrimary),
                cursorBrush = SolidColor(p.accent),
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) {
                            Text("Фильтр по названию", style = AetherType.body, color = p.textSecondary)
                        }
                        inner()
                    }
                },
            )
        }
        LazyColumn(
            Modifier.fillMaxSize().padding(top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(apps, key = { it.packageName }) { app ->
                ManagerRow(
                    app = app,
                    hidden = app.packageName in hiddenSet,
                    inDock = app.packageName in dockSet,
                    dockFull = dockSet.size >= AetherDimens.dockSize,
                    expanded = expandedPkg == app.packageName,
                    actions = actions,
                    onToggle = {
                        expandedPkg = if (expandedPkg == app.packageName) null else app.packageName
                    },
                )
            }
        }
    }
}

@Composable
private fun ManagerRow(
    app: AppInfo,
    hidden: Boolean,
    inDock: Boolean,
    dockFull: Boolean,
    expanded: Boolean,
    actions: HomeActions,
    onToggle: () -> Unit,
) {
    val p = LocalAetherPalette.current
    val builtin = BuiltinApps.isBuiltin(app.packageName)
    val tags = buildList {
        if (builtin) add("встроенное")
        if (hidden) add("скрыто")
        if (inDock) add("в доке")
    }.joinToString(" · ")

    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .clickable(onClick = onToggle)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(app.label, style = AetherType.body, color = p.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (tags.isEmpty()) app.packageName else "$tags · ${app.packageName}",
                    style = AetherType.caption,
                    color = p.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (expanded) {
            val pkg = app.packageName
            val buttons = buildList<Pair<String, () -> Unit>> {
                if (hidden) add("Показать" to { actions.onUnhide(pkg) }) else add("Скрыть" to { actions.onHide(pkg) })
                if (inDock) {
                    add("Убрать из дока" to { actions.onToggleDock(pkg) })
                } else if (!dockFull && !hidden) {
                    add("В док" to { actions.onToggleDock(pkg) })
                }
                if (!builtin) {
                    add("О приложении" to { actions.onAppInfo(pkg) })
                    add("Удалить" to { actions.onUninstall(pkg) })
                }
            }
            Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                buttons.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { (label, action) -> Chip(label, action) }
                    }
                }
                if (builtin) {
                    Text("Встроенное приложение AETHER: удалить нельзя.", style = AetherType.caption, color = p.textSecondary)
                }
            }
        }
    }
}
