package com.aether.os.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aether.os.data.CalEvent
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields
import java.util.Locale
import java.time.format.TextStyle as DateTextStyle

private fun minuteLabel(minuteOfDay: Int) = "%02d:%02d".format(minuteOfDay / 60, minuteOfDay % 60)

/**
 * Встроенный календарь AETHER: собственные события хранятся только на устройстве.
 * С системным календарём не синхронизируется (чтение его данных требует разрешения, которое не запрашивается).
 */
@Composable
fun CalendarApp(events: List<CalEvent>, actions: HomeActions, onClose: () -> Unit) {
    val p = LocalAetherPalette.current
    val locale = Locale.getDefault()
    var editing by rememberSaveable { mutableStateOf(false) }
    var editId by rememberSaveable { mutableStateOf<Long?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var allDay by rememberSaveable { mutableStateOf(true) }
    var hour by rememberSaveable { mutableStateOf(9) }
    var minute by rememberSaveable { mutableStateOf(0) }
    var monthOffset by rememberSaveable { mutableStateOf(0) }
    var selectedDay by rememberSaveable { mutableStateOf(LocalDate.now().toEpochDay()) }

    BackHandler(enabled = true) { if (editing) editing = false else onClose() }

    val selectedDate = LocalDate.ofEpochDay(selectedDay)
    val dateLabel = remember(selectedDay) {
        selectedDate.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", locale))
            .replaceFirstChar { it.titlecase(locale) }
    }

    if (editing) {
        EventEditor(
            dateLabel = dateLabel,
            title = title,
            onTitle = { title = it.take(80) },
            allDay = allDay,
            onAllDay = { allDay = it },
            hour = hour,
            minute = minute,
            onHour = { hour = (it + 24) % 24 },
            onMinute = { minute = (it + 60) % 60 },
            canDelete = editId != null,
            onSave = {
                if (title.isNotBlank()) {
                    actions.onSaveEvent(
                        CalEvent(
                            id = editId ?: System.currentTimeMillis(),
                            epochDay = selectedDay,
                            minuteOfDay = if (allDay) -1 else hour * 60 + minute,
                            title = title.trim(),
                        )
                    )
                }
                editing = false
            },
            onCancel = { editing = false },
            onDelete = {
                editId?.let(actions.onDeleteEvent)
                editing = false
            },
        )
        return
    }

    val month = remember(monthOffset) { YearMonth.now().plusMonths(monthOffset.toLong()) }
    val monthTitle = month.month.getDisplayName(DateTextStyle.FULL_STANDALONE, locale)
        .replaceFirstChar { it.titlecase(locale) } + " " + month.year
    val eventDays = remember(events) { events.map { it.epochDay }.toSet() }
    val dayEvents = remember(events, selectedDay) {
        events.filter { it.epochDay == selectedDay }.sortedBy { it.minuteOfDay }
    }

    AppFrame(
        title = "Календарь",
        onClose = onClose,
        trailing = {
            Chip("Сегодня") {
                monthOffset = 0
                selectedDay = LocalDate.now().toEpochDay()
            }
        },
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "‹",
                style = AetherType.title,
                color = p.textPrimary,
                modifier = Modifier.clickable { monthOffset -= 1 }.padding(horizontal = 16.dp),
            )
            Text(monthTitle, style = AetherType.body, color = p.textPrimary)
            Text(
                "›",
                style = AetherType.title,
                color = p.textPrimary,
                modifier = Modifier.clickable { monthOffset += 1 }.padding(horizontal = 16.dp),
            )
        }
        MonthGrid(month, selectedDay, eventDays) { date -> selectedDay = date.toEpochDay() }

        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                dateLabel,
                style = AetherType.body,
                color = p.textPrimary,
                modifier = Modifier.weight(1f).padding(end = 8.dp),
            )
            Chip("+ Событие") {
                editId = null
                title = ""
                allDay = true
                hour = 9
                minute = 0
                editing = true
            }
        }

        if (dayEvents.isEmpty()) {
            Text("На этот день событий нет.", style = AetherType.caption, color = p.textSecondary)
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(dayEvents, key = { it.id }) { e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
                        .clickable {
                            editId = e.id
                            title = e.title
                            allDay = e.allDay
                            hour = if (e.allDay) 9 else e.minuteOfDay / 60
                            minute = if (e.allDay) 0 else e.minuteOfDay % 60
                            editing = true
                        }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (e.allDay) "Весь день" else minuteLabel(e.minuteOfDay),
                        style = AetherType.caption,
                        color = p.accent,
                        modifier = Modifier.width(88.dp),
                    )
                    Text(e.title, style = AetherType.body, color = p.textPrimary, maxLines = 2)
                }
            }
        }
        Text(
            "События хранятся только в AETHER и не синхронизируются с системным календарём.",
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    selectedDay: Long,
    eventDays: Set<Long>,
    onSelect: (LocalDate) -> Unit,
) {
    val p = LocalAetherPalette.current
    val locale = Locale.getDefault()
    val firstDow: DayOfWeek = remember { WeekFields.of(locale).firstDayOfWeek }
    val lead = (month.atDay(1).dayOfWeek.value - firstDow.value + 7) % 7
    val days = month.lengthOfMonth()
    val rows = (lead + days + 6) / 7
    val today = LocalDate.now()

    Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
        repeat(7) { i ->
            Text(
                firstDow.plus(i.toLong()).getDisplayName(DateTextStyle.NARROW, locale),
                style = AetherType.caption,
                color = p.textSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f),
            )
        }
    }
    repeat(rows) { r ->
        Row(Modifier.fillMaxWidth()) {
            repeat(7) { c ->
                val day = r * 7 + c - lead + 1
                if (day in 1..days) {
                    val date = month.atDay(day)
                    val epoch = date.toEpochDay()
                    val selected = epoch == selectedDay
                    Box(
                        Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .padding(2.dp)
                            .clip(CircleShape)
                            .background(if (selected) p.accent.copy(alpha = 0.45f) else Color.Transparent)
                            .clickable { onSelect(date) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                day.toString(),
                                style = AetherType.caption,
                                color = if (date == today) p.accent else p.textPrimary,
                            )
                            Box(
                                Modifier
                                    .size(4.dp)
                                    .background(
                                        if (epoch in eventDays) p.accent else Color.Transparent,
                                        CircleShape,
                                    )
                            )
                        }
                    }
                } else {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun EventEditor(
    dateLabel: String,
    title: String,
    onTitle: (String) -> Unit,
    allDay: Boolean,
    onAllDay: (Boolean) -> Unit,
    hour: Int,
    minute: Int,
    onHour: (Int) -> Unit,
    onMinute: (Int) -> Unit,
    canDelete: Boolean,
    onSave: () -> Unit,
    onCancel: () -> Unit,
    onDelete: () -> Unit,
) {
    val p = LocalAetherPalette.current
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    AppFrame(
        title = "Событие",
        closeLabel = "Сохранить",
        onClose = onSave,
        trailing = {
            Chip("Отмена", onCancel)
            if (canDelete) {
                Spacer(Modifier.size(8.dp))
                Chip("Удалить", onDelete)
            }
        },
    ) {
        Column(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(dateLabel, style = AetherType.caption, color = p.textSecondary)
            Row(
                Modifier
                    .fillMaxWidth()
                    .aetherGlass(RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp)
            ) {
                BasicTextField(
                    value = title,
                    onValueChange = onTitle,
                    singleLine = true,
                    textStyle = AetherType.body.copy(color = p.textPrimary),
                    cursorBrush = SolidColor(p.accent),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp).focusRequester(focus),
                    decorationBox = { inner ->
                        Box {
                            if (title.isEmpty()) {
                                Text("Название события", style = AetherType.body, color = p.textSecondary)
                            }
                            inner()
                        }
                    },
                )
            }
            SwitchRow(
                title = "Весь день",
                subtitle = "Без конкретного времени",
                checked = allDay,
                onChange = onAllDay,
            )
            if (!allDay) {
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    Stepper("Часы", "%02d".format(hour), { onHour(hour - 1) }, { onHour(hour + 1) })
                    Stepper("Минуты", "%02d".format(minute), { onMinute(minute - 5) }, { onMinute(minute + 5) })
                }
            }
        }
    }
}

/** Простой счётчик «− значение +». */
@Composable
internal fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    val p = LocalAetherPalette.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = AetherType.caption, color = p.textSecondary)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip("−", onMinus)
            Text(value, style = AetherType.title, color = p.textPrimary)
            Chip("+", onPlus)
        }
        Spacer(Modifier.height(2.dp))
    }
}
