package com.aether.os.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppInfo
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass

/** AETHER Search: приложения (включая скрытые и лежащие в папках) и настройки оболочки. */
@Composable
fun SearchScreen(
    all: List<AppInfo>,
    hiddenPackages: Set<String>,
    onLaunch: (AppInfo) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenPersonalization: () -> Unit,
    onOpenControl: () -> Unit,
    onOpenNotifications: () -> Unit,
    onClose: () -> Unit,
) {
    val p = LocalAetherPalette.current
    var query by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val backdropSource = remember { MutableInteractionSource() }

    LaunchedEffect(Unit) {
        focus.requestFocus()
        keyboard?.show()
    }

    val appResults = remember(query, all) { matchApps(query, all) }
    val settingResults = remember(query) { matchSettings(query) }

    Box(
        Modifier
            .fillMaxSize()
            .background(p.panel)
            .clickable(interactionSource = backdropSource, indication = null, onClick = onClose)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .aetherGlass(RoundedCornerShape(22.dp))
                    .padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = AetherType.body.copy(color = p.textPrimary),
                    cursorBrush = SolidColor(p.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = { appResults.firstOrNull()?.let(onLaunch) }
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 14.dp)
                        .focusRequester(focus),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) {
                                Text(
                                    "Приложения и настройки",
                                    style = AetherType.body,
                                    color = p.textSecondary,
                                )
                            }
                            inner()
                        }
                    },
                )
                TextButton(onClick = onClose) { Text("Отмена", color = p.accent) }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (query.isBlank()) {
                    item {
                        Text(
                            "Введите название приложения или настройки. Enter запускает первое приложение.",
                            style = AetherType.caption,
                            color = p.textSecondary,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                } else if (appResults.isEmpty() && settingResults.isEmpty()) {
                    item {
                        Text(
                            "Ничего не найдено",
                            style = AetherType.caption,
                            color = p.textSecondary,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                }

                if (appResults.isNotEmpty()) {
                    item { SectionTitle("ПРИЛОЖЕНИЯ") }
                    items(appResults, key = { it.packageName }) { app ->
                        AppResultRow(
                            app = app,
                            hidden = app.packageName in hiddenPackages,
                            onClick = { onLaunch(app) },
                        )
                    }
                }
                if (settingResults.isNotEmpty()) {
                    item { SectionTitle("НАСТРОЙКИ") }
                    items(settingResults, key = { it.title }) { entry ->
                        ActionRow(
                            title = entry.title,
                            subtitle = entry.subtitle,
                            onClick = {
                                when (entry.target) {
                                    SettingsTarget.SETTINGS -> onOpenSettings()
                                    SettingsTarget.PERSONALIZATION -> onOpenPersonalization()
                                    SettingsTarget.CONTROL -> onOpenControl()
                                    SettingsTarget.NOTIFICATIONS -> onOpenNotifications()
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppResultRow(app: AppInfo, hidden: Boolean, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(40.dp))
        Text(
            app.label,
            style = AetherType.body,
            color = p.textPrimary,
            maxLines = 1,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
        )
        if (hidden) {
            Text("Скрыто", style = AetherType.caption, color = p.textSecondary)
        }
    }
}
