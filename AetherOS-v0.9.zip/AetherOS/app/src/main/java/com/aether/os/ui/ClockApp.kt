package com.aether.os.ui

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.os.data.DefaultWorldZones
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.design.rememberNow
import com.aether.os.system.SystemTarget
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

private val WorldZonePresets = listOf(
    "Europe/Moscow" to "Москва",
    "Europe/London" to "Лондон",
    "Europe/Berlin" to "Берлин",
    "America/New_York" to "Нью-Йорк",
    "America/Los_Angeles" to "Лос-Анджелес",
    "Asia/Dubai" to "Дубай",
    "Asia/Kolkata" to "Дели",
    "Asia/Shanghai" to "Пекин",
    "Asia/Tokyo" to "Токио",
    "Australia/Sydney" to "Сидней",
)

private enum class ClockTab { WORLD, STOPWATCH, TIMER }

private val TimerPresets = listOf(1, 5, 10, 15, 30, 60)

private fun formatStopwatch(ms: Long): String {
    val minutes = ms / 60_000
    val seconds = (ms / 1000) % 60
    val centis = (ms % 1000) / 10
    return "%02d:%02d.%02d".format(minutes, seconds, centis)
}

private fun formatCountdown(ms: Long): String {
    val total = (ms + 999L) / 1000L
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

private fun utcLabel(seconds: Int): String {
    val sign = if (seconds < 0) "-" else "+"
    val abs = kotlin.math.abs(seconds)
    val h = abs / 3600
    val m = (abs % 3600) / 60
    return if (m == 0) "UTC$sign$h" else "UTC$sign$h:%02d".format(m)
}

/**
 * Встроенные «Часы»: мировое время, секундомер, таймер.
 * Будильники — системные (кнопка внизу): надёжный будильник требует прав, которые AETHER не запрашивает.
 * Секундомер работает, пока открыт этот экран.
 */
@Composable
fun ClockApp(
    zones: List<String>,
    timer: TimerState,
    actions: HomeActions,
    onClose: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(ClockTab.WORLD) }

    AppFrame(title = "Часы", onClose = onClose) {
        Spacer(Modifier.height(8.dp))
        SegmentedRow(
            options = listOf(
                ClockTab.WORLD to "Мир",
                ClockTab.STOPWATCH to "Секундомер",
                ClockTab.TIMER to "Таймер",
            ),
            selected = tab,
            onSelect = { tab = it },
        )
        Spacer(Modifier.height(12.dp))
        Column(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                ClockTab.WORLD -> WorldTab(zones, actions)
                ClockTab.STOPWATCH -> StopwatchTab()
                ClockTab.TIMER -> TimerTab(timer, actions)
            }
        }
        ActionRow(
            title = "Будильники",
            subtitle = "Откроются системные будильники — они надёжно сработают в любой момент",
            onClick = { actions.onOpenSystem(SystemTarget.ALARMS) },
        )
    }
}

@Composable
private fun WorldTab(zones: List<String>, actions: HomeActions) {
    val p = LocalAetherPalette.current
    val now by rememberNow()   // обновляется раз в минуту
    val formatter = remember { DateTimeFormatter.ofPattern("HH:mm") }
    val localZone = ZoneId.systemDefault()
    val current = remember(now) { ZonedDateTime.now(localZone) }

    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ZoneRow("Здесь", current.format(formatter), utcLabel(current.offset.totalSeconds))
        zones.forEach { id ->
            val zone = runCatching { ZoneId.of(id) }.getOrNull() ?: return@forEach
            val time = remember(now, id) { ZonedDateTime.now(zone) }
            val diff = ChronoUnit.DAYS.between(current.toLocalDate(), time.toLocalDate())
            val day = when {
                diff > 0 -> "завтра"
                diff < 0 -> "вчера"
                else -> "сегодня"
            }
            val label = WorldZonePresets.firstOrNull { it.first == id }?.second ?: id
            ZoneRow(label, time.format(formatter), "$day · ${utcLabel(time.offset.totalSeconds)}")
        }

        Text("ГОРОДА", style = AetherType.section, color = p.accent, modifier = Modifier.padding(top = 8.dp))
        WorldZonePresets.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { (id, label) ->
                    ToggleChip(label, selected = id in zones) {
                        val next = if (id in zones) zones - id else zones + id
                        actions.onSetWorldZones(next)
                    }
                }
            }
        }
        if (zones != DefaultWorldZones) {
            Chip("Сбросить список") { actions.onSetWorldZones(DefaultWorldZones) }
        }
    }
}

@Composable
private fun ZoneRow(label: String, time: String, note: String) {
    val p = LocalAetherPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = AetherType.body, color = p.textPrimary)
            Text(note, style = AetherType.caption, color = p.textSecondary)
        }
        Text(time, style = AetherType.title, color = p.textPrimary)
    }
}

@Composable
internal fun ToggleChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    Text(
        text,
        style = AetherType.caption,
        color = p.textPrimary,
        modifier = Modifier
            .aetherGlass(RoundedCornerShape(14.dp))
            .background(if (selected) p.accent.copy(alpha = 0.30f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun StopwatchTab() {
    val p = LocalAetherPalette.current
    var running by remember { mutableStateOf(false) }
    var base by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var laps by remember { mutableStateOf(listOf<Long>()) }
    val tick by produceState(initialValue = 0L, running) {
        while (running) {
            value = SystemClock.elapsedRealtime()
            delay(33)
        }
    }
    val elapsed = base + if (running) (tick.coerceAtLeast(startedAt) - startedAt) else 0L

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            formatStopwatch(elapsed),
            style = AetherType.clock.copy(fontSize = 56.sp),
            color = p.textPrimary,
            modifier = Modifier.padding(vertical = 16.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Chip(if (running) "Стоп" else "Старт") {
                if (running) {
                    base = elapsed
                    running = false
                } else {
                    startedAt = SystemClock.elapsedRealtime()
                    running = true
                }
            }
            Chip(if (running) "Круг" else "Сброс") {
                if (running) {
                    laps = listOf(elapsed) + laps
                } else {
                    base = 0L
                    laps = emptyList()
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false)) {
            itemsIndexed(laps) { index, lap ->
                val number = laps.size - index
                val previous = laps.getOrNull(index + 1) ?: 0L
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("Круг $number", style = AetherType.caption, color = p.textSecondary)
                    Text("+${formatStopwatch(lap - previous)}", style = AetherType.caption, color = p.textPrimary)
                    Text(formatStopwatch(lap), style = AetherType.caption, color = p.textPrimary)
                }
            }
        }
    }
}

@Composable
private fun TimerTab(timer: TimerState, actions: HomeActions) {
    val p = LocalAetherPalette.current
    var customMinutes by rememberSaveable { mutableStateOf(15) }
    val endAt = timer.endAt

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        if (endAt != null) {
            val now by produceState(initialValue = System.currentTimeMillis(), endAt) {
                while (value < endAt) {
                    delay(250)
                    value = System.currentTimeMillis()
                }
            }
            val remaining = (endAt - now).coerceAtLeast(0L)
            Text(
                if (remaining == 0L) "Время вышло" else formatCountdown(remaining),
                style = AetherType.clock.copy(fontSize = 56.sp),
                color = p.textPrimary,
                modifier = Modifier.padding(vertical = 16.dp),
            )
            Chip(if (remaining == 0L) "Закрыть" else "Отменить") { actions.onCancelTimer() }
        } else {
            Text("Быстрый запуск", style = AetherType.section, color = p.accent, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
            TimerPresets.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                    row.forEach { m -> Chip("$m мин") { actions.onStartTimer(m) } }
                }
            }
            Spacer(Modifier.height(12.dp))
            Stepper(
                label = "Своё время, минут",
                value = customMinutes.toString(),
                onMinus = { customMinutes = (customMinutes - 1).coerceAtLeast(1) },
                onPlus = { customMinutes = (customMinutes + 1).coerceAtMost(180) },
            )
            Spacer(Modifier.height(8.dp))
            Chip("Запустить $customMinutes мин") { actions.onStartTimer(customMinutes) }
        }
        Text(
            "Остров вверху экрана показывает таймер. Сигнал сработает, пока AETHER запущен; " +
                "для надёжного будильника используйте системные будильники.",
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.padding(top = 16.dp),
        )
    }
}
