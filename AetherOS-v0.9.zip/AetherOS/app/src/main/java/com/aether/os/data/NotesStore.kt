package com.aether.os.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.notesDataStore by preferencesDataStore(name = "aether_notes")

/** Заметка приложения «Заметки». Первая строка текста служит заголовком. */
data class Note(val id: Long, val text: String, val updatedAt: Long)

/** Локальное хранилище заметок (JSON в DataStore). Данные не покидают устройство. */
class NotesStore(private val context: Context) {

    private val kNotes = stringPreferencesKey("notes_json")

    val notes: Flow<List<Note>> = context.notesDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p -> p[kNotes]?.let(::decode) ?: emptyList() }

    suspend fun save(list: List<Note>) {
        context.notesDataStore.edit { it[kNotes] = encode(list) }
    }

    private fun encode(list: List<Note>): String {
        val array = JSONArray()
        list.forEach { n ->
            array.put(JSONObject().put("id", n.id).put("text", n.text).put("t", n.updatedAt))
        }
        return array.toString()
    }

    private fun decode(s: String): List<Note> = runCatching {
        val array = JSONArray(s)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Note(o.getLong("id"), o.getString("text"), o.optLong("t"))
        }
    }.getOrDefault(emptyList())
}
