package com.aether.os.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherSpring
import kotlinx.coroutines.delay

private val IslandColor = Color(0xF2000000)

private fun formatRemaining(ms: Long): String {
    val total = (ms + 999L) / 1000L
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/**
 * AETHER Dynamic Island. Показывает только реальные события оболочки: сейчас это
 * таймер, запущенный в виджете «Часы». Когда событий нет, остров не отображается.
 * Нажатие раскрывает остров. Таймер работает, пока процесс AETHER жив;
 * для надёжного будильника используйте системный (плитка «Будильник»).
 */
@Composable
fun BoxScope.DynamicIsland(timer: TimerState, onCancel: () -> Unit) {
    val endAt = timer.endAt ?: return
    val p = LocalAetherPalette.current
    val now by produceState(initialValue = System.currentTimeMillis(), endAt) {
        while (value < endAt) {
            delay(250)
            value = System.currentTimeMillis()
        }
    }
    val remaining = (endAt - now).coerceAtLeast(0L)
    val finished = remaining == 0L
    var expanded by remember(finished) { mutableStateOf(finished) }
    val shape = RoundedCornerShape(if (expanded) 28.dp else 22.dp)

    Box(
        Modifier
            .align(Alignment.TopCenter)
            .statusBarsPadding()
            .padding(top = 6.dp)
    ) {
        Column(
            Modifier
                .clip(shape)
                .background(IslandColor)
                .border(1.dp, Color.White.copy(alpha = 0.18f), shape)
                .clickable { expanded = !expanded }
                .animateContentSize(animationSpec = aetherSpring())
                .width(if (expanded) 264.dp else 116.dp)
                .padding(horizontal = 16.dp, vertical = if (expanded) 14.dp else 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            if (!expanded) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(8.dp)
                            .background(if (finished) Color(0xFFFF9F43) else p.accent, CircleShape)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (finished) "Готово" else formatRemaining(remaining),
                        style = AetherType.caption,
                        color = Color.White,
                    )
                }
            } else {
                Text("Таймер", style = AetherType.caption, color = Color.White.copy(alpha = 0.7f))
                Text(
                    if (finished) "Время вышло" else formatRemaining(remaining),
                    style = AetherType.title,
                    color = Color.White,
                )
                if (!finished && timer.totalMs > 0L) {
                    val fraction = (remaining.toFloat() / timer.totalMs).coerceIn(0f, 1f)
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(fraction)
                                .fillMaxHeight()
                                .background(p.accent)
                        )
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onCancel) {
                        Text(if (finished) "Закрыть" else "Отмена", color = p.accent)
                    }
                }
            }
        }
    }
}
