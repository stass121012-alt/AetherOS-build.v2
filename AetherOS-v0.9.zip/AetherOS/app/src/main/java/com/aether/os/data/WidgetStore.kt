package com.aether.os.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.widgetDataStore by preferencesDataStore(name = "aether_widgets")

enum class WidgetType(val title: String) {
    CLOCK("Часы"),
    CALENDAR("Календарь"),
    NOTES("Заметки"),
    WEATHER("Погода"),
}

/** Выбранный город и последний полученный прогноз (кэш на случай отсутствия сети). */
data class WeatherPrefs(
    val city: String,
    val lat: Double,
    val lon: Double,
    val tempC: Double?,
    val code: Int?,
    val windKmh: Double?,
    val updatedAt: Long,
)

data class WidgetPrefs(
    val widgets: List<WidgetType>,
    val notes: List<String>,
    val weather: WeatherPrefs?,
    /** Время окончания таймера оболочки (мс, wall clock); null — таймер не запущен. */
    val timerEndAt: Long?,
    val timerTotalMs: Long,
)

class WidgetStore(private val context: Context) {

    private val kWidgets = stringPreferencesKey("widgets")
    private val kNotes = stringPreferencesKey("notes")
    private val kCity = stringPreferencesKey("w_city")
    private val kLat = doublePreferencesKey("w_lat")
    private val kLon = doublePreferencesKey("w_lon")
    private val kTemp = doublePreferencesKey("w_temp")
    private val kCode = intPreferencesKey("w_code")
    private val kWind = doublePreferencesKey("w_wind")
    private val kUpdated = longPreferencesKey("w_updated")
    private val kTimerEnd = longPreferencesKey("timer_end")
    private val kTimerTotal = longPreferencesKey("timer_total")

    val prefs: Flow<WidgetPrefs> = context.widgetDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { it.toWidgetPrefs() }

    private fun Preferences.toWidgetPrefs(): WidgetPrefs {
        val widgets = this[kWidgets]?.split(",")
            ?.mapNotNull { n -> runCatching { WidgetType.valueOf(n) }.getOrNull() }
            ?: DEFAULT_WIDGETS
        val city = this[kCity]
        val lat = this[kLat]
        val lon = this[kLon]
        val weather = if (city != null && lat != null && lon != null) {
            WeatherPrefs(city, lat, lon, this[kTemp], this[kCode], this[kWind], this[kUpdated] ?: 0L)
        } else {
            null
        }
        return WidgetPrefs(
            widgets = widgets.distinct(),
            notes = this[kNotes]?.split("\n")?.filter { it.isNotBlank() } ?: emptyList(),
            weather = weather,
            timerEndAt = this[kTimerEnd],
            timerTotalMs = this[kTimerTotal] ?: 0L,
        )
    }

    suspend fun setWidgets(list: List<WidgetType>) {
        context.widgetDataStore.edit { it[kWidgets] = list.joinToString(",") { t -> t.name } }
    }

    suspend fun setNotes(list: List<String>) {
        context.widgetDataStore.edit { it[kNotes] = list.joinToString("\n") }
    }

    suspend fun setWeather(w: WeatherPrefs?) {
        context.widgetDataStore.edit { p ->
            if (w == null) {
                p.remove(kCity); p.remove(kLat); p.remove(kLon)
                p.remove(kTemp); p.remove(kCode); p.remove(kWind); p.remove(kUpdated)
            } else {
                p[kCity] = w.city
                p[kLat] = w.lat
                p[kLon] = w.lon
                if (w.tempC != null) p[kTemp] = w.tempC else p.remove(kTemp)
                if (w.code != null) p[kCode] = w.code else p.remove(kCode)
                if (w.windKmh != null) p[kWind] = w.windKmh else p.remove(kWind)
                p[kUpdated] = w.updatedAt
            }
        }
    }

    suspend fun setTimer(endAt: Long?, totalMs: Long) {
        context.widgetDataStore.edit { p ->
            if (endAt == null) {
                p.remove(kTimerEnd)
                p.remove(kTimerTotal)
            } else {
                p[kTimerEnd] = endAt
                p[kTimerTotal] = totalMs
            }
        }
    }

    private companion object {
        val DEFAULT_WIDGETS = listOf(WidgetType.CLOCK, WidgetType.NOTES)
    }
}
