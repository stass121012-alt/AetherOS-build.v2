package com.aether.os.ui

import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.design.aetherSpring
import kotlin.math.roundToInt

/** Общая «шторка» для экранов настроек: затемнение, панель со световой кромкой, список. */
@Composable
internal fun SheetScaffold(
    title: String,
    subtitle: String?,
    onClose: () -> Unit,
    heightFraction: Float = 0.85f,
    scrimAlpha: Float = 0.45f,
    content: LazyListScope.() -> Unit,
) {
    val p = LocalAetherPalette.current
    val scrimSource = remember { MutableInteractionSource() }
    val panelSource = remember { MutableInteractionSource() }
    val sheetShape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
    val configuration = LocalConfiguration.current
    // В ландшафте высоты мало — шторка занимает почти весь экран.
    val fraction = if (configuration.screenWidthDp > configuration.screenHeightDp) maxOf(heightFraction, 0.92f) else heightFraction

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = scrimAlpha))
            .clickable(interactionSource = scrimSource, indication = null, onClick = onClose)
    ) {
        LazyColumn(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .fillMaxHeight(fraction)
                .clip(sheetShape)
                .background(p.panel)
                .border(1.dp, Brush.verticalGradient(listOf(p.glassEdgeLight, Color.Transparent)), sheetShape)
                .clickable(interactionSource = panelSource, indication = null) { },
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Text(title, style = AetherType.title, color = p.textPrimary)
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = AetherType.caption,
                        color = p.textSecondary,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }
            content()
        }
    }
}

@Composable
internal fun SectionTitle(text: String) {
    val p = LocalAetherPalette.current
    Text(
        text,
        style = AetherType.section,
        color = p.accent,
        modifier = Modifier.padding(top = 16.dp, bottom = 2.dp),
    )
}

@Composable
internal fun ActionRow(title: String, subtitle: String?, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(title, style = AetherType.body, color = p.textPrimary)
        if (subtitle != null) {
            Text(subtitle, style = AetherType.caption, color = p.textSecondary)
        }
    }
}

@Composable
internal fun InfoRow(label: String, value: String) {
    val p = LocalAetherPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, style = AetherType.caption, color = p.textSecondary)
        Text(
            value,
            style = AetherType.caption,
            color = p.textPrimary,
            modifier = Modifier.padding(start = 16.dp),
        )
    }
}

@Composable
internal fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalAetherPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = AetherType.body, color = p.textPrimary)
            Text(subtitle, style = AetherType.caption, color = p.textSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = p.accent,
                uncheckedThumbColor = p.textSecondary,
                uncheckedTrackColor = Color.Transparent,
                uncheckedBorderColor = p.textSecondary,
            ),
        )
    }
}

/** Слайдер с целыми значениями: значение сохраняется только по окончании перетаскивания. */
@Composable
internal fun SliderRow(
    title: String,
    unit: String,
    value: Int,
    range: IntRange,
    onCommit: (Int) -> Unit,
) {
    val p = LocalAetherPalette.current
    var live by remember(value) { mutableFloatStateOf(value.toFloat()) }
    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = AetherType.body, color = p.textPrimary)
            Text("${live.roundToInt()}$unit", style = AetherType.body, color = p.accent)
        }
        Slider(
            value = live,
            onValueChange = { live = it },
            onValueChangeFinished = { onCommit(live.roundToInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(),
            steps = (range.last - range.first - 1).coerceAtLeast(0),
            colors = SliderDefaults.colors(
                thumbColor = p.accent,
                activeTrackColor = p.accent,
                inactiveTrackColor = p.textSecondary.copy(alpha = 0.25f),
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent,
            ),
        )
    }
}

@Composable
internal fun <T> SegmentedRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    val p = LocalAetherPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(4.dp)
    ) {
        options.forEach { (value, label) ->
            val isSelected = value == selected
            val bg by animateColorAsState(
                targetValue = if (isSelected) p.accent.copy(alpha = 0.28f) else Color.Transparent,
                animationSpec = aetherSpring(),
                label = "segment",
            )
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(AetherDimens.radiusSmall - 3.dp))
                    .background(bg)
                    .clickable { onSelect(value) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = AetherType.caption, color = p.textPrimary, textAlign = TextAlign.Center)
            }
        }
    }
}
