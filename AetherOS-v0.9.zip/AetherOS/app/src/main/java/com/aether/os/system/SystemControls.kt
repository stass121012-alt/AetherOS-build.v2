package com.aether.os.system

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Куда ведут плитки, которые Android не разрешает переключать обычному приложению. */
enum class SystemTarget { WIFI, BLUETOOTH, AIRPLANE, DISPLAY, DND_ACCESS, ALARMS, NOTIFICATION_ACCESS }

data class ControlState(
    /** null — состояние Wi-Fi прочитать не удалось. */
    val wifiOn: Boolean? = null,
    val airplaneOn: Boolean = false,
    val torchAvailable: Boolean = false,
    val torchOn: Boolean = false,
    /** Пользователь выдал AETHER доступ к режиму «Не беспокоить» в системных настройках. */
    val dndAccess: Boolean = false,
    val dndOn: Boolean = false,
    val volume: Int = 0,
    val volumeMax: Int = 1,
)

/**
 * Реальные системные действия, доступные обычному приложению:
 *  - фонарик (CameraManager.setTorchMode, без разрешений);
 *  - громкость мультимедиа (AudioManager);
 *  - «Не беспокоить» — только если пользователь выдал доступ;
 *  - чтение состояния Wi-Fi и авиарежима (переключать их приложение не может).
 * Слушатели регистрируются только пока открыт Control Center ([start]/[stop]).
 */
class SystemControls(context: Context) {

    private val appContext = context.applicationContext
    private val audio = appContext.getSystemService(AudioManager::class.java)
    private val wifi = appContext.getSystemService(WifiManager::class.java)
    private val camera = appContext.getSystemService(CameraManager::class.java)
    private val notifications = appContext.getSystemService(NotificationManager::class.java)

    private val torchId: String? = findTorchId()
    private val _state = MutableStateFlow(ControlState(torchAvailable = torchId != null))
    val state: StateFlow<ControlState> = _state.asStateFlow()
    private var started = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refresh()
        }
    }

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) _state.update { it.copy(torchOn = enabled) }
        }

        override fun onTorchModeUnavailable(cameraId: String) {
            if (cameraId == torchId) _state.update { it.copy(torchOn = false) }
        }
    }

    private fun findTorchId(): String? {
        val manager = camera ?: return null
        return try {
            manager.cameraIdList.firstOrNull { id ->
                val c = manager.getCameraCharacteristics(id)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (e: CameraAccessException) {
            null
        }
    }

    fun start() {
        if (started) return
        started = true
        refresh()
        val filter = IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
        }
        ContextCompat.registerReceiver(appContext, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        if (torchId != null) camera?.registerTorchCallback(torchCallback, null)
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            appContext.unregisterReceiver(receiver)
        } catch (e: IllegalArgumentException) {
            // Уже снят — ничего не делаем.
        }
        camera?.unregisterTorchCallback(torchCallback)
    }

    fun refresh() {
        val wifiOn = try {
            wifi?.isWifiEnabled
        } catch (e: SecurityException) {
            null
        }
        val airplane = Settings.Global.getInt(appContext.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        val access = notifications?.isNotificationPolicyAccessGranted == true
        val filter = notifications?.currentInterruptionFilter ?: NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        val dndOn = filter != NotificationManager.INTERRUPTION_FILTER_ALL &&
            filter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        _state.update {
            it.copy(
                wifiOn = wifiOn,
                airplaneOn = airplane,
                dndAccess = access,
                dndOn = dndOn,
                volume = audio?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0,
                volumeMax = (audio?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 1).coerceAtLeast(1),
            )
        }
    }

    /** Состояние фонарика обновит [torchCallback]. */
    fun toggleTorch() {
        val id = torchId ?: return
        try {
            camera?.setTorchMode(id, !_state.value.torchOn)
        } catch (e: CameraAccessException) {
            // Камера занята другим приложением.
        } catch (e: IllegalArgumentException) {
            // Устройство перестало поддерживать фонарик.
        }
    }

    fun setVolume(value: Int) {
        val max = _state.value.volumeMax
        try {
            audio?.setStreamVolume(AudioManager.STREAM_MUSIC, value.coerceIn(0, max), 0)
        } catch (e: SecurityException) {
            // Политика устройства запрещает менять громкость.
        }
        refresh()
    }

    /**
     * Переключает «Не беспокоить». Возвращает false, если у AETHER нет доступа —
     * тогда интерфейс открывает системный экран выдачи доступа.
     */
    fun toggleDnd(): Boolean {
        val nm = notifications ?: return false
        if (!nm.isNotificationPolicyAccessGranted) return false
        val next = if (_state.value.dndOn) {
            NotificationManager.INTERRUPTION_FILTER_ALL
        } else {
            NotificationManager.INTERRUPTION_FILTER_PRIORITY
        }
        return try {
            nm.setInterruptionFilter(next)
            refresh()
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /** Системная яркость (0..1) — только чтение, без WRITE_SETTINGS. */
    fun systemBrightness(): Float {
        val v = Settings.System.getInt(appContext.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        return (v / 255f).coerceIn(0.02f, 1f)
    }
}
