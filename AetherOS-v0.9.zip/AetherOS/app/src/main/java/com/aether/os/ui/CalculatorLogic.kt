package com.aether.os.ui

import java.math.BigDecimal
import java.math.RoundingMode

/** Логика калькулятора: ввод выражения и вычисление с приоритетом операций. */
object CalculatorLogic {

    const val ERROR = "Ошибка"
    private const val OPERATORS = "+−×÷"

    data class State(val expr: String = "", val justEvaluated: Boolean = false)

    fun press(state: State, key: String): State {
        val s = if (state.expr == ERROR) State() else state
        return when (key) {
            "C" -> State()
            "⌫" -> if (s.justEvaluated) State() else State(s.expr.dropLast(1))
            "=" -> evaluate(s.expr)?.let { State(it, true) } ?: s
            "±" -> State(toggleSign(s.expr), false)
            "%" -> if (s.expr.isNotEmpty() && (s.expr.last().isDigit() || s.expr.last() == '%')) {
                State(s.expr + "%", false)
            } else {
                s
            }
            "." -> pressDecimal(s)
            "+", "−", "×", "÷" -> pressOperator(s, key[0])
            else -> pressDigit(s, key)
        }
    }

    private fun currentNumber(expr: String): String = expr.takeLastWhile { it.isDigit() || it == '.' }

    private fun pressDigit(s: State, digit: String): State {
        if (s.justEvaluated) return State(digit)
        val current = currentNumber(s.expr)
        if (current == "0" && !s.expr.endsWith("%")) {
            return State(s.expr.dropLast(1) + digit)
        }
        if (s.expr.endsWith("%")) return s
        return State(s.expr + digit)
    }

    private fun pressDecimal(s: State): State {
        if (s.justEvaluated) return State("0.")
        if (s.expr.endsWith("%")) return s
        val current = currentNumber(s.expr)
        return when {
            current.contains('.') -> s
            current.isEmpty() -> State(s.expr + "0.")
            else -> State(s.expr + ".")
        }
    }

    private fun pressOperator(s: State, op: Char): State {
        val expr = s.expr
        if (expr.isEmpty()) return if (op == '−') State("−") else s
        if (expr == "−") return s
        val last = expr.last()
        return when {
            last in OPERATORS -> State(expr.dropLast(1) + op)
            last == '.' -> State(expr.dropLast(1) + op)
            else -> State(expr + op)
        }
    }

    private fun toggleSign(expr: String): String {
        if (!Regex("^−?[0-9.]+$").matches(expr)) return expr
        return if (expr.startsWith("−")) expr.drop(1) else "−$expr"
    }

    /**
     * Возвращает результат строкой, "Ошибка" при делении на ноль
     * или null, если выражение пока неполное.
     */
    fun evaluate(expr: String): String? {
        if (expr.isBlank() || expr == ERROR) return null
        return try {
            val parser = Parser(expr)
            val value = parser.parseExpression()
            if (!parser.atEnd()) null else format(value)
        } catch (e: ArithmeticException) {
            ERROR
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    private fun format(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return ERROR
        val text = BigDecimal(v).setScale(10, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
        return text.replace('-', '−')
    }

    private class Parser(private val s: String) {
        private var i = 0

        fun atEnd() = i >= s.length

        private fun isMinus(c: Char) = c == '−' || c == '-'

        fun parseExpression(): Double {
            var value = parseTerm()
            while (i < s.length && (s[i] == '+' || isMinus(s[i]))) {
                val op = s[i++]
                val right = parseTerm()
                value = if (op == '+') value + right else value - right
            }
            return value
        }

        private fun parseTerm(): Double {
            var value = parseFactor()
            while (i < s.length && (s[i] == '×' || s[i] == '÷')) {
                val op = s[i++]
                val right = parseFactor()
                if (op == '÷') {
                    if (right == 0.0) throw ArithmeticException("division by zero")
                    value /= right
                } else {
                    value *= right
                }
            }
            return value
        }

        private fun parseFactor(): Double {
            var negative = false
            if (i < s.length && isMinus(s[i])) {
                negative = true
                i++
            }
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (start == i) throw IllegalArgumentException("number expected")
            var value = s.substring(start, i).toDouble()
            while (i < s.length && s[i] == '%') {
                value /= 100.0
                i++
            }
            return if (negative) -value else value
        }
    }
}
