package com.aether.os.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Встроенные приложения AETHER. Они живут внутри оболочки (не отдельные APK),
 * но участвуют в сетке, доке, папках и поиске как обычные приложения.
 */
object BuiltinApps {
    const val PREFIX = "aether.builtin."
    const val NOTES = PREFIX + "notes"
    const val CALCULATOR = PREFIX + "calculator"
    const val CALENDAR = PREFIX + "calendar"
    const val CLOCK = PREFIX + "clock"
    const val GALLERY = PREFIX + "gallery"
    const val WEATHER = PREFIX + "weather"
    const val APP_MANAGER = PREFIX + "appmanager"
    const val SETTINGS = PREFIX + "settings"
    const val PERSONALIZATION = PREFIX + "personalization"

    fun isBuiltin(packageName: String) = packageName.startsWith(PREFIX)

    @Suppress("UNUSED_PARAMETER")
    fun create(context: Context): List<AppInfo> = listOf(
        AppInfo("Заметки", NOTES, "notes", notesIcon()),
        AppInfo("Калькулятор", CALCULATOR, "calculator", calculatorIcon()),
        AppInfo("Календарь", CALENDAR, "calendar", calendarIcon()),
        AppInfo("Часы", CLOCK, "clock", clockIcon()),
        AppInfo("Галерея", GALLERY, "gallery", galleryIcon()),
        AppInfo("Погода", WEATHER, "weather", weatherIcon()),
        AppInfo("Диспетчер приложений", APP_MANAGER, "appmanager", managerIcon()),
        AppInfo("Настройки AETHER", SETTINGS, "settings", settingsIcon()),
        AppInfo("Персонализация", PERSONALIZATION, "personalization", personalizationIcon()),
    )

    private const val SIZE = 144
    private const val S = SIZE.toFloat()

    private fun fill(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color }

    private fun stroke(color: Int, width: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeWidth = width
        strokeCap = Paint.Cap.ROUND
    }

    /** Рисует фон-градиент со скруглением и передаёт холст для глифа. */
    private fun icon(top: Int, bottom: Int, draw: (Canvas) -> Unit): ImageBitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, S, top, bottom, Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(RectF(0f, 0f, S, S), S * 0.22f, S * 0.22f, bg)
        draw(canvas)
        return bmp.asImageBitmap()
    }

    private fun notesIcon() = icon(0xFFFFC857.toInt(), 0xFFFF8F3D.toInt()) { c ->
        val line = fill(0xE6FFFFFF.toInt())
        for (i in 0..2) {
            val top = 40f + i * 28f
            val right = if (i == 2) 84f else 114f
            c.drawRoundRect(RectF(30f, top, right, top + 11f), 5.5f, 5.5f, line)
        }
    }

    private fun calculatorIcon() = icon(0xFF3A3F4B.toInt(), 0xFF14161C.toInt()) { c ->
        val paint = fill(0xFFFFFFFF.toInt()).apply {
            textSize = 52f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        c.drawText("+", 46f, 66f, paint)
        c.drawText("−", 98f, 66f, paint)
        c.drawText("×", 46f, 116f, paint)
        paint.color = 0xFFFF9F43.toInt()
        c.drawText("=", 98f, 116f, paint)
    }

    private fun calendarIcon() = icon(0xFFFFFFFF.toInt(), 0xFFE6E9F0.toInt()) { c ->
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, S, S), S * 0.22f, S * 0.22f, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, 0f, S, 44f, fill(0xFFFF453A.toInt()))
        c.restore()
        val dot = fill(0xFF8A8F9C.toInt())
        for (row in 0..1) for (col in 0..2) {
            c.drawCircle(40f + col * 32f, 80f + row * 30f, 8f, dot)
        }
    }

    private fun clockIcon() = icon(0xFF2B2F3A.toInt(), 0xFF0E1015.toInt()) { c ->
        c.drawCircle(72f, 72f, 54f, fill(0xFFF4F6FB.toInt()))
        val hand = stroke(0xFF1B1E26.toInt(), 8f)
        c.drawLine(72f, 72f, 72f, 40f, hand)
        c.drawLine(72f, 72f, 98f, 72f, hand)
        c.drawCircle(72f, 72f, 6f, fill(0xFFFF9F43.toInt()))
    }

    private fun galleryIcon() = icon(0xFF5AC8FA.toInt(), 0xFF2F6BFF.toInt()) { c ->
        c.drawCircle(104f, 46f, 14f, fill(0xFFFFE08A.toInt()))
        val big = Path().apply { moveTo(18f, 118f); lineTo(60f, 64f); lineTo(100f, 118f); close() }
        val small = Path().apply { moveTo(66f, 118f); lineTo(98f, 82f); lineTo(130f, 118f); close() }
        c.drawPath(big, fill(0xE6FFFFFF.toInt()))
        c.drawPath(small, fill(0xB3FFFFFF.toInt()))
    }

    private fun weatherIcon() = icon(0xFF4FA8FF.toInt(), 0xFF1E5FD1.toInt()) { c ->
        c.drawCircle(58f, 56f, 24f, fill(0xFFFFD66B.toInt()))
        val cloud = fill(0xF2FFFFFF.toInt())
        c.drawCircle(64f, 94f, 22f, cloud)
        c.drawCircle(92f, 88f, 26f, cloud)
        c.drawRoundRect(RectF(40f, 92f, 118f, 116f), 12f, 12f, cloud)
    }

    private fun managerIcon() = icon(0xFF9AA0AF.toInt(), 0xFF565B69.toInt()) { c ->
        val tile = fill(0xE6FFFFFF.toInt())
        for (row in 0..1) for (col in 0..1) {
            val left = 32f + col * 44f
            val top = 32f + row * 44f
            c.drawRoundRect(RectF(left, top, left + 34f, top + 34f), 9f, 9f, tile)
        }
    }

    private fun settingsIcon() = icon(0xFF8E94A3.toInt(), 0xFF4A4F5C.toInt()) { c ->
        val paint = stroke(0xFFFFFFFF.toInt(), 12f)
        c.drawCircle(72f, 72f, 26f, stroke(0xFFFFFFFF.toInt(), 10f))
        for (i in 0 until 8) {
            c.save()
            c.rotate(i * 45f, 72f, 72f)
            c.drawLine(72f, 22f, 72f, 36f, paint)
            c.restore()
        }
    }

    private fun personalizationIcon() = icon(0xFFB06AF0.toInt(), 0xFFFF5E98.toInt()) { c ->
        c.drawCircle(50f, 56f, 15f, fill(0xFFFFE08A.toInt()))
        c.drawCircle(94f, 56f, 15f, fill(0xFFFFFFFF.toInt()))
        c.drawCircle(72f, 96f, 15f, fill(0xFF8DEBFF.toInt()))
    }
}
