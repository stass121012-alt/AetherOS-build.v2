package com.aether.os.ui

import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.os.data.WidgetType
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.design.rememberNow
import com.aether.os.system.SystemTarget
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.WeekFields
import java.util.Locale
import java.time.format.TextStyle as DateTextStyle

private val TimerPresetsMinutes = listOf(1, 5, 10, 25)

/** Страница виджетов (слева от первой страницы приложений). */
@Composable
fun WidgetsPage(state: WidgetsState, actions: HomeActions) {
    val p = LocalAetherPalette.current
    val missing = WidgetType.entries.filter { it !in state.widgets }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            "Виджеты",
            style = AetherType.title,
            color = p.textPrimary,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        state.widgets.forEach { type ->
            when (type) {
                WidgetType.CLOCK -> ClockWidget(state.timer, actions)
                WidgetType.CALENDAR -> CalendarWidget(actions)
                WidgetType.NOTES -> NotesWidget(state.notes, actions)
                WidgetType.WEATHER -> WeatherWidget(state, actions)
            }
        }
        if (state.widgets.isEmpty()) {
            Text(
                "Виджетов нет. Добавьте их ниже.",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
        missing.forEach { type ->
            ActionRow(
                title = "Добавить: ${type.title}",
                subtitle = null,
                onClick = { actions.onAddWidget(type) },
            )
        }
    }
}

/** Общая оболочка виджета: стеклянная карточка, заголовок и кнопка «Убрать». */
@Composable
internal fun WidgetCard(
    title: String,
    onRemove: () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalAetherPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusCard))
            .padding(16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(title.uppercase(Locale.getDefault()), style = AetherType.section, color = p.accent)
            Text(
                "Убрать",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.clickable(onClick = onRemove).padding(4.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
internal fun Chip(text: String, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    Text(
        text,
        style = AetherType.caption,
        color = p.textPrimary,
        modifier = Modifier
            .aetherGlass(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

@Composable
private fun ClockWidget(timer: TimerState, actions: HomeActions) {
    val p = LocalAetherPalette.current
    val context = LocalContext.current
    val now by rememberNow()
    val is24 = DateFormat.is24HourFormat(context)
    val timeFormatter = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm") }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }

    WidgetCard("Часы", { actions.onRemoveWidget(WidgetType.CLOCK) }) {
        Text(
            now.format(timeFormatter),
            style = AetherType.clock.copy(fontSize = 56.sp),
            color = p.textPrimary,
            modifier = Modifier.clickable { actions.onOpenSystem(SystemTarget.ALARMS) },
        )
        Text(
            now.format(dateFormatter).replaceFirstChar { it.titlecase(Locale.getDefault()) },
            style = AetherType.caption,
            color = p.textSecondary,
        )
        Spacer(Modifier.height(12.dp))
        if (timer.endAt != null) {
            Text(
                "Таймер запущен — смотрите остров вверху экрана.",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            Chip("Отменить таймер", actions.onCancelTimer)
        } else {
            Text("ТАЙМЕР", style = AetherType.section, color = p.textSecondary)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimerPresetsMinutes.forEach { m -> Chip("$m мин") { actions.onStartTimer(m) } }
            }
        }
        Text(
            "Нажмите на время, чтобы открыть системные будильники.",
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.padding(top = 10.dp),
        )
    }
}

/**
 * Календарь: сетка месяца без событий — чтение календаря требует разрешения READ_CALENDAR,
 * которое AETHER не запрашивает. Нажатие на день открывает системный календарь.
 */
@Composable
private fun CalendarWidget(actions: HomeActions) {
    val p = LocalAetherPalette.current
    val locale = Locale.getDefault()
    var offset by rememberSaveable { mutableStateOf(0) }
    val month = remember(offset) { YearMonth.now().plusMonths(offset.toLong()) }
    val firstDow: DayOfWeek = remember { WeekFields.of(locale).firstDayOfWeek }
    val lead = (month.atDay(1).dayOfWeek.value - firstDow.value + 7) % 7
    val days = month.lengthOfMonth()
    val rows = (lead + days + 6) / 7
    val today = LocalDate.now()
    val title = month.month.getDisplayName(DateTextStyle.FULL_STANDALONE, locale)
        .replaceFirstChar { it.titlecase(locale) } + " " + month.year

    WidgetCard("Календарь", { actions.onRemoveWidget(WidgetType.CALENDAR) }) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "‹",
                style = AetherType.title,
                color = p.textPrimary,
                modifier = Modifier.clickable { offset -= 1 }.padding(horizontal = 12.dp),
            )
            Text(
                title,
                style = AetherType.body,
                color = p.textPrimary,
                modifier = Modifier.clickable { offset = 0 }.padding(8.dp),
            )
            Text(
                "›",
                style = AetherType.title,
                color = p.textPrimary,
                modifier = Modifier.clickable { offset += 1 }.padding(horizontal = 12.dp),
            )
        }
        Row(Modifier.fillMaxWidth()) {
            repeat(7) { i ->
                Text(
                    firstDow.plus(i.toLong()).getDisplayName(DateTextStyle.NARROW, locale),
                    style = AetherType.caption,
                    color = p.textSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
            }
        }
        repeat(rows) { r ->
            Row(Modifier.fillMaxWidth()) {
                repeat(7) { c ->
                    val day = r * 7 + c - lead + 1
                    if (day in 1..days) {
                        val date = month.atDay(day)
                        val isToday = date == today
                        Box(
                            Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(if (isToday) p.accent.copy(alpha = 0.35f) else androidx.compose.ui.graphics.Color.Transparent)
                                .clickable {
                                    val millis = date.atStartOfDay(ZoneId.systemDefault())
                                        .toInstant().toEpochMilli()
                                    actions.onOpenCalendarDay(millis)
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(day.toString(), style = AetherType.caption, color = p.textPrimary)
                        }
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        Text(
            "События не показываются: для чтения календаря нужно разрешение, AETHER его не запрашивает. " +
                "Нажмите на день — откроется системный календарь.",
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}
