package com.aether.os

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.aether.os.data.AppInfo
import com.aether.os.data.BuiltinApps
import com.aether.os.design.AetherTheme
import com.aether.os.design.LocalAetherPalette
import com.aether.os.system.GalleryPermission
import com.aether.os.system.SystemTarget
import com.aether.os.ui.HomeActions
import com.aether.os.ui.HomeScreen
import com.aether.os.ui.HomeViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: HomeViewModel by viewModels()

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refresh(300L)
        }
    }

    /** Системный Photo Picker: разрешения на галерею не нужны. */
    private val pickWallpaper = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.setWallpaperFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if ((application as? AetherApp)?.safeModeReset == true) {
            Toast.makeText(this, R.string.safe_mode_reset, Toast.LENGTH_LONG).show()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.messages.collect { resId ->
                    Toast.makeText(this@MainActivity, resId, Toast.LENGTH_SHORT).show()
                }
            }
        }

        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val wallpaperImage by viewModel.wallpaperImage.collectAsStateWithLifecycle()
            val brightness by viewModel.brightness.collectAsStateWithLifecycle()
            val widgets by viewModel.widgets.collectAsStateWithLifecycle()
            val appNotes by viewModel.appNotes.collectAsStateWithLifecycle()
            val notificationAccess by viewModel.notificationAccess.collectAsStateWithLifecycle()
            val systemApps by viewModel.systemApps.collectAsStateWithLifecycle()
            val forecast by viewModel.forecast.collectAsStateWithLifecycle()
            val gallery by viewModel.gallery.collectAsStateWithLifecycle()
            val actions = remember {
                HomeActions(
                    onLaunch = ::launchApp,
                    onToggleDock = viewModel::toggleDock,
                    onHide = viewModel::hide,
                    onUnhide = viewModel::unhide,
                    onUnhideAll = viewModel::unhideAll,
                    onResetDock = viewModel::resetDock,
                    onMove = viewModel::moveBy,
                    onAppInfo = ::openAppInfo,
                    onThemeMode = viewModel::setThemeMode,
                    onReduceMotion = viewModel::setReduceMotion,
                    onIconSize = viewModel::setIconSize,
                    onColumns = viewModel::setColumns,
                    onRows = viewModel::setRows,
                    onShowLabels = viewModel::setShowLabels,
                    onWallpaper = viewModel::setWallpaper,
                    onPickWallpaper = ::pickWallpaperImage,
                    onRemoveWallpaperImage = viewModel::removeWallpaperImage,
                    onResetPersonalization = viewModel::resetPersonalization,
                    onReorder = viewModel::reorder,
                    onCreateFolder = viewModel::createFolder,
                    onAddToFolder = viewModel::addToFolder,
                    onRemoveFromFolder = viewModel::removeFromFolder,
                    onRenameFolder = viewModel::renameFolder,
                    onDissolveFolder = viewModel::dissolveFolder,
                    onOpenSystem = ::openSystem,
                    onSetBrightness = viewModel::setBrightness,
                    onResetBrightness = viewModel::resetBrightness,
                    onAddWidget = viewModel::addWidget,
                    onRemoveWidget = viewModel::removeWidget,
                    onAddNote = viewModel::addNote,
                    onDeleteNote = viewModel::deleteNote,
                    onSetWeatherCity = viewModel::setWeatherCity,
                    onRefreshWeather = viewModel::refreshWeather,
                    onStartTimer = viewModel::startTimer,
                    onCancelTimer = viewModel::cancelTimer,
                    onOpenCalendarDay = ::openCalendarDay,
                    onSaveAppNote = viewModel::saveAppNote,
                    onDeleteAppNote = viewModel::deleteAppNote,
                    onSaveEvent = viewModel::saveEvent,
                    onDeleteEvent = viewModel::deleteEvent,
                    onSetWorldZones = viewModel::setWorldZones,
                    onLoadForecast = viewModel::loadForecast,
                    onRequestGalleryPermission = ::requestGalleryPermission,
                    onLoadGallery = viewModel::loadGallery,
                    onSetWallpaperFromUri = viewModel::setWallpaperFromUri,
                    onOpenUri = ::openUri,
                    onUninstall = ::uninstallApp,
                )
            }

            // Яркость окна AETHER: действует только на этот экран, системная не меняется.
            LaunchedEffect(brightness) {
                val lp = window.attributes
                lp.screenBrightness = brightness ?: WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                window.attributes = lp
            }

            AetherTheme(themeMode = settings.themeMode, reduceMotion = settings.reduceMotion) {
                // Цвет иконок системных панелей следует выбранной теме AETHER.
                val isDark = LocalAetherPalette.current.isDark
                LaunchedEffect(isDark) {
                    val style = if (isDark) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    }
                    this@MainActivity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                }
                // Домашний экран не закрывается кнопкой «Назад».
                BackHandler(enabled = true) { }
                HomeScreen(
                    state = state,
                    settings = settings,
                    wallpaperImage = wallpaperImage,
                    controls = viewModel.controls,
                    brightness = brightness,
                    widgets = widgets,
                    appNotes = appNotes,
                    notificationAccess = notificationAccess,
                    systemApps = systemApps,
                    forecast = forecast,
                    gallery = gallery,
                    baseActions = actions,
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Пользователь мог выдать или отозвать доступ к уведомлениям в системных настройках.
        viewModel.refreshNotificationAccess()
        viewModel.refreshGalleryAccess()
    }

    private var receiverRegistered = false
    private var startedOnce = false

    /** Слушатель пакетов работает только пока оболочка видима — без фоновой работы. */
    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
        receiverRegistered = true
        // Пока оболочка была в фоне, набор приложений мог измениться (кэш иконок делает это дешёвым).
        if (startedOnce) viewModel.refresh()
        startedOnce = true
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(packageReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    private val requestGallery = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshGalleryAccess() }

    private fun requestGalleryPermission() {
        requestGallery.launch(GalleryPermission.name)
    }

    /** Открывает изображение во внешнем приложении. */
    private fun openUri(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStart(intent)
    }

    /** Удаление выполняет система после вашего подтверждения. */
    private fun uninstallApp(packageName: String) {
        if (BuiltinApps.isBuiltin(packageName)) return
        safeStart(
            Intent(Intent.ACTION_DELETE, Uri.fromParts("package", packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun pickWallpaperImage() {
        pickWallpaper.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    private fun launchApp(app: AppInfo) {
        if (BuiltinApps.isBuiltin(app.packageName)) return
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(intent)
    }

    private fun openAppInfo(packageName: String) {
        if (BuiltinApps.isBuiltin(packageName)) {
            Toast.makeText(this, R.string.builtin_app, Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStart(intent)
    }

    /** Системные экраны для того, что обычное приложение переключать не вправе. */
    private fun openSystem(target: SystemTarget) {
        val intent = when (target) {
            SystemTarget.WIFI ->
                if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else Intent(Settings.ACTION_WIFI_SETTINGS)
            SystemTarget.BLUETOOTH -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            SystemTarget.AIRPLANE -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            SystemTarget.DISPLAY -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            SystemTarget.DND_ACCESS -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            SystemTarget.ALARMS -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            SystemTarget.NOTIFICATION_ACCESS -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStart(intent)
    }

    /** Открывает системный календарь на выбранном дне (разрешения не нужны). */
    private fun openCalendarDay(epochMillis: Long) {
        val uri = CalendarContract.CONTENT_URI.buildUpon()
            .appendPath("time")
            .appendPath(epochMillis.toString())
            .build()
        safeStart(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.launch_failed, Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, R.string.launch_failed, Toast.LENGTH_SHORT).show()
        }
    }
}
