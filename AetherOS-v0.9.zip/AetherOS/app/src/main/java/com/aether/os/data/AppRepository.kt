package com.aether.os.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Источник реальных установленных приложений через PackageManager.
 * Иконки и названия кэшируются по (пакет, время обновления, язык): при изменении набора
 * приложений перечитываются только новые, обновлённые и сменившие язык.
 */
class AppRepository(private val context: Context) {

    private class Cached(
        val lastUpdate: Long,
        val localeTag: String,
        val label: String,
        val icon: ImageBitmap,
    )

    private val pm: PackageManager get() = context.packageManager
    private val cache = ConcurrentHashMap<String, Cached>()
    private val builtinApps: List<AppInfo> by lazy { BuiltinApps.create(context) }

    suspend fun loadLauncherApps(): List<AppInfo> = withContext(Dispatchers.Default) {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val localeTag = Locale.getDefault().toLanguageTag()
        val seen = HashSet<String>()

        val installed = queryActivities(query)
            .filter { it.activityInfo.packageName != context.packageName }
            .mapNotNull { ri ->
                // Один «сломанный» пакет не должен ронять весь список.
                runCatching {
                    val pkg = ri.activityInfo.packageName
                    val activity = ri.activityInfo.name
                    val key = "$pkg/$activity"
                    seen += key
                    val updated = lastUpdateTime(pkg)
                    val cached = cache[key]
                    val entry = if (cached != null && cached.lastUpdate == updated && cached.localeTag == localeTag) {
                        cached
                    } else {
                        Cached(
                            lastUpdate = updated,
                            localeTag = localeTag,
                            label = ri.loadLabel(pm).toString(),
                            icon = ri.loadIcon(pm).toBitmap(ICON_PX, ICON_PX).asImageBitmap(),
                        ).also { cache[key] = it }
                    }
                    AppInfo(entry.label, pkg, activity, entry.icon)
                }.getOrNull()
            }
        // Удалённые приложения освобождают память.
        cache.keys.removeAll { it !in seen }

        (installed + builtinApps).sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    /** Док: телефон, сообщения, браузер, камера (если определены системой), затем добор. */
    fun pickDock(apps: List<AppInfo>, size: Int): List<AppInfo> {
        val preferred = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
                .addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE),
        ).mapNotNull { resolvePackage(it) }
        val byPackage = apps.associateBy { it.packageName }
        val dock = LinkedHashMap<String, AppInfo>()
        preferred.forEach { pkg -> byPackage[pkg]?.let { dock.putIfAbsent(pkg, it) } }
        apps.forEach { if (dock.size < size) dock.putIfAbsent(it.packageName, it) }
        return dock.values.take(size)
    }

    private fun lastUpdateTime(pkg: String): Long = try {
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L)).lastUpdateTime
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(pkg, 0).lastUpdateTime
        }
    } catch (e: PackageManager.NameNotFoundException) {
        0L
    }

    private fun resolvePackage(intent: Intent): String? {
        val ri = if (Build.VERSION.SDK_INT >= 33) {
            pm.resolveActivity(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()),
            )
        } else {
            @Suppress("DEPRECATION")
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }
        val pkg = ri?.activityInfo?.packageName
        return if (pkg == null || pkg == "android") null else pkg
    }

    private fun queryActivities(intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

    private companion object {
        const val ICON_PX = 144
    }
}
