package com.aether.os.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aether.os.data.GalleryImage
import com.aether.os.data.ImageLoader
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette

private const val THUMB_EDGE = 256
private const val FULL_EDGE = 1600

/**
 * Встроенная «Галерея». Читает изображения устройства только после того, как вы
 * разрешите доступ к фото. Фото можно поставить на обои или открыть во внешнем приложении.
 */
@Composable
fun GalleryApp(gallery: GalleryState, actions: HomeActions, onClose: () -> Unit) {
    val p = LocalAetherPalette.current
    val context = LocalContext.current
    var viewerIndex by rememberSaveable { mutableStateOf<Int?>(null) }

    LaunchedEffect(gallery.hasAccess) {
        if (gallery.hasAccess) actions.onLoadGallery()
    }
    // Освобождаем память при закрытии галереи.
    DisposableEffect(Unit) {
        onDispose { ImageLoader.clear() }
    }
    BackHandler(enabled = true) { if (viewerIndex != null) viewerIndex = null else onClose() }

    val viewer = viewerIndex
    if (viewer != null && viewer in gallery.images.indices) {
        GalleryViewer(gallery.images, viewer, actions) { viewerIndex = null }
        return
    }

    AppFrame(title = "Галерея", onClose = onClose) {
        when {
            !gallery.hasAccess -> Column(
                Modifier.padding(top = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    "Чтобы показать ваши фотографии, Android требует разрешение на доступ к изображениям.",
                    style = AetherType.body,
                    color = p.textPrimary,
                )
                Text(
                    "• Фото читаются только на устройстве и никуда не передаются.\n" +
                        "• Миниатюры хранятся в памяти и освобождаются при закрытии галереи.\n" +
                        "• Разрешение можно отозвать в настройках приложения.",
                    style = AetherType.caption,
                    color = p.textSecondary,
                )
                Chip("Разрешить доступ", actions.onRequestGalleryPermission)
                Text(
                    "Если окно разрешения не появляется, откройте настройки приложения и включите доступ к фото вручную.",
                    style = AetherType.caption,
                    color = p.textSecondary,
                )
                Chip("Настройки приложения") { actions.onAppInfo(context.packageName) }
            }
            gallery.loading && gallery.images.isEmpty() ->
                Text("Загрузка…", style = AetherType.caption, color = p.textSecondary, modifier = Modifier.padding(top = 16.dp))
            gallery.images.isEmpty() ->
                Text("Изображений не найдено.", style = AetherType.caption, color = p.textSecondary, modifier = Modifier.padding(top = 16.dp))
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                itemsIndexed(gallery.images, key = { _, img -> img.uri.toString() }) { index, img ->
                    Thumbnail(img) { viewerIndex = index }
                }
            }
        }
    }
}

@Composable
private fun Thumbnail(image: GalleryImage, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    val resolver = LocalContext.current.contentResolver
    val bitmap by produceState<ImageBitmap?>(initialValue = null, image.uri) {
        value = ImageLoader.load(resolver, image.uri, THUMB_EDGE)
    }
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(p.glassBody)
            .clickable(onClick = onClick)
    ) {
        bitmap?.let {
            Image(
                bitmap = it,
                contentDescription = image.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
    }
}

@Composable
private fun GalleryViewer(
    images: List<GalleryImage>,
    startIndex: Int,
    actions: HomeActions,
    onClose: () -> Unit,
) {
    val pagerState = rememberPagerState(initialPage = startIndex, pageCount = { images.size })
    val resolver = LocalContext.current.contentResolver

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val image = images[page]
            val bitmap by produceState<ImageBitmap?>(initialValue = null, image.uri) {
                value = ImageLoader.load(resolver, image.uri, FULL_EDGE)
            }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                bitmap?.let {
                    Image(
                        bitmap = it,
                        contentDescription = image.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                    )
                } ?: Text("…", style = AetherType.title, color = Color.White)
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ViewerButton("Закрыть", onClose)
            Text(
                "${pagerState.currentPage + 1} / ${images.size}",
                style = AetherType.caption,
                color = Color.White,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ViewerButton("Обои") { actions.onSetWallpaperFromUri(images[pagerState.currentPage].uri) }
                ViewerButton("Открыть") { actions.onOpenUri(images[pagerState.currentPage].uri) }
            }
        }
    }
}

@Composable
private fun ViewerButton(text: String, onClick: () -> Unit) {
    Text(
        text,
        style = AetherType.caption,
        color = Color.White,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}
