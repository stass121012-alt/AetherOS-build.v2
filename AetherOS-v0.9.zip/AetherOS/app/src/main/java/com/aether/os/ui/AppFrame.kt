package com.aether.os.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette

/**
 * Полноэкранная рамка встроенного приложения AETHER: заголовок, кнопка закрытия, содержимое.
 * На планшетах и в ландшафте содержимое ограничено по ширине и центрируется.
 */
@Composable
internal fun AppFrame(
    title: String,
    onClose: () -> Unit,
    closeLabel: String = "Закрыть",
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val p = LocalAetherPalette.current
    Box(
        Modifier.fillMaxSize().background(p.panel),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(title, style = AetherType.title, color = p.textPrimary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    trailing?.invoke()
                    TextButton(onClick = onClose) { Text(closeLabel, color = p.accent) }
                }
            }
            content()
        }
    }
}
