package com.aether.os.ui

import androidx.compose.runtime.Immutable
import com.aether.os.data.AppInfo

/** Элемент сетки рабочего стола: приложение или папка. */
@Immutable
sealed interface GridItem {
    val key: String

    @Immutable
    data class App(val app: AppInfo) : GridItem {
        override val key: String get() = app.packageName
    }

    @Immutable
    data class Folder(val id: String, val name: String, val apps: List<AppInfo>) : GridItem {
        override val key: String get() = "folder:$id"
    }
}
