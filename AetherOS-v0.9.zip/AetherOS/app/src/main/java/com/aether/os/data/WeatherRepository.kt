package com.aether.os.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.time.LocalDate
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Погода через Open-Meteo: бесплатно, без ключа, без геолокации (город вводит пользователь).
 * Запросы выполняются только по действию пользователя или при просмотре страницы виджетов.
 */
class WeatherRepository {

    data class GeoResult(val name: String, val lat: Double, val lon: Double)

    data class Current(val tempC: Double, val code: Int, val windKmh: Double)

    /** Success(null) — город не найден; Failure — нет сети или ошибка сервера. */
    suspend fun geocode(name: String): Result<GeoResult?> = withContext(Dispatchers.IO) {
        runCatching {
            val q = URLEncoder.encode(name.trim(), "UTF-8")
            val json = JSONObject(
                get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ru&format=json")
            )
            val results = json.optJSONArray("results")
            if (results == null || results.length() == 0) {
                null
            } else {
                val r = results.getJSONObject(0)
                GeoResult(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
            }
        }
    }

    suspend fun current(lat: Double, lon: Double): Result<Current> = withContext(Dispatchers.IO) {
        runCatching {
            val la = "%.4f".format(Locale.US, lat)
            val lo = "%.4f".format(Locale.US, lon)
            val json = JSONObject(
                get(
                    "https://api.open-meteo.com/v1/forecast?latitude=$la&longitude=$lo" +
                        "&current=temperature_2m,weather_code,wind_speed_10m&timezone=auto"
                )
            )
            val c = json.getJSONObject("current")
            Current(
                tempC = c.getDouble("temperature_2m"),
                code = c.getInt("weather_code"),
                windKmh = c.getDouble("wind_speed_10m"),
            )
        }
    }

    /** Прогноз на 5 дней (мин/макс и код погоды). */
    suspend fun forecast(lat: Double, lon: Double): Result<List<DayForecast>> = withContext(Dispatchers.IO) {
        runCatching {
            val la = "%.4f".format(Locale.US, lat)
            val lo = "%.4f".format(Locale.US, lon)
            val json = JSONObject(
                get(
                    "https://api.open-meteo.com/v1/forecast?latitude=$la&longitude=$lo" +
                        "&daily=weather_code,temperature_2m_max,temperature_2m_min&forecast_days=5&timezone=auto"
                )
            )
            val d = json.getJSONObject("daily")
            val times = d.getJSONArray("time")
            val codes = d.getJSONArray("weather_code")
            val maxs = d.getJSONArray("temperature_2m_max")
            val mins = d.getJSONArray("temperature_2m_min")
            (0 until times.length()).map { i ->
                DayForecast(
                    date = runCatching { LocalDate.parse(times.getString(i)) }.getOrNull(),
                    code = codes.getInt(i),
                    minC = mins.getDouble(i),
                    maxC = maxs.getDouble(i),
                )
            }
        }
    }

    private fun get(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = TIMEOUT_MS
            connection.readTimeout = TIMEOUT_MS
            connection.requestMethod = "GET"
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                error("HTTP ${connection.responseCode}")
            }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private companion object {
        const val TIMEOUT_MS = 8_000
    }
}

/** Описание кода погоды WMO (Open-Meteo) по-русски. */
fun describeWeatherCode(code: Int): String = when (code) {
    0 -> "Ясно"
    1 -> "Преимущественно ясно"
    2 -> "Переменная облачность"
    3 -> "Пасмурно"
    45, 48 -> "Туман"
    in 51..57 -> "Морось"
    in 61..67 -> "Дождь"
    in 71..77 -> "Снег"
    in 80..82 -> "Ливень"
    85, 86 -> "Снегопад"
    95, 96, 99 -> "Гроза"
    else -> "Без описания"
}

data class DayForecast(val date: LocalDate?, val code: Int, val minC: Double, val maxC: Double)
