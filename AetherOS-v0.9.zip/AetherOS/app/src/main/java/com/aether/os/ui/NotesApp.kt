package com.aether.os.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aether.os.data.Note
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass

/** Встроенное приложение «Заметки»: список, редактор, сохранение, удаление. */
@Composable
fun NotesApp(notes: List<Note>, actions: HomeActions, onClose: () -> Unit) {
    var editing by rememberSaveable { mutableStateOf(false) }
    var editId by rememberSaveable { mutableStateOf<Long?>(null) }
    var draft by rememberSaveable { mutableStateOf("") }

    fun finishEdit() {
        actions.onSaveAppNote(editId, draft)
        editing = false
        editId = null
        draft = ""
    }

    // Объявлен внутри HomeScreen позже его обработчика — «Назад» сначала закрывает редактор.
    BackHandler(enabled = true) { if (editing) finishEdit() else onClose() }

    if (editing) {
        NoteEditor(
            draft = draft,
            onDraftChange = { draft = it },
            canDelete = editId != null,
            onDelete = {
                editId?.let(actions.onDeleteAppNote)
                editing = false
                editId = null
                draft = ""
            },
            onDone = ::finishEdit,
        )
    } else {
        AppFrame(
            title = "Заметки",
            onClose = onClose,
            trailing = {
                Chip("+ Новая") {
                    editId = null
                    draft = ""
                    editing = true
                }
            },
        ) {
            val p = LocalAetherPalette.current
            if (notes.isEmpty()) {
                Text(
                    "Заметок пока нет. Нажмите «+ Новая».",
                    style = AetherType.caption,
                    color = p.textSecondary,
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
            LazyColumn(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(notes, key = { it.id }) { note ->
                    NoteCard(note) {
                        editId = note.id
                        draft = note.text
                        editing = true
                    }
                }
            }
        }
    }
}

@Composable
private fun NoteCard(note: Note, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    val lines = note.text.lines()
    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            lines.firstOrNull().orEmpty(),
            style = AetherType.body,
            color = p.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        val rest = lines.drop(1).joinToString(" ").trim()
        if (rest.isNotEmpty()) {
            Text(
                rest,
                style = AetherType.caption,
                color = p.textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun NoteEditor(
    draft: String,
    onDraftChange: (String) -> Unit,
    canDelete: Boolean,
    onDelete: () -> Unit,
    onDone: () -> Unit,
) {
    val p = LocalAetherPalette.current
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    AppFrame(
        title = "Заметка",
        closeLabel = "Готово",
        onClose = onDone,
        trailing = { if (canDelete) Chip("Удалить", onDelete) },
    ) {
        Box(Modifier.weight(1f).fillMaxWidth().padding(top = 12.dp)) {
            BasicTextField(
                value = draft,
                onValueChange = onDraftChange,
                textStyle = AetherType.body.copy(color = p.textPrimary),
                cursorBrush = SolidColor(p.accent),
                modifier = Modifier.fillMaxSize().focusRequester(focus),
                decorationBox = { inner ->
                    Box {
                        if (draft.isEmpty()) {
                            Text("Текст заметки. Первая строка — заголовок.", style = AetherType.body, color = p.textSecondary)
                        }
                        inner()
                    }
                },
            )
        }
    }
}
