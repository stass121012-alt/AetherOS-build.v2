package com.aether.os.ui

import android.app.Application
import android.media.Ringtone
import android.media.RingtoneManager
import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.ui.graphics.ImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aether.os.R
import com.aether.os.data.AppInfo
import com.aether.os.data.AppRepository
import com.aether.os.data.AppSettings
import com.aether.os.data.FolderData
import com.aether.os.data.LayoutPrefs
import com.aether.os.data.CalEvent
import com.aether.os.data.DayForecast
import com.aether.os.data.GalleryImage
import com.aether.os.data.LayoutStore
import com.aether.os.data.SystemAppsPrefs
import com.aether.os.data.SystemAppsStore
import com.aether.os.data.Note
import com.aether.os.data.NotesStore
import com.aether.os.data.SettingsStore
import com.aether.os.data.ThemeMode
import com.aether.os.data.WallpaperKind
import com.aether.os.data.WallpaperStore
import com.aether.os.data.WeatherPrefs
import com.aether.os.data.WeatherRepository
import com.aether.os.data.WidgetStore
import com.aether.os.data.WidgetType
import com.aether.os.design.AetherDimens
import com.aether.os.system.GalleryPermission
import com.aether.os.system.SystemControls
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class HomeState(
    val items: List<GridItem> = emptyList(),
    val dock: List<AppInfo> = emptyList(),
    val hidden: List<AppInfo> = emptyList(),
    /** Все приложения (для поиска), включая лежащие в папках и скрытые. */
    val all: List<AppInfo> = emptyList(),
    val loading: Boolean = true,
)

private const val FOLDER_PREFIX = "folder:"
private const val WEATHER_TTL_MS = 30 * 60 * 1000L
private const val MAX_NOTES = 50
private const val MAX_GALLERY_IMAGES = 500
private const val MAX_NOTE_LENGTH = 120
private const val DEFAULT_FOLDER_NAME = "Папка"
private const val MAX_FOLDER_NAME = 24

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val store = LayoutStore(application)
    private val settingsStore = SettingsStore(application)
    private val wallpaperStore = WallpaperStore(application)
    private val widgetStore = WidgetStore(application)
    private val weatherRepository = WeatherRepository()
    private val _weatherStatus = MutableStateFlow(WeatherStatus.IDLE)
    private var timerJob: Job? = null
    private var timerRingtone: Ringtone? = null

    /** Состояние виджетов, заметок, погоды и таймера оболочки. */
    val widgets: StateFlow<WidgetsState> = combine(widgetStore.prefs, _weatherStatus) { p, status ->
        WidgetsState(
            widgets = p.widgets,
            notes = p.notes,
            weather = p.weather,
            weatherStatus = status,
            timer = TimerState(p.timerEndAt, p.timerTotalMs),
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, WidgetsState())

    private val notesStore = NotesStore(application)

    /** Заметки встроенного приложения «Заметки». */
    val appNotes: StateFlow<List<Note>> = notesStore.notes
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _notificationAccess = MutableStateFlow(false)

    /** Пользователь выдал AETHER доступ к уведомлениям в системных настройках. */
    val notificationAccess: StateFlow<Boolean> = _notificationAccess.asStateFlow()

    private val systemAppsStore = SystemAppsStore(application)

    /** Данные встроенных приложений «Календарь» и «Часы». */
    val systemApps: StateFlow<SystemAppsPrefs> = systemAppsStore.prefs
        .stateIn(viewModelScope, SharingStarted.Eagerly, SystemAppsPrefs())

    private val _forecast = MutableStateFlow<List<DayForecast>>(emptyList())
    val forecast: StateFlow<List<DayForecast>> = _forecast.asStateFlow()

    private val _gallery = MutableStateFlow(GalleryState())
    val gallery: StateFlow<GalleryState> = _gallery.asStateFlow()

    /** Системные переключатели Control Center. */
    val controls = SystemControls(application)

    /** Яркость окна AETHER (0..1); null — системная. Не сохраняется между запусками. */
    private val _brightness = MutableStateFlow<Float?>(null)
    val brightness: StateFlow<Float?> = _brightness.asStateFlow()

    private val allApps = MutableStateFlow<List<AppInfo>?>(null)
    private val defaultDock = MutableStateFlow<List<String>>(emptyList())
    private var loadJob: Job? = null

    private val _wallpaperImage = MutableStateFlow<ImageBitmap?>(null)
    val wallpaperImage: StateFlow<ImageBitmap?> = _wallpaperImage.asStateFlow()

    /** Короткие сообщения для пользователя (id строковых ресурсов). */
    private val _messages = MutableSharedFlow<Int>(extraBufferCapacity = 1)
    val messages: SharedFlow<Int> = _messages.asSharedFlow()

    val state: StateFlow<HomeState> = combine(allApps, defaultDock, store.prefs) { all, def, prefs ->
        build(all, def, prefs)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HomeState())

    val settings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    init {
        refresh()
        viewModelScope.launch { _wallpaperImage.value = wallpaperStore.load() }
        refreshNotificationAccess()
        refreshGalleryAccess()
        // Если таймер был запущен до перезапуска оболочки и ещё не истёк — продолжаем отсчёт.
        viewModelScope.launch { widgetStore.prefs.first().timerEndAt?.let(::scheduleTimerAlert) }
    }

    /** Перечитывает список приложений (при установке/удалении пакетов). */
    fun refresh(debounceMs: Long = 0L) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            // Пакетные события часто приходят пачкой — склеиваем их в одно обновление.
            if (debounceMs > 0L) delay(debounceMs)
            val all = repository.loadLauncherApps()
            defaultDock.value = repository.pickDock(all, AetherDimens.dockSize).map { it.packageName }
            allApps.value = all
        }
    }

    private fun build(all: List<AppInfo>?, defDock: List<String>, p: LayoutPrefs): HomeState {
        if (all == null) return HomeState()
        val byPkg = all.associateBy { it.packageName }
        val dockPkgs = (p.dock ?: defDock)
            .filter { it in byPkg && it !in p.hidden }
            .distinct()
            .take(AetherDimens.dockSize)
        val dockSet = dockPkgs.toSet()

        val folders = p.folders.mapNotNull { f ->
            val apps = f.members
                .filter { it in byPkg && it !in p.hidden && it !in dockSet }
                .distinct()
                .map { byPkg.getValue(it) }
            if (apps.isEmpty()) null else GridItem.Folder(f.id, f.name, apps)
        }
        val inFolder = folders.flatMap { f -> f.apps.map { it.packageName } }.toSet()

        val apps = all
            .filter { it.packageName !in dockSet && it.packageName !in p.hidden && it.packageName !in inFolder }
            .map { GridItem.App(it) }

        val index = p.order.withIndex().associate { it.value to it.index }
        val items = (apps + folders).sortedBy { index[it.key] ?: Int.MAX_VALUE }

        return HomeState(
            items = items,
            dock = dockPkgs.map { byPkg.getValue(it) },
            hidden = all.filter { it.packageName in p.hidden },
            all = all,
            loading = false,
        )
    }

    // ---- внешний вид и персонализация ----

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsStore.setThemeMode(mode) }
    }

    fun setReduceMotion(value: Boolean) {
        viewModelScope.launch { settingsStore.setReduceMotion(value) }
    }

    fun setIconSize(dp: Int) {
        viewModelScope.launch { settingsStore.setIconSize(dp) }
    }

    fun setColumns(value: Int) {
        viewModelScope.launch { settingsStore.setColumns(value) }
    }

    fun setRows(value: Int) {
        viewModelScope.launch { settingsStore.setRows(value) }
    }

    fun setShowLabels(value: Boolean) {
        viewModelScope.launch { settingsStore.setShowLabels(value) }
    }

    fun setWallpaper(kind: WallpaperKind, preset: Int) {
        viewModelScope.launch {
            if (kind == WallpaperKind.IMAGE && _wallpaperImage.value == null) return@launch
            settingsStore.setWallpaper(kind, preset)
        }
    }

    fun setWallpaperFromUri(uri: Uri) {
        viewModelScope.launch {
            val bitmap = wallpaperStore.saveFromUri(uri)
            if (bitmap == null) {
                _messages.tryEmit(R.string.wallpaper_failed)
            } else {
                _wallpaperImage.value = bitmap
                settingsStore.setWallpaper(WallpaperKind.IMAGE, settings.value.wallpaperPreset)
                _messages.tryEmit(R.string.wallpaper_set)
            }
        }
    }

    fun removeWallpaperImage() {
        viewModelScope.launch {
            wallpaperStore.delete()
            _wallpaperImage.value = null
            val s = settings.value
            if (s.wallpaperKind == WallpaperKind.IMAGE) {
                settingsStore.setWallpaper(WallpaperKind.AMBIENT, s.wallpaperPreset)
            }
        }
    }

    fun resetPersonalization() {
        viewModelScope.launch {
            wallpaperStore.delete()
            _wallpaperImage.value = null
            settingsStore.resetPersonalization()
        }
    }

    // ---- заметки и уведомления ----

    /** Создаёт заметку ([id] == null) или обновляет существующую; пустой текст удаляет заметку. */
    fun saveAppNote(id: Long?, text: String) {
        viewModelScope.launch {
            val list = notesStore.notes.first()
            val clean = text.trimEnd()
            val now = System.currentTimeMillis()
            val updated = when {
                id == null -> if (clean.isBlank()) list else listOf(Note(now, clean, now)) + list
                clean.isBlank() -> list.filter { it.id != id }
                else -> list
                    .map { if (it.id == id) it.copy(text = clean, updatedAt = now) else it }
                    .sortedByDescending { it.updatedAt }
            }
            notesStore.save(updated)
        }
    }

    fun deleteAppNote(id: Long) {
        viewModelScope.launch {
            notesStore.save(notesStore.notes.first().filter { it.id != id })
        }
    }

    /** Вызывается при возврате из системных настроек, где пользователь мог выдать или отозвать доступ. */
    fun refreshNotificationAccess() {
        val app = getApplication<Application>()
        _notificationAccess.value =
            NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName)
    }

    // ---- системные приложения: календарь, часы, погода, галерея ----

    fun saveEvent(event: CalEvent) {
        viewModelScope.launch {
            val p = systemAppsStore.prefs.first()
            systemAppsStore.setEvents(p.events.filter { it.id != event.id } + event)
        }
    }

    fun deleteEvent(id: Long) {
        viewModelScope.launch {
            val p = systemAppsStore.prefs.first()
            systemAppsStore.setEvents(p.events.filter { it.id != id })
        }
    }

    fun setWorldZones(zones: List<String>) {
        viewModelScope.launch { systemAppsStore.setZones(zones.distinct()) }
    }

    /** Загружает прогноз на 5 дней для выбранного города (хранится только в памяти). */
    fun loadForecast() {
        viewModelScope.launch {
            val w = widgetStore.prefs.first().weather ?: return@launch
            weatherRepository.forecast(w.lat, w.lon)
                .onSuccess { _forecast.value = it }
                .onFailure { _weatherStatus.value = WeatherStatus.OFFLINE }
        }
    }

    fun refreshGalleryAccess() {
        val granted = GalleryPermission.granted(getApplication())
        _gallery.update { it.copy(hasAccess = granted, images = if (granted) it.images else emptyList()) }
    }

    fun loadGallery() {
        viewModelScope.launch {
            if (!GalleryPermission.granted(getApplication())) {
                _gallery.update { it.copy(hasAccess = false, images = emptyList(), loading = false) }
                return@launch
            }
            _gallery.update { it.copy(hasAccess = true, loading = true) }
            val images = withContext(Dispatchers.IO) { queryImages() }
            _gallery.update { it.copy(images = images, loading = false) }
        }
    }

    private fun queryImages(): List<GalleryImage> {
        val resolver = getApplication<Application>().contentResolver
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED,
        )
        val result = ArrayList<GalleryImage>()
        try {
            resolver.query(collection, projection, null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")
                ?.use { c ->
                    val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    while (c.moveToNext() && result.size < MAX_GALLERY_IMAGES) {
                        result += GalleryImage(
                            uri = ContentUris.withAppendedId(collection, c.getLong(idCol)),
                            name = c.getString(nameCol).orEmpty(),
                            dateAdded = c.getLong(dateCol),
                        )
                    }
                }
        } catch (e: SecurityException) {
            // Разрешение отозвано во время чтения — вернём то, что успели прочитать.
        }
        return result
    }

    // ---- виджеты, погода, таймер ----

    fun addWidget(type: WidgetType) {
        viewModelScope.launch {
            val p = widgetStore.prefs.first()
            if (type !in p.widgets) widgetStore.setWidgets(p.widgets + type)
        }
    }

    fun removeWidget(type: WidgetType) {
        viewModelScope.launch {
            val p = widgetStore.prefs.first()
            widgetStore.setWidgets(p.widgets - type)
        }
    }

    fun addNote(text: String) {
        viewModelScope.launch {
            val clean = text.trim().replace('\n', ' ').take(MAX_NOTE_LENGTH)
            if (clean.isEmpty()) return@launch
            val p = widgetStore.prefs.first()
            widgetStore.setNotes((listOf(clean) + p.notes).take(MAX_NOTES))
        }
    }

    fun deleteNote(index: Int) {
        viewModelScope.launch {
            val p = widgetStore.prefs.first()
            if (index !in p.notes.indices) return@launch
            widgetStore.setNotes(p.notes.filterIndexed { i, _ -> i != index })
        }
    }

    fun setWeatherCity(name: String) {
        viewModelScope.launch {
            val query = name.trim()
            if (query.isEmpty()) return@launch
            _weatherStatus.value = WeatherStatus.LOADING
            val place = weatherRepository.geocode(query).getOrElse {
                _weatherStatus.value = WeatherStatus.OFFLINE
                return@launch
            }
            if (place == null) {
                _weatherStatus.value = WeatherStatus.NOT_FOUND
                return@launch
            }
            widgetStore.setWeather(WeatherPrefs(place.name, place.lat, place.lon, null, null, null, 0L))
            loadWeather(place.lat, place.lon, place.name)
        }
    }

    fun refreshWeather(force: Boolean) {
        viewModelScope.launch {
            val w = widgetStore.prefs.first().weather ?: return@launch
            val fresh = w.tempC != null && System.currentTimeMillis() - w.updatedAt < WEATHER_TTL_MS
            if (!force && fresh) return@launch
            if (_weatherStatus.value == WeatherStatus.LOADING) return@launch
            _weatherStatus.value = WeatherStatus.LOADING
            loadWeather(w.lat, w.lon, w.city)
        }
    }

    private suspend fun loadWeather(lat: Double, lon: Double, city: String) {
        val current = weatherRepository.current(lat, lon).getOrNull()
        if (current == null) {
            _weatherStatus.value = WeatherStatus.OFFLINE
            return
        }
        widgetStore.setWeather(
            WeatherPrefs(city, lat, lon, current.tempC, current.code, current.windKmh, System.currentTimeMillis())
        )
        _weatherStatus.value = WeatherStatus.IDLE
    }

    fun startTimer(minutes: Int) {
        viewModelScope.launch {
            stopTimerAlert()
            val total = minutes.coerceIn(1, 180) * 60_000L
            val end = System.currentTimeMillis() + total
            widgetStore.setTimer(end, total)
            scheduleTimerAlert(end)
        }
    }

    fun cancelTimer() {
        viewModelScope.launch {
            timerJob?.cancel()
            stopTimerAlert()
            widgetStore.setTimer(null, 0L)
        }
    }

    private fun scheduleTimerAlert(endAt: Long) {
        timerJob?.cancel()
        val wait = endAt - System.currentTimeMillis()
        if (wait <= 0L) return
        timerJob = viewModelScope.launch {
            delay(wait)
            playTimerAlert()
        }
    }

    /** Сигнал окончания таймера: вибрация и мелодия будильника. Работает, пока процесс AETHER жив. */
    private fun playTimerAlert() {
        stopTimerAlert()
        val app = getApplication<Application>()
        app.getSystemService(Vibrator::class.java)
            ?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 250, 500, 250, 500), -1))
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        timerRingtone = RingtoneManager.getRingtone(app, uri)?.also { it.play() }
    }

    private fun stopTimerAlert() {
        timerRingtone?.stop()
        timerRingtone = null
    }

    // ---- Control Center ----

    fun setBrightness(value: Float) {
        _brightness.value = value.coerceIn(0.02f, 1f)
    }

    fun resetBrightness() {
        _brightness.value = null
    }

    override fun onCleared() {
        controls.stop()
        stopTimerAlert()
        super.onCleared()
    }

    // ---- док и скрытые приложения ----

    fun toggleDock(pkg: String) {
        viewModelScope.launch {
            val cur = state.value.dock.map { it.packageName }
            val next = when {
                pkg in cur -> cur - pkg
                cur.size < AetherDimens.dockSize -> cur + pkg
                else -> return@launch
            }
            store.setDock(next)
        }
    }

    fun hide(pkg: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            store.setHidden(p.hidden + pkg)
            val dock = state.value.dock.map { it.packageName }
            if (pkg in dock) store.setDock(dock - pkg)
        }
    }

    fun unhide(pkg: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            store.setHidden(p.hidden - pkg)
        }
    }

    fun unhideAll() {
        viewModelScope.launch { store.setHidden(emptySet()) }
    }

    fun resetDock() {
        viewModelScope.launch { store.setDock(null) }
    }

    // ---- порядок сетки и папки ----

    private fun currentKeys(): MutableList<String> = state.value.items.map { it.key }.toMutableList()

    /** Переносит элемент на позицию [toIndex] итогового списка. */
    fun reorder(key: String, toIndex: Int) {
        viewModelScope.launch {
            val keys = currentKeys()
            val from = keys.indexOf(key)
            if (from < 0) return@launch
            keys.removeAt(from)
            keys.add(toIndex.coerceIn(0, keys.size), key)
            store.setOrder(keys)
        }
    }

    /** Сдвигает элемент на [delta] позиций (через границы страниц). */
    fun moveBy(key: String, delta: Int) {
        val i = state.value.items.indexOfFirst { it.key == key }
        if (i >= 0) reorder(key, i + delta)
    }

    /** Создаёт папку на месте [target] и кладёт туда [dragged]. */
    fun createFolder(dragged: String, target: String) {
        viewModelScope.launch {
            if (dragged == target) return@launch
            val p = store.prefs.first()
            val keys = currentKeys()
            val ti = keys.indexOf(target)
            if (ti < 0 || dragged !in keys) return@launch
            val id = UUID.randomUUID().toString().take(8)
            keys[ti] = FOLDER_PREFIX + id
            keys.remove(dragged)
            store.update(keys, p.folders + FolderData(id, DEFAULT_FOLDER_NAME, listOf(target, dragged)))
        }
    }

    fun addToFolder(pkg: String, folderId: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            if (p.folders.none { it.id == folderId }) return@launch
            val keys = currentKeys()
            keys.remove(pkg)
            val folders = p.folders.map {
                if (it.id == folderId && pkg !in it.members) it.copy(members = it.members + pkg) else it
            }
            store.update(keys, folders)
        }
    }

    fun removeFromFolder(pkg: String, folderId: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            val folder = p.folders.firstOrNull { it.id == folderId } ?: return@launch
            val remaining = folder.members.filter { it != pkg }
            val keys = currentKeys()
            val pos = keys.indexOf(FOLDER_PREFIX + folderId)
            if (remaining.size < 2) {
                // Папка из одного приложения не нужна: расформировываем на месте.
                if (pos >= 0) {
                    keys.removeAt(pos)
                    keys.addAll(pos, remaining + pkg)
                }
                store.update(keys, p.folders.filter { it.id != folderId })
            } else {
                if (pos >= 0) keys.add((pos + 1).coerceAtMost(keys.size), pkg)
                store.update(
                    keys,
                    p.folders.map { if (it.id == folderId) it.copy(members = remaining) else it },
                )
            }
        }
    }

    fun renameFolder(folderId: String, name: String) {
        viewModelScope.launch {
            val clean = name.trim().take(MAX_FOLDER_NAME)
            if (clean.isEmpty()) return@launch
            val p = store.prefs.first()
            val folder = p.folders.firstOrNull { it.id == folderId } ?: return@launch
            if (folder.name == clean) return@launch
            store.update(
                currentKeys(),
                p.folders.map { if (it.id == folderId) it.copy(name = clean) else it },
            )
        }
    }

    fun dissolveFolder(folderId: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            val item = state.value.items
                .filterIsInstance<GridItem.Folder>()
                .firstOrNull { it.id == folderId }
            val keys = currentKeys()
            val pos = keys.indexOf(FOLDER_PREFIX + folderId)
            if (pos >= 0) {
                keys.removeAt(pos)
                keys.addAll(pos, item?.apps?.map { it.packageName }.orEmpty())
            }
            store.update(keys, p.folders.filter { it.id != folderId })
        }
    }
}

enum class WeatherStatus { IDLE, LOADING, OFFLINE, NOT_FOUND }

/** endAt — время окончания (мс, wall clock) или null, если таймер не запущен. */
data class TimerState(val endAt: Long? = null, val totalMs: Long = 0L)

data class WidgetsState(
    val widgets: List<WidgetType> = emptyList(),
    val notes: List<String> = emptyList(),
    val weather: WeatherPrefs? = null,
    val weatherStatus: WeatherStatus = WeatherStatus.IDLE,
    val timer: TimerState = TimerState(),
)

/** Состояние встроенной «Галереи»: доступ к фото и список изображений (только в памяти). */
data class GalleryState(
    val hasAccess: Boolean = false,
    val images: List<GalleryImage> = emptyList(),
    val loading: Boolean = false,
)
