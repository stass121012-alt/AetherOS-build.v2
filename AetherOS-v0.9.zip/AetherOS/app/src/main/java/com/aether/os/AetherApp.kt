package com.aether.os

import android.app.Application
import java.io.File

/**
 * Защита от цикла сбоев: домашний экран, который падает при каждом запуске, делает телефон
 * практически неуправляемым. Если за две минуты случилось три падения, при следующем запуске
 * сбрасываются только раскладка, настройки и обои. Заметки, события календаря и виджеты не трогаются.
 */
class AetherApp : Application() {

    /** true, если при этом запуске были сброшены раскладка и настройки. */
    var safeModeReset: Boolean = false
        private set

    override fun onCreate() {
        super.onCreate()
        val prefs = getSharedPreferences(CRASH_PREFS, MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val recent = parse(prefs.getString(KEY_TIMES, "")).filter { now - it < WINDOW_MS }
        if (recent.size >= CRASH_LIMIT) {
            resetLayoutAndSettings()
            prefs.edit().remove(KEY_TIMES).apply()
            safeModeReset = true
        } else {
            prefs.edit().putString(KEY_TIMES, recent.joinToString(",")).apply()
        }

        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            recordCrash()
            previous?.uncaughtException(thread, error)
        }
    }

    private fun recordCrash() {
        val prefs = getSharedPreferences(CRASH_PREFS, MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val times = parse(prefs.getString(KEY_TIMES, "")).filter { now - it < WINDOW_MS } + now
        prefs.edit().putString(KEY_TIMES, times.joinToString(",")).commit()
    }

    private fun resetLayoutAndSettings() {
        val dir = File(filesDir, "datastore")
        File(dir, "aether_layout.preferences_pb").delete()
        File(dir, "aether_settings.preferences_pb").delete()
        File(filesDir, "wallpaper.jpg").delete()
    }

    private fun parse(s: String?): List<Long> =
        s.orEmpty().split(",").mapNotNull { it.trim().toLongOrNull() }

    private companion object {
        const val CRASH_PREFS = "aether_crash_guard"
        const val KEY_TIMES = "times"
        const val CRASH_LIMIT = 3
        const val WINDOW_MS = 2 * 60 * 1000L
    }
}
