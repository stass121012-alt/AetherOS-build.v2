package com.aether.os.ui

import com.aether.os.data.AppInfo
import java.util.Locale

internal enum class SettingsTarget { SETTINGS, PERSONALIZATION, CONTROL, NOTIFICATIONS }

internal data class SettingsEntry(
    val title: String,
    val subtitle: String,
    val keywords: List<String>,
    val target: SettingsTarget,
)

/** Индекс настроек оболочки, по которым работает AETHER Search. */
internal val SettingsIndex = listOf(
    SettingsEntry("Персонализация", "Раздел настроек", listOf("персонализация", "personalization"), SettingsTarget.PERSONALIZATION),
    SettingsEntry("Тема", "Персонализация", listOf("тема", "светлая", "темная", "тёмная", "theme", "dark", "light"), SettingsTarget.PERSONALIZATION),
    SettingsEntry("Обои", "Персонализация", listOf("обои", "фон", "фото", "градиент", "wallpaper"), SettingsTarget.PERSONALIZATION),
    SettingsEntry("Сетка и размер иконок", "Персонализация", listOf("сетка", "иконки", "колонки", "строки", "размер", "подписи", "grid", "icon"), SettingsTarget.PERSONALIZATION),
    SettingsEntry("Control Center", "Быстрые настройки", listOf("control center", "центр управления", "быстрые настройки", "яркость", "громкость", "звук", "фонарик", "wi-fi", "wifi", "bluetooth", "авиарежим", "не беспокоить", "dnd", "flashlight"), SettingsTarget.CONTROL),
    SettingsEntry("Уведомления", "Центр уведомлений", listOf("уведомления", "центр уведомлений", "notifications"), SettingsTarget.NOTIFICATIONS),
    SettingsEntry("Анимации", "Настройки", listOf("анимации", "анимация", "движение", "animation", "motion"), SettingsTarget.SETTINGS),
    SettingsEntry("Док", "Настройки", listOf("док", "dock", "сброс"), SettingsTarget.SETTINGS),
    SettingsEntry("Скрытые приложения", "Настройки", listOf("скрытые", "скрыть", "hidden"), SettingsTarget.SETTINGS),
    SettingsEntry("Управление и жесты", "Справка", listOf("управление", "жесты", "справка", "помощь", "help"), SettingsTarget.SETTINGS),
    SettingsEntry("О системе", "Настройки", listOf("о системе", "версия", "устройство", "about", "version"), SettingsTarget.SETTINGS),
)

private fun normalize(s: String): String =
    s.trim().lowercase(Locale.getDefault()).replace('ё', 'е')

internal fun matchApps(query: String, apps: List<AppInfo>): List<AppInfo> {
    val q = normalize(query)
    if (q.isEmpty()) return emptyList()
    return apps
        .filter { normalize(it.label).contains(q) }
        .sortedWith(
            compareBy<AppInfo>(
                { !normalize(it.label).startsWith(q) },
                { normalize(it.label) },
            )
        )
}

internal fun matchSettings(query: String): List<SettingsEntry> {
    val q = normalize(query)
    if (q.isEmpty()) return emptyList()
    return SettingsIndex.filter { e ->
        normalize(e.title).contains(q) || e.keywords.any { normalize(it).contains(q) }
    }
}
