package com.aether.os.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.os.data.DayForecast
import com.aether.os.data.describeWeatherCode
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt
import java.time.format.TextStyle as DateTextStyle

/** Встроенное приложение «Погода»: текущая погода и прогноз на 5 дней (Open-Meteo, нужен интернет). */
@Composable
fun WeatherApp(
    state: WidgetsState,
    forecast: List<DayForecast>,
    actions: HomeActions,
    onClose: () -> Unit,
) {
    val p = LocalAetherPalette.current
    val weather = state.weather
    var cityInput by rememberSaveable { mutableStateOf("") }
    var editing by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(weather?.city) {
        editing = false
        if (weather != null) {
            actions.onRefreshWeather(false)
            actions.onLoadForecast()
        }
    }

    AppFrame(title = "Погода", onClose = onClose) {
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (weather == null || editing) {
                InputRow(
                    value = cityInput,
                    onValueChange = { cityInput = it.take(60) },
                    placeholder = "Город",
                    action = "Найти",
                    onSubmit = { actions.onSetWeatherCity(cityInput) },
                )
                WeatherStatusLine(state.weatherStatus, hasData = false)
                Text(
                    "Данные Open-Meteo. Геолокация не используется: город вводится вручную. " +
                        "Интернет нужен только для запросов погоды.",
                    style = AetherType.caption,
                    color = p.textSecondary,
                )
            } else {
                val temp = weather.tempC
                Text(weather.city, style = AetherType.title, color = p.textPrimary)
                if (temp != null) {
                    Text("${temp.roundToInt()}°", style = AetherType.clock.copy(fontSize = 88.sp), color = p.textPrimary)
                    Text(
                        describeWeatherCode(weather.code ?: -1) +
                            (weather.windKmh?.let { " · ветер ${it.roundToInt()} км/ч" } ?: ""),
                        style = AetherType.body,
                        color = p.textSecondary,
                    )
                    if (weather.updatedAt > 0L) {
                        val time = Instant.ofEpochMilli(weather.updatedAt).atZone(ZoneId.systemDefault())
                            .format(DateTimeFormatter.ofPattern("HH:mm"))
                        Text("Обновлено в $time", style = AetherType.caption, color = p.textSecondary)
                    }
                }
                WeatherStatusLine(state.weatherStatus, hasData = temp != null)

                if (forecast.isNotEmpty()) {
                    Text("ПРОГНОЗ", style = AetherType.section, color = p.accent, modifier = Modifier.padding(top = 12.dp))
                    forecast.forEach { day ->
                        val name = day.date?.dayOfWeek?.getDisplayName(DateTextStyle.SHORT, Locale.getDefault())
                            ?.replaceFirstChar { it.titlecase(Locale.getDefault()) } ?: "—"
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(name, style = AetherType.body, color = p.textPrimary, modifier = Modifier.weight(0.5f))
                            Text(describeWeatherCode(day.code), style = AetherType.caption, color = p.textSecondary, modifier = Modifier.weight(1.2f))
                            Text(
                                "${day.minC.roundToInt()}° / ${day.maxC.roundToInt()}°",
                                style = AetherType.body,
                                color = p.textPrimary,
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Chip("Обновить") {
                        actions.onRefreshWeather(true)
                        actions.onLoadForecast()
                    }
                    Chip("Сменить город") { editing = true }
                }
            }
        }
    }
}
