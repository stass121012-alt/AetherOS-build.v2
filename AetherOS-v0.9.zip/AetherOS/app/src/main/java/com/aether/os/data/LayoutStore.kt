package com.aether.os.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.layoutDataStore by preferencesDataStore(name = "aether_layout")

/** Папка на рабочем столе. В порядке сетки она представлена ключом "folder:<id>". */
data class FolderData(val id: String, val name: String, val members: List<String>)

/**
 * Сохранённая раскладка рабочего стола.
 * dock == null — пользователь ещё не менял док, используется набор по умолчанию.
 * order — ключи элементов сетки: пакет приложения или "folder:<id>".
 */
data class LayoutPrefs(
    val dock: List<String>?,
    val hidden: Set<String>,
    val order: List<String>,
    val folders: List<FolderData>,
)

class LayoutStore(private val context: Context) {

    private val kDock = stringPreferencesKey("dock")
    private val kHidden = stringSetPreferencesKey("hidden")
    private val kOrder = stringPreferencesKey("order")
    private val kFolders = stringPreferencesKey("folders")

    val prefs: Flow<LayoutPrefs> = context.layoutDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            LayoutPrefs(
                dock = p[kDock]?.let(::decodeList),
                hidden = p[kHidden] ?: emptySet(),
                order = p[kOrder]?.let(::decodeList) ?: emptyList(),
                folders = p[kFolders]?.let(::decodeFolders) ?: emptyList(),
            )
        }

    suspend fun setDock(list: List<String>?) {
        context.layoutDataStore.edit { p ->
            if (list == null) p.remove(kDock) else p[kDock] = encodeList(list)
        }
    }

    suspend fun setHidden(set: Set<String>) {
        context.layoutDataStore.edit { p -> p[kHidden] = set }
    }

    suspend fun setOrder(list: List<String>) {
        context.layoutDataStore.edit { p -> p[kOrder] = encodeList(list) }
    }

    /** Атомарно сохраняет порядок сетки и список папок (одна запись — одно обновление UI). */
    suspend fun update(order: List<String>, folders: List<FolderData>) {
        context.layoutDataStore.edit { p ->
            p[kOrder] = encodeList(order)
            p[kFolders] = encodeFolders(folders)
        }
    }

    private fun encodeList(list: List<String>) = list.joinToString("\n")
    private fun decodeList(s: String) = s.split("\n").filter { it.isNotBlank() }

    private fun encodeFolders(list: List<FolderData>): String =
        list.joinToString("\n") { f ->
            val safeName = f.name.replace('\t', ' ').replace('\n', ' ')
            "${f.id}\t$safeName\t${f.members.joinToString(",")}"
        }

    private fun decodeFolders(s: String): List<FolderData> =
        s.split("\n").mapNotNull { line ->
            val parts = line.split("\t", limit = 3)
            if (parts.size < 3 || parts[0].isBlank()) {
                null
            } else {
                FolderData(
                    id = parts[0],
                    name = parts[1],
                    members = parts[2].split(",").filter { it.isNotBlank() },
                )
            }
        }
}
