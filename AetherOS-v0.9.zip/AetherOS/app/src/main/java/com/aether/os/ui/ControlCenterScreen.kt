package com.aether.os.ui

import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.design.aetherSpring
import com.aether.os.system.SystemControls
import com.aether.os.system.SystemTarget
import kotlin.math.roundToInt

private const val TILE_COLUMNS = 3
private const val SWIPE_UP_THRESHOLD_PX = 80f

private class Tile(
    val title: String,
    val subtitle: String,
    val active: Boolean,
    val enabled: Boolean = true,
    val onClick: () -> Unit,
)

/**
 * AETHER Control Center.
 * Полноценно: фонарик, громкость мультимедиа, «Не беспокоить» (при выданном доступе).
 * Ограниченно API Android: яркость (только окно AETHER), Wi-Fi / Bluetooth / авиарежим /
 * будильник (открывают системные экраны; состояние Wi-Fi и авиарежима читается).
 */
@Composable
fun ControlCenterScreen(
    controls: SystemControls,
    brightness: Float?,
    actions: HomeActions,
    onClose: () -> Unit,
) {
    val p = LocalAetherPalette.current
    val cs by controls.state.collectAsStateWithLifecycle()
    val backdropSource = remember { MutableInteractionSource() }
    val cardSource = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
    var liveBrightness by remember { mutableFloatStateOf(brightness ?: controls.systemBrightness()) }

    // Слушатели системных событий работают только пока Control Center открыт.
    DisposableEffect(controls) {
        controls.start()
        onDispose { controls.stop() }
    }
    LaunchedEffect(brightness) {
        if (brightness == null) liveBrightness = controls.systemBrightness()
    }

    fun onOff(on: Boolean) = if (on) "Вкл" else "Выкл"

    val tiles = listOf(
        Tile("Wi‑Fi", cs.wifiOn?.let(::onOff) ?: "—", cs.wifiOn == true) {
            actions.onOpenSystem(SystemTarget.WIFI)
        },
        Tile("Bluetooth", "Настройки", false) {
            actions.onOpenSystem(SystemTarget.BLUETOOTH)
        },
        Tile("Авиарежим", onOff(cs.airplaneOn), cs.airplaneOn) {
            actions.onOpenSystem(SystemTarget.AIRPLANE)
        },
        Tile(
            title = "Фонарик",
            subtitle = if (cs.torchAvailable) onOff(cs.torchOn) else "Нет",
            active = cs.torchOn,
            enabled = cs.torchAvailable,
        ) { controls.toggleTorch() },
        Tile(
            title = "Не беспокоить",
            subtitle = if (cs.dndAccess) onOff(cs.dndOn) else "Нужен доступ",
            active = cs.dndAccess && cs.dndOn,
        ) {
            if (!controls.toggleDnd()) actions.onOpenSystem(SystemTarget.DND_ACCESS)
        },
        Tile("Будильник", "Открыть", false) {
            actions.onOpenSystem(SystemTarget.ALARMS)
        },
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .clickable(interactionSource = backdropSource, indication = null, onClick = onClose)
    ) {
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 600.dp)
                .fillMaxWidth()
                .clip(shape)
                .background(p.panel)
                .border(1.dp, Brush.verticalGradient(listOf(p.glassEdgeLight, p.glassEdgeDim)), shape)
                .clickable(interactionSource = cardSource, indication = null) { }
                .pointerInput(Unit) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onVerticalDrag = { _, dy -> total += dy },
                        onDragEnd = { if (total < -SWIPE_UP_THRESHOLD_PX) onClose() },
                    )
                }
                .statusBarsPadding()
                .heightIn(max = (LocalConfiguration.current.screenHeightDp * 0.95f).dp)
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Control Center", style = AetherType.title, color = p.textPrimary)

            tiles.chunked(TILE_COLUMNS).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { ControlTile(it, Modifier.weight(1f)) }
                    repeat(TILE_COLUMNS - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            ControlSlider(
                title = "Яркость",
                valueText = "${(liveBrightness * 100).roundToInt()}%",
                value = liveBrightness,
                range = 0.02f..1f,
                steps = 0,
                onChange = {
                    liveBrightness = it
                    actions.onSetBrightness(it)
                },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (brightness != null) {
                    TextButton(onClick = actions.onResetBrightness) {
                        Text("Вернуть системную яркость", color = p.accent)
                    }
                } else {
                    TextButton(onClick = { actions.onOpenSystem(SystemTarget.DISPLAY) }) {
                        Text("Настройки экрана", color = p.accent)
                    }
                }
            }

            ControlSlider(
                title = "Громкость мультимедиа",
                valueText = "${cs.volume * 100 / cs.volumeMax}%",
                value = cs.volume.toFloat(),
                range = 0f..cs.volumeMax.toFloat(),
                steps = (cs.volumeMax - 1).coerceAtLeast(0),
                onChange = { controls.setVolume(it.roundToInt()) },
            )

            Text(
                "Android не позволяет обычным приложениям переключать Wi‑Fi, Bluetooth и авиарежим — " +
                    "эти плитки открывают системные настройки. Яркость действует только на экран AETHER.",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun ControlTile(tile: Tile, modifier: Modifier = Modifier) {
    val p = LocalAetherPalette.current
    val shape = RoundedCornerShape(AetherDimens.radiusSmall + 4.dp)
    val bg by animateColorAsState(
        targetValue = if (tile.active) p.accent.copy(alpha = 0.30f) else Color.Transparent,
        animationSpec = aetherSpring(),
        label = "tileBg",
    )
    Column(
        modifier
            .aetherGlass(shape)
            .background(bg)
            .clickable(enabled = tile.enabled, onClick = tile.onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Text(
            tile.title,
            style = AetherType.body,
            color = if (tile.enabled) p.textPrimary else p.textSecondary.copy(alpha = 0.5f),
            maxLines = 1,
        )
        Text(
            tile.subtitle,
            style = AetherType.caption,
            color = if (tile.active) p.textPrimary else p.textSecondary,
            maxLines = 1,
        )
    }
}

@Composable
private fun ControlSlider(
    title: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    onChange: (Float) -> Unit,
) {
    val p = LocalAetherPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, style = AetherType.body, color = p.textPrimary)
            Text(valueText, style = AetherType.body, color = p.accent)
        }
        Slider(
            value = value.coerceIn(range),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = p.accent,
                activeTrackColor = p.accent,
                inactiveTrackColor = p.textSecondary.copy(alpha = 0.25f),
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent,
            ),
        )
    }
}
