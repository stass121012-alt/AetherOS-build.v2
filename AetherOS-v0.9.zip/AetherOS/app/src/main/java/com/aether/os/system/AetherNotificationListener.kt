package com.aether.os.system

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Системный сервис чтения уведомлений. Начинает работать только после явной выдачи
 * доступа пользователем (Настройки → Доступ к уведомлениям) и перестаёт при отзыве.
 * Читает название и текст, не сохраняет их на диск и никуда не отправляет.
 * Уведомления самого AETHER, текущие процессы (ongoing) и сводки групп пропускаются.
 */
class AetherNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationHub.attach(this)
        val active = try {
            activeNotifications?.mapNotNull { convert(it) } ?: emptyList()
        } catch (e: SecurityException) {
            emptyList()
        }
        NotificationHub.replaceAll(active)
    }

    override fun onListenerDisconnected() {
        NotificationHub.detach(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val item = convert(sbn)
        if (item != null) NotificationHub.upsert(item) else NotificationHub.remove(sbn.key)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        NotificationHub.remove(sbn.key)
    }

    private fun convert(sbn: StatusBarNotification): NotifItem? {
        if (sbn.packageName == packageName) return null
        val n = sbn.notification ?: return null
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        if (sbn.isOngoing) return null

        val extras = n.extras
        val title = extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras?.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return null

        return NotifItem(
            key = sbn.key,
            pkg = sbn.packageName,
            appLabel = labelFor(sbn.packageName),
            title = title,
            text = text,
            postTime = sbn.postTime,
            clearable = sbn.isClearable,
            intent = n.contentIntent,
        )
    }

    private fun labelFor(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }
}
