package com.aether.os.ui

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppInfo
import com.aether.os.data.AppSettings
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass

const val AETHER_VERSION = "0.9.0"

/** Экран настроек оболочки. Открывается долгим нажатием на часы. */
@Composable
fun SettingsScreen(
    settings: AppSettings,
    hidden: List<AppInfo>,
    actions: HomeActions,
    onOpenPersonalization: () -> Unit,
    onOpenHelp: () -> Unit,
    onClose: () -> Unit,
) {
    SheetScaffold(
        title = "Настройки AETHER",
        subtitle = "AETHER OS $AETHER_VERSION · оболочка Android",
        onClose = onClose,
    ) {
        item { SectionTitle("ВНЕШНИЙ ВИД") }
        item {
            ActionRow(
                title = "Персонализация",
                subtitle = "Тема, обои, сетка и размер иконок",
                onClick = onOpenPersonalization,
            )
        }
        item {
            SwitchRow(
                title = "Уменьшить анимации",
                subtitle = "Без пружин и масштабирования, мгновенная смена тем",
                checked = settings.reduceMotion,
                onChange = actions.onReduceMotion,
            )
        }

        item { SectionTitle("РАБОЧИЙ СТОЛ") }
        item {
            ActionRow(
                title = "Сбросить док",
                subtitle = "Телефон, сообщения, браузер и камера по умолчанию",
                onClick = actions.onResetDock,
            )
        }

        item { SectionTitle("СКРЫТЫЕ ПРИЛОЖЕНИЯ (${hidden.size})") }
        if (hidden.isEmpty()) {
            item {
                val p = LocalAetherPalette.current
                Text(
                    "Нет скрытых приложений. Долгое нажатие на иконку → «Скрыть».",
                    style = AetherType.caption,
                    color = p.textSecondary,
                )
            }
        } else {
            items(hidden, key = { it.packageName }) { app ->
                HiddenRow(app, onShow = { actions.onUnhide(app.packageName) })
            }
            item { ActionRow("Показать все", null, actions.onUnhideAll) }
        }

        item { SectionTitle("СПРАВКА") }
        item { ActionRow("Управление", "Жесты и действия AETHER OS", onOpenHelp) }

        item { SectionTitle("О СИСТЕМЕ") }
        item { InfoRow("Оболочка", "AETHER OS $AETHER_VERSION") }
        item { InfoRow("Тип", "Приложение-оболочка (APK), не прошивка") }
        item { InfoRow("Устройство", "${Build.MANUFACTURER} ${Build.MODEL}") }
        item { InfoRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})") }

        item { Spacer(Modifier.height(8.dp)) }
        item { ActionRow("Закрыть", null, onClose) }
    }
}

@Composable
private fun HiddenRow(app: AppInfo, onShow: () -> Unit) {
    val p = LocalAetherPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(36.dp))
        Text(
            app.label,
            style = AetherType.body,
            color = p.textPrimary,
            maxLines = 1,
            modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
        )
        TextButton(onClick = onShow) { Text("Показать", color = p.accent) }
    }
}
