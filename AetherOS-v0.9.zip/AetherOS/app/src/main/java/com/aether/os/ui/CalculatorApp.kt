package com.aether.os.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass

private val Keys = listOf(
    listOf("C", "⌫", "%", "÷"),
    listOf("7", "8", "9", "×"),
    listOf("4", "5", "6", "−"),
    listOf("1", "2", "3", "+"),
    listOf("±", "0", ".", "="),
)

private fun isAccentKey(key: String) = key in listOf("÷", "×", "−", "+", "=")

/** Встроенный калькулятор AETHER: полноценная логика, состояние сохраняется при повороте. */
@Composable
fun CalculatorApp(onClose: () -> Unit) {
    val p = LocalAetherPalette.current
    var expr by rememberSaveable { mutableStateOf("") }
    var justEvaluated by rememberSaveable { mutableStateOf(false) }
    val hasOperator = expr.drop(1).any { it in "+−×÷%" }
    val preview = remember(expr) { if (hasOperator) CalculatorLogic.evaluate(expr) else null }
    val scroll = rememberScrollState()

    AppFrame(title = "Калькулятор", onClose = onClose) {
        Column(
            Modifier.weight(0.32f).fillMaxWidth(),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End,
        ) {
            Row(Modifier.fillMaxWidth().horizontalScroll(scroll, reverseScrolling = true), horizontalArrangement = Arrangement.End) {
                Text(
                    text = expr.ifEmpty { "0" },
                    style = AetherType.clock.copy(fontSize = 52.sp),
                    color = p.textPrimary,
                    maxLines = 1,
                    softWrap = false,
                )
            }
            Text(
                text = if (preview != null && !justEvaluated) "= $preview" else " ",
                style = AetherType.body,
                color = p.textSecondary,
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
            )
        }

        Column(
            Modifier.weight(0.68f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Keys.forEach { row ->
                Row(
                    Modifier.weight(1f).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    row.forEach { key ->
                        CalcKey(key, Modifier.weight(1f).fillMaxHeight()) {
                            val next = CalculatorLogic.press(CalculatorLogic.State(expr, justEvaluated), key)
                            expr = next.expr
                            justEvaluated = next.justEvaluated
                        }
                    }
                }
            }
            Box(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun CalcKey(key: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    val shape = RoundedCornerShape(AetherDimens.radiusCard)
    val equals = key == "="
    Box(
        modifier
            .aetherGlass(shape)
            .background(if (equals) p.accent.copy(alpha = 0.55f) else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            key,
            style = AetherType.title.copy(fontSize = 26.sp),
            color = if (isAccentKey(key) && !equals) p.accent else p.textPrimary,
        )
    }
}
