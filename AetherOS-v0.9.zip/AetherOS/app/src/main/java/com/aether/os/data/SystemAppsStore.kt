package com.aether.os.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.systemAppsDataStore by preferencesDataStore(name = "aether_system_apps")

/** Событие встроенного календаря AETHER. minuteOfDay < 0 означает «весь день». */
data class CalEvent(val id: Long, val epochDay: Long, val minuteOfDay: Int, val title: String) {
    val allDay: Boolean get() = minuteOfDay < 0
}

val DefaultWorldZones = listOf("Europe/Moscow", "Europe/London", "America/New_York", "Asia/Tokyo")

data class SystemAppsPrefs(
    val events: List<CalEvent> = emptyList(),
    val zones: List<String> = DefaultWorldZones,
)

/** Локальные данные встроенных приложений «Календарь» и «Часы». Ничего не покидает устройство. */
class SystemAppsStore(private val context: Context) {

    private val kEvents = stringPreferencesKey("calendar_events")
    private val kZones = stringPreferencesKey("world_zones")

    val prefs: Flow<SystemAppsPrefs> = context.systemAppsDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            SystemAppsPrefs(
                events = p[kEvents]?.let(::decodeEvents) ?: emptyList(),
                zones = p[kZones]?.split(",")?.filter { it.isNotBlank() } ?: DefaultWorldZones,
            )
        }

    suspend fun setEvents(list: List<CalEvent>) {
        context.systemAppsDataStore.edit { it[kEvents] = encodeEvents(list) }
    }

    suspend fun setZones(list: List<String>) {
        context.systemAppsDataStore.edit { it[kZones] = list.joinToString(",") }
    }

    private fun encodeEvents(list: List<CalEvent>): String {
        val array = JSONArray()
        list.forEach { e ->
            array.put(
                JSONObject()
                    .put("id", e.id)
                    .put("d", e.epochDay)
                    .put("m", e.minuteOfDay)
                    .put("t", e.title)
            )
        }
        return array.toString()
    }

    private fun decodeEvents(s: String): List<CalEvent> = runCatching {
        val array = JSONArray(s)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            CalEvent(o.getLong("id"), o.getLong("d"), o.getInt("m"), o.getString("t"))
        }
    }.getOrDefault(emptyList())
}
