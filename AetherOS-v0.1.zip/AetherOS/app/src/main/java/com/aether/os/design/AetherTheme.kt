package com.aether.os.design

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Цветовая палитра AETHER. Material 3 используется лишь как техническая основа. */
@Immutable
data class AetherPalette(
    val isDark: Boolean,
    val textPrimary: Color,
    val textSecondary: Color,
    val glassHighlight: Color,
    val glassBody: Color,
    val glassEdgeLight: Color,
    val glassEdgeDim: Color,
    val accent: Color,
)

val AetherDarkPalette = AetherPalette(
    isDark = true,
    textPrimary = Color(0xFFF4F6FB),
    textSecondary = Color(0xB3F4F6FB),
    glassHighlight = Color(0x38FFFFFF),
    glassBody = Color(0x14FFFFFF),
    glassEdgeLight = Color(0x80FFFFFF),
    glassEdgeDim = Color(0x14FFFFFF),
    accent = Color(0xFF7FB2FF),
)

val AetherLightPalette = AetherPalette(
    isDark = false,
    textPrimary = Color(0xFF0E1320),
    textSecondary = Color(0xB30E1320),
    glassHighlight = Color(0x99FFFFFF),
    glassBody = Color(0x55FFFFFF),
    glassEdgeLight = Color(0xCCFFFFFF),
    glassEdgeDim = Color(0x40FFFFFF),
    accent = Color(0xFF2F6BFF),
)

val LocalAetherPalette = staticCompositionLocalOf { AetherDarkPalette }

/** Размеры, отступы и радиусы дизайн-системы. */
object AetherDimens {
    val screenPadding = 20.dp
    val iconSize = 58.dp
    val dockIconSize = 56.dp
    val radiusDock = 32.dp
    val radiusCard = 24.dp
    val radiusSmall = 14.dp
    const val gridColumns = 4
    const val gridRows = 5
    const val appsPerPage = gridColumns * gridRows
    const val dockSize = 4
}

@Composable
fun AetherTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val palette = if (dark) AetherDarkPalette else AetherLightPalette
    CompositionLocalProvider(LocalAetherPalette provides palette) {
        MaterialTheme(
            colorScheme = if (dark) darkColorScheme(primary = palette.accent)
            else lightColorScheme(primary = palette.accent),
            content = content,
        )
    }
}
