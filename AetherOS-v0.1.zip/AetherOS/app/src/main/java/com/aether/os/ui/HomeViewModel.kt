package com.aether.os.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aether.os.data.AppInfo
import com.aether.os.data.AppRepository
import com.aether.os.design.AetherDimens
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class HomeState(
    val apps: List<AppInfo> = emptyList(),
    val dock: List<AppInfo> = emptyList(),
    val loading: Boolean = true,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()
    private var job: Job? = null

    init {
        refresh()
    }

    /** Перечитывает список приложений (вызывается при установке/удалении пакетов). */
    fun refresh() {
        job?.cancel()
        job = viewModelScope.launch {
            val all = repository.loadLauncherApps()
            val dock = repository.pickDock(all, AetherDimens.dockSize)
            val dockPackages = dock.map { it.packageName }.toSet()
            _state.value = HomeState(
                apps = all.filter { it.packageName !in dockPackages },
                dock = dock,
                loading = false,
            )
        }
    }
}
