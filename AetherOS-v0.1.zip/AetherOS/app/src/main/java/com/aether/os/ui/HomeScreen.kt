package com.aether.os.ui

import android.text.format.DateFormat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppInfo
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.AmbientBackground
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.design.pressScale
import com.aether.os.design.rememberNow
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(state: HomeState, onLaunch: (AppInfo) -> Unit) {
    Box(Modifier.fillMaxSize()) {
        AmbientBackground()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = AetherDimens.screenPadding)
        ) {
            ClockBlock(Modifier.fillMaxWidth().padding(top = 32.dp, bottom = 16.dp))
            AppPager(state.apps, onLaunch, Modifier.weight(1f).fillMaxWidth())
            Dock(state.dock, onLaunch, Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp))
        }
    }
}

@Composable
private fun ClockBlock(modifier: Modifier = Modifier) {
    val p = LocalAetherPalette.current
    val context = LocalContext.current
    val now by rememberNow()
    val is24 = DateFormat.is24HourFormat(context)
    val timeFormatter = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm") }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    val softShadow = Shadow(Color.Black.copy(alpha = 0.22f), blurRadius = 24f)

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = now.format(timeFormatter),
            style = AetherType.clock.copy(shadow = softShadow),
            color = p.textPrimary,
        )
        Text(
            text = now.format(dateFormatter).replaceFirstChar { it.titlecase(Locale.getDefault()) },
            style = AetherType.date,
            color = p.textSecondary,
        )
    }
}

@Composable
private fun AppPager(apps: List<AppInfo>, onLaunch: (AppInfo) -> Unit, modifier: Modifier = Modifier) {
    val pages = remember(apps) { apps.chunked(AetherDimens.appsPerPage) }
    val pagerState = rememberPagerState(pageCount = { maxOf(1, pages.size) })

    Column(modifier) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) { index ->
            AppGridPage(pages.getOrElse(index) { emptyList() }, onLaunch)
        }
        if (pages.size > 1) {
            PageIndicator(count = pages.size, current = pagerState.currentPage)
        }
    }
}

@Composable
private fun AppGridPage(apps: List<AppInfo>, onLaunch: (AppInfo) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        repeat(AetherDimens.gridRows) { row ->
            Row(Modifier.fillMaxWidth().weight(1f)) {
                repeat(AetherDimens.gridColumns) { col ->
                    val app = apps.getOrNull(row * AetherDimens.gridColumns + col)
                    Box(
                        Modifier.weight(1f).fillMaxHeight(),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (app != null) AppCell(app, showLabel = true, onLaunch = onLaunch)
                    }
                }
            }
        }
    }
}

@Composable
private fun AppCell(
    app: AppInfo,
    showLabel: Boolean,
    onLaunch: (AppInfo) -> Unit,
    iconSize: Dp = AetherDimens.iconSize,
) {
    val p = LocalAetherPalette.current
    val interaction = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .pressScale(interaction)
            .clickable(interactionSource = interaction, indication = null) { onLaunch(app) }
            .padding(horizontal = 2.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier.size(iconSize),
        )
        if (showLabel) {
            Text(
                text = app.label,
                style = AetherType.appLabel,
                color = p.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}

@Composable
private fun PageIndicator(count: Int, current: Int) {
    val p = LocalAetherPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(count) { i ->
            val selected = i == current
            val width by animateDpAsState(if (selected) 18.dp else 6.dp, spring(0.7f), label = "dotW")
            val color by animateColorAsState(
                if (selected) p.textPrimary else p.textSecondary.copy(alpha = 0.4f),
                label = "dotC",
            )
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(width = width, height = 6.dp)
                    .background(color, CircleShape)
            )
        }
    }
}

@Composable
private fun Dock(dock: List<AppInfo>, onLaunch: (AppInfo) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusDock))
            .padding(horizontal = 12.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        dock.forEach { app ->
            AppCell(app, showLabel = false, onLaunch = onLaunch, iconSize = AetherDimens.dockIconSize)
        }
    }
}
