package com.aether.os.design

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

/**
 * AETHER Glass (v0.1): оптимизированная имитация жидкого стекла —
 * вертикальный градиент полупрозрачности + тонкая световая кромка.
 * Это НЕ реальное размытие/преломление фона (появится позже, где позволит API).
 */
fun Modifier.aetherGlass(shape: Shape): Modifier = composed {
    val p = LocalAetherPalette.current
    this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(p.glassHighlight, p.glassBody)))
        .border(
            width = 1.dp,
            brush = Brush.verticalGradient(listOf(p.glassEdgeLight, p.glassEdgeDim)),
            shape = shape,
        )
}

/** Пружинный эффект нажатия. */
fun Modifier.pressScale(
    interaction: MutableInteractionSource,
    pressedScale: Float = 0.92f,
): Modifier = composed {
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
