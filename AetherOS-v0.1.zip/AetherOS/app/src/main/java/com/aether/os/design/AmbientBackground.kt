package com.aether.os.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import java.time.LocalDateTime

private enum class DayPhase {
    DAWN, DAY, DUSK, NIGHT;

    companion object {
        fun fromHour(h: Int) = when (h) {
            in 5..7 -> DAWN
            in 8..16 -> DAY
            in 17..19 -> DUSK
            else -> NIGHT
        }
    }
}

private data class AmbientSpec(val top: Color, val bottom: Color, val glow: Color)

private fun ambientSpec(phase: DayPhase, dark: Boolean): AmbientSpec = when (phase) {
    DayPhase.DAWN ->
        if (dark) AmbientSpec(Color(0xFF1A1B3A), Color(0xFF3B2A4D), Color(0xFFFF9E7A))
        else AmbientSpec(Color(0xFFFFD9C7), Color(0xFFBFD4FF), Color(0xFFFFB38A))
    DayPhase.DAY ->
        if (dark) AmbientSpec(Color(0xFF0B1B3D), Color(0xFF16335E), Color(0xFF4C8DFF))
        else AmbientSpec(Color(0xFF9CCBFF), Color(0xFFE9F3FF), Color(0xFFFFFFFF))
    DayPhase.DUSK ->
        if (dark) AmbientSpec(Color(0xFF1B1038), Color(0xFF4A1F4F), Color(0xFFFF6F91))
        else AmbientSpec(Color(0xFFFFC2A8), Color(0xFFC9B6FF), Color(0xFFFF9AA8))
    DayPhase.NIGHT ->
        if (dark) AmbientSpec(Color(0xFF050814), Color(0xFF0D1330), Color(0xFF3A5BFF))
        else AmbientSpec(Color(0xFFB9C4E8), Color(0xFFDDE3F7), Color(0xFF8EA2FF))
}

/** Текущее время, обновляется раз в минуту (без постоянных фоновых процессов). */
@Composable
fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        val n = LocalDateTime.now()
        value = n
        val wait = (60 - n.second) * 1000L - n.nano / 1_000_000
        delay(wait.coerceAtLeast(250L))
    }
}

/** AETHER Ambient: фон реагирует на время суток и системную тему, с плавной сменой цветов. */
@Composable
fun AmbientBackground(modifier: Modifier = Modifier) {
    val dark = LocalAetherPalette.current.isDark
    val now by rememberNow()
    val spec = ambientSpec(DayPhase.fromHour(now.hour), dark)
    val top by animateColorAsState(spec.top, tween(700), label = "ambTop")
    val bottom by animateColorAsState(spec.bottom, tween(700), label = "ambBottom")
    val glow by animateColorAsState(spec.glow, tween(700), label = "ambGlow")

    Box(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(glow.copy(alpha = 0.55f), Color.Transparent),
                        center = Offset(size.width * 0.8f, size.height * 0.18f),
                        radius = size.width * 0.9f,
                    )
                )
            }
    )
}
