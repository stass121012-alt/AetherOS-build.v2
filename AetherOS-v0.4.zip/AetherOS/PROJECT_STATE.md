# PROJECT STATE — AETHER OS v0.4.0
Сборка не запускалась (нет Android SDK в среде генерации).
v0.4: раздел «Персонализация» (тема, обои, сетка, размер иконок, подписи), WallpaperStore, SheetComponents.
Следующий этап: v0.5 — поиск, папки, drag-and-drop.
