package com.aether.os.ui

import android.app.Application
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aether.os.R
import com.aether.os.data.AppInfo
import com.aether.os.data.AppRepository
import com.aether.os.data.AppSettings
import com.aether.os.data.LayoutPrefs
import com.aether.os.data.LayoutStore
import com.aether.os.data.SettingsStore
import com.aether.os.data.ThemeMode
import com.aether.os.data.WallpaperKind
import com.aether.os.data.WallpaperStore
import com.aether.os.design.AetherDimens
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeState(
    val apps: List<AppInfo> = emptyList(),
    val dock: List<AppInfo> = emptyList(),
    val hidden: List<AppInfo> = emptyList(),
    val loading: Boolean = true,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = AppRepository(application)
    private val store = LayoutStore(application)
    private val settingsStore = SettingsStore(application)
    private val wallpaperStore = WallpaperStore(application)

    private val allApps = MutableStateFlow<List<AppInfo>?>(null)
    private val defaultDock = MutableStateFlow<List<String>>(emptyList())
    private var loadJob: Job? = null

    private val _wallpaperImage = MutableStateFlow<ImageBitmap?>(null)
    val wallpaperImage: StateFlow<ImageBitmap?> = _wallpaperImage.asStateFlow()

    /** Короткие сообщения для пользователя (id строковых ресурсов). */
    private val _messages = MutableSharedFlow<Int>(extraBufferCapacity = 1)
    val messages: SharedFlow<Int> = _messages.asSharedFlow()

    val state: StateFlow<HomeState> = combine(allApps, defaultDock, store.prefs) { all, def, prefs ->
        build(all, def, prefs)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HomeState())

    val settings: StateFlow<AppSettings> = settingsStore.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    init {
        refresh()
        viewModelScope.launch { _wallpaperImage.value = wallpaperStore.load() }
    }

    /** Перечитывает список приложений (при установке/удалении пакетов). */
    fun refresh() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            val all = repository.loadLauncherApps()
            defaultDock.value = repository.pickDock(all, AetherDimens.dockSize).map { it.packageName }
            allApps.value = all
        }
    }

    private fun build(all: List<AppInfo>?, defDock: List<String>, p: LayoutPrefs): HomeState {
        if (all == null) return HomeState()
        val byPkg = all.associateBy { it.packageName }
        val dockPkgs = (p.dock ?: defDock)
            .filter { it in byPkg && it !in p.hidden }
            .distinct()
            .take(AetherDimens.dockSize)
        val dockSet = dockPkgs.toSet()
        val index = p.order.withIndex().associate { it.value to it.index }
        val grid = all
            .filter { it.packageName !in dockSet && it.packageName !in p.hidden }
            .sortedBy { index[it.packageName] ?: Int.MAX_VALUE }
        return HomeState(
            apps = grid,
            dock = dockPkgs.map { byPkg.getValue(it) },
            hidden = all.filter { it.packageName in p.hidden },
            loading = false,
        )
    }

    // ---- внешний вид и персонализация ----

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsStore.setThemeMode(mode) }
    }

    fun setReduceMotion(value: Boolean) {
        viewModelScope.launch { settingsStore.setReduceMotion(value) }
    }

    fun setIconSize(dp: Int) {
        viewModelScope.launch { settingsStore.setIconSize(dp) }
    }

    fun setColumns(value: Int) {
        viewModelScope.launch { settingsStore.setColumns(value) }
    }

    fun setRows(value: Int) {
        viewModelScope.launch { settingsStore.setRows(value) }
    }

    fun setShowLabels(value: Boolean) {
        viewModelScope.launch { settingsStore.setShowLabels(value) }
    }

    fun setWallpaper(kind: WallpaperKind, preset: Int) {
        viewModelScope.launch {
            if (kind == WallpaperKind.IMAGE && _wallpaperImage.value == null) return@launch
            settingsStore.setWallpaper(kind, preset)
        }
    }

    fun setWallpaperFromUri(uri: Uri) {
        viewModelScope.launch {
            val bitmap = wallpaperStore.saveFromUri(uri)
            if (bitmap == null) {
                _messages.tryEmit(R.string.wallpaper_failed)
            } else {
                _wallpaperImage.value = bitmap
                settingsStore.setWallpaper(WallpaperKind.IMAGE, settings.value.wallpaperPreset)
            }
        }
    }

    fun removeWallpaperImage() {
        viewModelScope.launch {
            wallpaperStore.delete()
            _wallpaperImage.value = null
            val s = settings.value
            if (s.wallpaperKind == WallpaperKind.IMAGE) {
                settingsStore.setWallpaper(WallpaperKind.AMBIENT, s.wallpaperPreset)
            }
        }
    }

    fun resetPersonalization() {
        viewModelScope.launch {
            wallpaperStore.delete()
            _wallpaperImage.value = null
            settingsStore.resetPersonalization()
        }
    }

    // ---- раскладка рабочего стола ----

    fun toggleDock(pkg: String) {
        viewModelScope.launch {
            val cur = state.value.dock.map { it.packageName }
            val next = when {
                pkg in cur -> cur - pkg
                cur.size < AetherDimens.dockSize -> cur + pkg
                else -> return@launch
            }
            store.setDock(next)
        }
    }

    fun hide(pkg: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            store.setHidden(p.hidden + pkg)
            val dock = state.value.dock.map { it.packageName }
            if (pkg in dock) store.setDock(dock - pkg)
        }
    }

    fun unhide(pkg: String) {
        viewModelScope.launch {
            val p = store.prefs.first()
            store.setHidden(p.hidden - pkg)
        }
    }

    fun unhideAll() {
        viewModelScope.launch { store.setHidden(emptySet()) }
    }

    fun resetDock() {
        viewModelScope.launch { store.setDock(null) }
    }

    /** Сдвигает приложение в сетке на [delta] позиций (-1 влево, +1 вправо). */
    fun move(pkg: String, delta: Int) {
        viewModelScope.launch {
            val list = state.value.apps.map { it.packageName }.toMutableList()
            val i = list.indexOf(pkg)
            val j = i + delta
            if (i < 0 || j !in list.indices) return@launch
            val tmp = list[i]
            list[i] = list[j]
            list[j] = tmp
            store.setOrder(list)
        }
    }
}
