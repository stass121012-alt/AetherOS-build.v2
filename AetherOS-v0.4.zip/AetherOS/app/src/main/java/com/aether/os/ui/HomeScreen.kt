package com.aether.os.ui

import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppInfo
import com.aether.os.data.AppSettings
import com.aether.os.data.ThemeMode
import com.aether.os.data.WallpaperKind
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.AetherWallpaper
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.LocalReduceMotion
import com.aether.os.design.aetherGlass
import com.aether.os.design.aetherSpring
import com.aether.os.design.pressScale
import com.aether.os.design.rememberNow
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Все действия, которые UI может запросить у оболочки. */
@Immutable
data class HomeActions(
    val onLaunch: (AppInfo) -> Unit,
    val onToggleDock: (String) -> Unit,
    val onHide: (String) -> Unit,
    val onUnhide: (String) -> Unit,
    val onUnhideAll: () -> Unit,
    val onResetDock: () -> Unit,
    val onMove: (String, Int) -> Unit,
    val onAppInfo: (String) -> Unit,
    val onThemeMode: (ThemeMode) -> Unit,
    val onReduceMotion: (Boolean) -> Unit,
    val onIconSize: (Int) -> Unit,
    val onColumns: (Int) -> Unit,
    val onRows: (Int) -> Unit,
    val onShowLabels: (Boolean) -> Unit,
    val onWallpaper: (WallpaperKind, Int) -> Unit,
    val onPickWallpaper: () -> Unit,
    val onRemoveWallpaperImage: () -> Unit,
    val onResetPersonalization: () -> Unit,
)

private enum class Panel { NONE, SETTINGS, PERSONALIZATION }

private const val MAX_DOCK_ICON_DP = 64

@Composable
fun HomeScreen(
    state: HomeState,
    settings: AppSettings,
    wallpaperImage: ImageBitmap?,
    actions: HomeActions,
) {
    var panel by rememberSaveable { mutableStateOf(Panel.NONE) }
    val reduce = LocalReduceMotion.current
    BackHandler(enabled = panel != Panel.NONE) {
        panel = if (panel == Panel.PERSONALIZATION) Panel.SETTINGS else Panel.NONE
    }

    Box(Modifier.fillMaxSize()) {
        AetherWallpaper(
            kind = settings.wallpaperKind,
            presetIndex = settings.wallpaperPreset,
            image = wallpaperImage,
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = AetherDimens.screenPadding)
        ) {
            ClockBlock(
                modifier = Modifier.fillMaxWidth().padding(top = 32.dp, bottom = 16.dp),
                onLongPress = { panel = Panel.SETTINGS },
            )
            AppPager(
                apps = state.apps,
                settings = settings,
                dockFull = state.dock.size >= AetherDimens.dockSize,
                actions = actions,
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
            Dock(
                dock = state.dock,
                iconSize = minOf(settings.iconSizeDp, MAX_DOCK_ICON_DP).dp,
                actions = actions,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp),
            )
        }

        AnimatedVisibility(
            visible = panel == Panel.SETTINGS,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + slideInVertically { it / 8 },
            exit = if (reduce) fadeOut(tween(120)) else fadeOut() + slideOutVertically { it / 8 },
        ) {
            SettingsScreen(
                settings = settings,
                hidden = state.hidden,
                actions = actions,
                onOpenPersonalization = { panel = Panel.PERSONALIZATION },
                onClose = { panel = Panel.NONE },
            )
        }
        AnimatedVisibility(
            visible = panel == Panel.PERSONALIZATION,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + slideInVertically { it / 8 },
            exit = if (reduce) fadeOut(tween(120)) else fadeOut() + slideOutVertically { it / 8 },
        ) {
            PersonalizationScreen(
                settings = settings,
                wallpaperImage = wallpaperImage,
                actions = actions,
                onBack = { panel = Panel.SETTINGS },
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ClockBlock(modifier: Modifier = Modifier, onLongPress: () -> Unit) {
    val p = LocalAetherPalette.current
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val now by rememberNow()
    val is24 = DateFormat.is24HourFormat(context)
    val timeFormatter = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm") }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    val softShadow = Shadow(Color.Black.copy(alpha = 0.22f), blurRadius = 24f)
    val source = remember { MutableInteractionSource() }

    Column(
        modifier = modifier.combinedClickable(
            interactionSource = source,
            indication = null,
            onClick = { },
            onLongClick = {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onLongPress()
            },
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = now.format(timeFormatter),
            style = AetherType.clock.copy(shadow = softShadow),
            color = p.textPrimary,
        )
        Text(
            text = now.format(dateFormatter).replaceFirstChar { it.titlecase(Locale.getDefault()) },
            style = AetherType.date,
            color = p.textSecondary,
        )
    }
}

@Composable
private fun AppPager(
    apps: List<AppInfo>,
    settings: AppSettings,
    dockFull: Boolean,
    actions: HomeActions,
    modifier: Modifier = Modifier,
) {
    val perPage = settings.columns * settings.rows
    val pages = remember(apps, perPage) { apps.chunked(perPage) }
    val pagerState = rememberPagerState(pageCount = { maxOf(1, pages.size) })

    Column(modifier) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) { index ->
            AppGridPage(
                apps = pages.getOrElse(index) { emptyList() },
                startIndex = index * perPage,
                total = apps.size,
                settings = settings,
                dockFull = dockFull,
                actions = actions,
            )
        }
        if (pages.size > 1) {
            PageIndicator(count = pages.size, current = pagerState.currentPage)
        }
    }
}

@Composable
private fun AppGridPage(
    apps: List<AppInfo>,
    startIndex: Int,
    total: Int,
    settings: AppSettings,
    dockFull: Boolean,
    actions: HomeActions,
) {
    val columns = settings.columns
    val rows = settings.rows
    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Иконка не больше ячейки: на узких экранах и больших сетках размер уменьшается автоматически.
        val cellWidth = maxWidth / columns
        val cellHeight = maxHeight / rows
        val labelSpace = if (settings.showLabels) 32.dp else 10.dp
        val icon = minOf(settings.iconSizeDp.dp, cellWidth - 8.dp, cellHeight - labelSpace)
            .coerceAtLeast(28.dp)

        Column(Modifier.fillMaxSize()) {
            repeat(rows) { row ->
                Row(Modifier.fillMaxWidth().weight(1f)) {
                    repeat(columns) { col ->
                        val local = row * columns + col
                        val app = apps.getOrNull(local)
                        val global = startIndex + local
                        Box(
                            Modifier.weight(1f).fillMaxHeight(),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (app != null) {
                                AppCell(
                                    app = app,
                                    showLabel = settings.showLabels,
                                    actions = actions,
                                    menu = CellMenu(
                                        inDock = false,
                                        dockFull = dockFull,
                                        canMoveLeft = global > 0,
                                        canMoveRight = global < total - 1,
                                    ),
                                    iconSize = icon,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppCell(
    app: AppInfo,
    showLabel: Boolean,
    actions: HomeActions,
    menu: CellMenu,
    iconSize: Dp,
) {
    val p = LocalAetherPalette.current
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    var expanded by remember { mutableStateOf(false) }

    Box {
        Column(
            modifier = Modifier
                .pressScale(interaction)
                .combinedClickable(
                    interactionSource = interaction,
                    indication = null,
                    onClick = { actions.onLaunch(app) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        expanded = true
                    },
                )
                .padding(horizontal = 2.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier.size(iconSize),
            )
            if (showLabel) {
                Text(
                    text = app.label,
                    style = AetherType.appLabel,
                    color = p.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
        AppMenu(expanded, { expanded = false }, app, actions, menu)
    }
}

@Composable
private fun PageIndicator(count: Int, current: Int) {
    val p = LocalAetherPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(count) { i ->
            val selected = i == current
            val width by animateDpAsState(
                targetValue = if (selected) 18.dp else 6.dp,
                animationSpec = aetherSpring(dampingRatio = 0.7f),
                label = "dotW",
            )
            val color by animateColorAsState(
                targetValue = if (selected) p.textPrimary else p.textSecondary.copy(alpha = 0.4f),
                animationSpec = aetherSpring(),
                label = "dotC",
            )
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(width = width, height = 6.dp)
                    .background(color, CircleShape)
            )
        }
    }
}

@Composable
private fun Dock(
    dock: List<AppInfo>,
    iconSize: Dp,
    actions: HomeActions,
    modifier: Modifier = Modifier,
) {
    val p = LocalAetherPalette.current
    Row(
        modifier = modifier
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusDock))
            .padding(horizontal = 12.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (dock.isEmpty()) {
            Text(
                "Долгое нажатие на иконку → «Добавить в док»",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(vertical = 20.dp),
            )
        }
        dock.forEach { app ->
            AppCell(
                app = app,
                showLabel = false,
                actions = actions,
                menu = CellMenu(inDock = true, dockFull = true),
                iconSize = iconSize,
            )
        }
    }
}
