package com.aether.os.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore by preferencesDataStore(name = "aether_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class WallpaperKind { AMBIENT, PRESET, IMAGE }

/** Границы пользовательских настроек сетки и иконок. */
object PersonalizationLimits {
    val iconSize = 44..72
    val columns = 3..6
    val rows = 4..7
    const val DEFAULT_ICON_SIZE = 58
    const val DEFAULT_COLUMNS = 4
    const val DEFAULT_ROWS = 5
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val reduceMotion: Boolean = false,
    val iconSizeDp: Int = PersonalizationLimits.DEFAULT_ICON_SIZE,
    val columns: Int = PersonalizationLimits.DEFAULT_COLUMNS,
    val rows: Int = PersonalizationLimits.DEFAULT_ROWS,
    val showLabels: Boolean = true,
    val wallpaperKind: WallpaperKind = WallpaperKind.AMBIENT,
    val wallpaperPreset: Int = 0,
)

class SettingsStore(private val context: Context) {

    private val kTheme = stringPreferencesKey("theme_mode")
    private val kReduce = booleanPreferencesKey("reduce_motion")
    private val kIcon = intPreferencesKey("icon_size")
    private val kColumns = intPreferencesKey("grid_columns")
    private val kRows = intPreferencesKey("grid_rows")
    private val kLabels = booleanPreferencesKey("show_labels")
    private val kWpKind = stringPreferencesKey("wallpaper_kind")
    private val kWpPreset = intPreferencesKey("wallpaper_preset")

    val settings: Flow<AppSettings> = context.settingsDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p -> p.toSettings() }

    private fun Preferences.toSettings() = AppSettings(
        themeMode = this[kTheme]
            ?.let { n -> runCatching { ThemeMode.valueOf(n) }.getOrNull() }
            ?: ThemeMode.SYSTEM,
        reduceMotion = this[kReduce] ?: false,
        iconSizeDp = (this[kIcon] ?: PersonalizationLimits.DEFAULT_ICON_SIZE)
            .coerceIn(PersonalizationLimits.iconSize),
        columns = (this[kColumns] ?: PersonalizationLimits.DEFAULT_COLUMNS)
            .coerceIn(PersonalizationLimits.columns),
        rows = (this[kRows] ?: PersonalizationLimits.DEFAULT_ROWS)
            .coerceIn(PersonalizationLimits.rows),
        showLabels = this[kLabels] ?: true,
        wallpaperKind = this[kWpKind]
            ?.let { n -> runCatching { WallpaperKind.valueOf(n) }.getOrNull() }
            ?: WallpaperKind.AMBIENT,
        wallpaperPreset = this[kWpPreset] ?: 0,
    )

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[kTheme] = mode.name }
    }

    suspend fun setReduceMotion(value: Boolean) {
        context.settingsDataStore.edit { it[kReduce] = value }
    }

    suspend fun setIconSize(dp: Int) {
        context.settingsDataStore.edit { it[kIcon] = dp.coerceIn(PersonalizationLimits.iconSize) }
    }

    suspend fun setColumns(value: Int) {
        context.settingsDataStore.edit { it[kColumns] = value.coerceIn(PersonalizationLimits.columns) }
    }

    suspend fun setRows(value: Int) {
        context.settingsDataStore.edit { it[kRows] = value.coerceIn(PersonalizationLimits.rows) }
    }

    suspend fun setShowLabels(value: Boolean) {
        context.settingsDataStore.edit { it[kLabels] = value }
    }

    suspend fun setWallpaper(kind: WallpaperKind, preset: Int) {
        context.settingsDataStore.edit {
            it[kWpKind] = kind.name
            it[kWpPreset] = preset
        }
    }

    /** Сбрасывает сетку, иконки, подписи и обои. Тема и режим анимаций не затрагиваются. */
    suspend fun resetPersonalization() {
        context.settingsDataStore.edit {
            it.remove(kIcon)
            it.remove(kColumns)
            it.remove(kRows)
            it.remove(kLabels)
            it.remove(kWpKind)
            it.remove(kWpPreset)
        }
    }
}
