package com.aether.os.design

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aether.os.data.ThemeMode

/** Цветовая палитра AETHER. Material 3 используется лишь как техническая основа. */
@Immutable
data class AetherPalette(
    val isDark: Boolean,
    val textPrimary: Color,
    val textSecondary: Color,
    val glassHighlight: Color,
    val glassBody: Color,
    val glassEdgeLight: Color,
    val glassEdgeDim: Color,
    val accent: Color,
    val panel: Color,
)

val AetherDarkPalette = AetherPalette(
    isDark = true,
    textPrimary = Color(0xFFF4F6FB),
    textSecondary = Color(0xB3F4F6FB),
    glassHighlight = Color(0x38FFFFFF),
    glassBody = Color(0x14FFFFFF),
    glassEdgeLight = Color(0x80FFFFFF),
    glassEdgeDim = Color(0x14FFFFFF),
    accent = Color(0xFF7FB2FF),
    panel = Color(0xF2121828),
)

val AetherLightPalette = AetherPalette(
    isDark = false,
    textPrimary = Color(0xFF0E1320),
    textSecondary = Color(0xB30E1320),
    glassHighlight = Color(0x99FFFFFF),
    glassBody = Color(0x55FFFFFF),
    glassEdgeLight = Color(0xCCFFFFFF),
    glassEdgeDim = Color(0x40FFFFFF),
    accent = Color(0xFF2F6BFF),
    panel = Color(0xF2F3F6FF),
)

val LocalAetherPalette = compositionLocalOf { AetherDarkPalette }

/** Режим уменьшенных анимаций: пружины и масштабирование заменяются мгновенными переходами. */
val LocalReduceMotion = staticCompositionLocalOf { false }

/** Пружина AETHER, которая автоматически отключается в режиме уменьшенных анимаций. */
@Composable
fun <T> aetherSpring(
    dampingRatio: Float = Spring.DampingRatioNoBouncy,
    stiffness: Float = Spring.StiffnessMedium,
): FiniteAnimationSpec<T> =
    if (LocalReduceMotion.current) snap() else spring(dampingRatio, stiffness)

/** Размеры, отступы и радиусы дизайн-системы. */
object AetherDimens {
    val screenPadding = 20.dp
    val iconSize = 58.dp
    val dockIconSize = 56.dp
    val radiusDock = 32.dp
    val radiusCard = 24.dp
    val radiusSmall = 14.dp
    const val dockSize = 4
}

@Composable
private fun animatePalette(t: AetherPalette, reduceMotion: Boolean): AetherPalette {
    val spec: AnimationSpec<Color> = if (reduceMotion) snap() else tween(450)
    val textPrimary by animateColorAsState(t.textPrimary, spec, label = "tp")
    val textSecondary by animateColorAsState(t.textSecondary, spec, label = "ts")
    val glassHighlight by animateColorAsState(t.glassHighlight, spec, label = "gh")
    val glassBody by animateColorAsState(t.glassBody, spec, label = "gb")
    val glassEdgeLight by animateColorAsState(t.glassEdgeLight, spec, label = "gel")
    val glassEdgeDim by animateColorAsState(t.glassEdgeDim, spec, label = "ged")
    val accent by animateColorAsState(t.accent, spec, label = "ac")
    val panel by animateColorAsState(t.panel, spec, label = "pn")
    return AetherPalette(
        isDark = t.isDark,
        textPrimary = textPrimary,
        textSecondary = textSecondary,
        glassHighlight = glassHighlight,
        glassBody = glassBody,
        glassEdgeLight = glassEdgeLight,
        glassEdgeDim = glassEdgeDim,
        accent = accent,
        panel = panel,
    )
}

@Composable
fun AetherTheme(
    themeMode: ThemeMode,
    reduceMotion: Boolean,
    content: @Composable () -> Unit,
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val palette = animatePalette(if (dark) AetherDarkPalette else AetherLightPalette, reduceMotion)
    CompositionLocalProvider(
        LocalAetherPalette provides palette,
        LocalReduceMotion provides reduceMotion,
    ) {
        MaterialTheme(
            colorScheme = if (dark) darkColorScheme(primary = palette.accent)
            else lightColorScheme(primary = palette.accent),
            content = content,
        )
    }
}
