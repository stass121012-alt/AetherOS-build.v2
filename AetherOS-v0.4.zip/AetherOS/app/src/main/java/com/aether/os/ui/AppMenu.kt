package com.aether.os.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import com.aether.os.data.AppInfo
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.LocalReduceMotion

@Immutable
internal data class CellMenu(
    val inDock: Boolean,
    val dockFull: Boolean,
    val canMoveLeft: Boolean = false,
    val canMoveRight: Boolean = false,
)

/** Располагает меню под иконкой, а если снизу нет места (док) — над ней; не выходит за экран. */
private class MenuPositionProvider(private val margin: Int) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize,
    ): IntOffset {
        val maxX = (windowSize.width - popupContentSize.width - margin).coerceAtLeast(margin)
        val x = (anchorBounds.center.x - popupContentSize.width / 2).coerceIn(margin, maxX)
        val below = anchorBounds.bottom + margin
        val y = if (below + popupContentSize.height <= windowSize.height - margin) {
            below
        } else {
            (anchorBounds.top - popupContentSize.height - margin).coerceAtLeast(margin)
        }
        return IntOffset(x, y)
    }
}

/** Контекстное меню иконки в стиле AETHER (вместо стандартного DropdownMenu). */
@Composable
internal fun AppMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    app: AppInfo,
    actions: HomeActions,
    menu: CellMenu,
) {
    if (!expanded) return
    val p = LocalAetherPalette.current
    val reduce = LocalReduceMotion.current
    val pkg = app.packageName
    val margin = with(LocalDensity.current) { 8.dp.roundToPx() }
    val provider = remember(margin) { MenuPositionProvider(margin) }
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    val shape = RoundedCornerShape(AetherDimens.radiusSmall + 4.dp)

    Popup(
        popupPositionProvider = provider,
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true),
    ) {
        AnimatedVisibility(
            visibleState = visible,
            enter = if (reduce) fadeIn(tween(100)) else fadeIn() + scaleIn(initialScale = 0.9f),
        ) {
            Column(
                Modifier
                    .width(220.dp)
                    .clip(shape)
                    .background(p.panel)
                    .border(1.dp, Brush.verticalGradient(listOf(p.glassEdgeLight, p.glassEdgeDim)), shape)
                    .padding(vertical = 6.dp)
            ) {
                MenuItem(
                    text = when {
                        menu.inDock -> "Убрать из дока"
                        menu.dockFull -> "Док заполнен"
                        else -> "Добавить в док"
                    },
                    enabled = menu.inDock || !menu.dockFull,
                ) { onDismiss(); actions.onToggleDock(pkg) }
                if (!menu.inDock) {
                    MenuItem("Сдвинуть влево", menu.canMoveLeft) { onDismiss(); actions.onMove(pkg, -1) }
                    MenuItem("Сдвинуть вправо", menu.canMoveRight) { onDismiss(); actions.onMove(pkg, 1) }
                }
                MenuItem("Скрыть") { onDismiss(); actions.onHide(pkg) }
                MenuItem("О приложении") { onDismiss(); actions.onAppInfo(pkg) }
            }
        }
    }
}

@Composable
private fun MenuItem(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val p = LocalAetherPalette.current
    Text(
        text = text,
        style = AetherType.body,
        color = if (enabled) p.textPrimary else p.textSecondary.copy(alpha = 0.5f),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    )
}
