package com.aether.os.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppSettings
import com.aether.os.data.PersonalizationLimits
import com.aether.os.data.ThemeMode
import com.aether.os.data.WallpaperKind
import com.aether.os.design.AetherType
import com.aether.os.design.AetherWallpaperPresets
import com.aether.os.design.LocalAetherPalette

/** Раздел «Персонализация»: тема, обои, сетка, размер иконок, подписи. */
@Composable
fun PersonalizationScreen(
    settings: AppSettings,
    wallpaperImage: ImageBitmap?,
    actions: HomeActions,
    onBack: () -> Unit,
) {
    SheetScaffold(
        title = "Персонализация",
        subtitle = "Изменения применяются и сохраняются сразу",
        onClose = onBack,
        heightFraction = 0.62f,
        scrimAlpha = 0.2f,
    ) {
        item { SectionTitle("ТЕМА") }
        item {
            SegmentedRow(
                options = listOf(
                    ThemeMode.SYSTEM to "Системная",
                    ThemeMode.LIGHT to "Светлая",
                    ThemeMode.DARK to "Тёмная",
                ),
                selected = settings.themeMode,
                onSelect = actions.onThemeMode,
            )
        }

        item { SectionTitle("ОБОИ") }
        item { WallpaperPicker(settings, wallpaperImage, actions) }
        item {
            ActionRow(
                title = "Выбрать фото из галереи",
                subtitle = "Копия хранится внутри приложения, разрешения не нужны",
                onClick = actions.onPickWallpaper,
            )
        }
        if (wallpaperImage != null) {
            item { ActionRow("Удалить своё фото", null, actions.onRemoveWallpaperImage) }
        }

        item { SectionTitle("СЕТКА И ИКОНКИ") }
        item {
            SliderRow(
                title = "Размер иконок",
                unit = " dp",
                value = settings.iconSizeDp,
                range = PersonalizationLimits.iconSize,
                onCommit = actions.onIconSize,
            )
        }
        item {
            SliderRow(
                title = "Колонки",
                unit = "",
                value = settings.columns,
                range = PersonalizationLimits.columns,
                onCommit = actions.onColumns,
            )
        }
        item {
            SliderRow(
                title = "Строки",
                unit = "",
                value = settings.rows,
                range = PersonalizationLimits.rows,
                onCommit = actions.onRows,
            )
        }
        item {
            SwitchRow(
                title = "Подписи под иконками",
                subtitle = "Названия приложений на рабочем столе",
                checked = settings.showLabels,
                onChange = actions.onShowLabels,
            )
        }

        item { SectionTitle("СБРОС") }
        item {
            ActionRow(
                title = "Сбросить сетку, иконки и обои",
                subtitle = "Тема и режим анимаций останутся прежними",
                onClick = actions.onResetPersonalization,
            )
        }
        item { ActionRow("Назад", null, onBack) }
    }
}

@Composable
private fun WallpaperPicker(
    settings: AppSettings,
    image: ImageBitmap?,
    actions: HomeActions,
) {
    val p = LocalAetherPalette.current
    val kind = settings.wallpaperKind

    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            WallpaperTile(
                label = "Авто",
                selected = kind == WallpaperKind.AMBIENT,
                onClick = { actions.onWallpaper(WallpaperKind.AMBIENT, settings.wallpaperPreset) },
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF0B1B3D), Color(0xFFFF6F91))))
                )
            }
        }
        itemsIndexed(AetherWallpaperPresets) { index, preset ->
            WallpaperTile(
                label = preset.name,
                selected = kind == WallpaperKind.PRESET && settings.wallpaperPreset == index,
                onClick = { actions.onWallpaper(WallpaperKind.PRESET, index) },
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(preset.top, preset.bottom)))
                )
            }
        }
        item {
            WallpaperTile(
                label = "Фото",
                selected = kind == WallpaperKind.IMAGE && image != null,
                onClick = {
                    if (image != null) {
                        actions.onWallpaper(WallpaperKind.IMAGE, settings.wallpaperPreset)
                    } else {
                        actions.onPickWallpaper()
                    }
                },
            ) {
                if (image != null) {
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("+", style = AetherType.title, color = p.accent)
                    }
                }
            }
        }
    }
}

@Composable
private fun WallpaperTile(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val p = LocalAetherPalette.current
    val shape = RoundedCornerShape(16.dp)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(width = 76.dp, height = 116.dp)
                .clip(shape)
                .border(
                    width = if (selected) 2.dp else 1.dp,
                    color = if (selected) p.accent else p.glassEdgeDim,
                    shape = shape,
                )
                .clickable(onClick = onClick),
            content = content,
        )
        Text(
            label,
            style = AetherType.caption,
            color = if (selected) p.textPrimary else p.textSecondary,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}
