package com.aether.os.design

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

/**
 * AETHER Glass: оптимизированная имитация жидкого стекла — вертикальный градиент
 * полупрозрачности, тонкая световая кромка и верхний блик.
 * Это НЕ реальное размытие/преломление фона.
 */
fun Modifier.aetherGlass(shape: Shape): Modifier = composed {
    val p = LocalAetherPalette.current
    this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(p.glassHighlight, p.glassBody)))
        .drawBehind {
            val inset = minOf(size.width, size.height) * 0.28f
            if (size.width > inset * 2f) {
                val y = 1.5.dp.toPx()
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, p.glassEdgeLight, Color.Transparent),
                        startX = inset,
                        endX = size.width - inset,
                    ),
                    start = Offset(inset, y),
                    end = Offset(size.width - inset, y),
                    strokeWidth = 1.dp.toPx(),
                )
            }
        }
        .border(
            width = 1.dp,
            brush = Brush.verticalGradient(listOf(p.glassEdgeLight, p.glassEdgeDim)),
            shape = shape,
        )
}

/** Пружинный эффект нажатия (отключается в режиме уменьшенных анимаций). */
fun Modifier.pressScale(
    interaction: MutableInteractionSource,
    pressedScale: Float = 0.92f,
): Modifier = composed {
    val reduce = LocalReduceMotion.current
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && !reduce) pressedScale else 1f,
        animationSpec = aetherSpring(dampingRatio = 0.55f),
        label = "pressScale",
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
