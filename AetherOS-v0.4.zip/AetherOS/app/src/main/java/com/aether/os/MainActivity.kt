package com.aether.os

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.aether.os.data.AppInfo
import com.aether.os.design.AetherTheme
import com.aether.os.design.LocalAetherPalette
import com.aether.os.ui.HomeActions
import com.aether.os.ui.HomeScreen
import com.aether.os.ui.HomeViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: HomeViewModel by viewModels()

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refresh()
        }
    }

    /** Системный Photo Picker: разрешения на галерею не нужны. */
    private val pickWallpaper = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.setWallpaperFromUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.messages.collect { resId ->
                    Toast.makeText(this@MainActivity, resId, Toast.LENGTH_SHORT).show()
                }
            }
        }

        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val wallpaperImage by viewModel.wallpaperImage.collectAsStateWithLifecycle()
            val actions = remember {
                HomeActions(
                    onLaunch = ::launchApp,
                    onToggleDock = viewModel::toggleDock,
                    onHide = viewModel::hide,
                    onUnhide = viewModel::unhide,
                    onUnhideAll = viewModel::unhideAll,
                    onResetDock = viewModel::resetDock,
                    onMove = viewModel::move,
                    onAppInfo = ::openAppInfo,
                    onThemeMode = viewModel::setThemeMode,
                    onReduceMotion = viewModel::setReduceMotion,
                    onIconSize = viewModel::setIconSize,
                    onColumns = viewModel::setColumns,
                    onRows = viewModel::setRows,
                    onShowLabels = viewModel::setShowLabels,
                    onWallpaper = viewModel::setWallpaper,
                    onPickWallpaper = ::pickWallpaperImage,
                    onRemoveWallpaperImage = viewModel::removeWallpaperImage,
                    onResetPersonalization = viewModel::resetPersonalization,
                )
            }

            AetherTheme(themeMode = settings.themeMode, reduceMotion = settings.reduceMotion) {
                // Цвет иконок системных панелей следует выбранной теме AETHER.
                val isDark = LocalAetherPalette.current.isDark
                LaunchedEffect(isDark) {
                    val style = if (isDark) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    }
                    this@MainActivity.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                }
                // Домашний экран не закрывается кнопкой «Назад».
                BackHandler(enabled = true) { }
                HomeScreen(
                    state = state,
                    settings = settings,
                    wallpaperImage = wallpaperImage,
                    actions = actions,
                )
            }
        }
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    private fun pickWallpaperImage() {
        pickWallpaper.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(intent)
    }

    private fun openAppInfo(packageName: String) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", packageName, null),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStart(intent)
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.launch_failed, Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, R.string.launch_failed, Toast.LENGTH_SHORT).show()
        }
    }
}
