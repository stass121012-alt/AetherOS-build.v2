package com.aether.os.design

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import com.aether.os.data.WallpaperKind

/** Готовый градиентный пресет обоев (тёмный вариант; светлый получается осветлением). */
class WallpaperPreset(
    val name: String,
    val top: Color,
    val bottom: Color,
    val glow: Color,
)

val AetherWallpaperPresets = listOf(
    WallpaperPreset("Аврора", Color(0xFF0B2A2F), Color(0xFF1B4B5A), Color(0xFF3EE0B0)),
    WallpaperPreset("Океан", Color(0xFF08203F), Color(0xFF0E4D7A), Color(0xFF38BDF8)),
    WallpaperPreset("Закат", Color(0xFF2B1241), Color(0xFF7A2E55), Color(0xFFFF8A5B)),
    WallpaperPreset("Графит", Color(0xFF0E1013), Color(0xFF23272E), Color(0xFF8A94A6)),
)

/** Обои рабочего стола: динамические (Ambient), пресет или своё фото. */
@Composable
fun AetherWallpaper(
    kind: WallpaperKind,
    presetIndex: Int,
    image: ImageBitmap?,
    modifier: Modifier = Modifier,
) {
    val dark = LocalAetherPalette.current.isDark
    when {
        kind == WallpaperKind.IMAGE && image != null -> {
            Box(modifier.fillMaxSize()) {
                Image(
                    bitmap = image,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
                // Затемнение/осветление для читаемости часов и подписей.
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(if (dark) Color.Black.copy(alpha = 0.30f) else Color.White.copy(alpha = 0.22f))
                )
            }
        }
        kind == WallpaperKind.PRESET -> {
            val preset = AetherWallpaperPresets.getOrElse(presetIndex) { AetherWallpaperPresets.first() }
            if (dark) {
                GradientBackdrop(preset.top, preset.bottom, preset.glow, modifier)
            } else {
                GradientBackdrop(
                    lerp(preset.top, Color.White, 0.7f),
                    lerp(preset.bottom, Color.White, 0.7f),
                    preset.glow,
                    modifier,
                )
            }
        }
        else -> AmbientBackground(modifier)
    }
}
