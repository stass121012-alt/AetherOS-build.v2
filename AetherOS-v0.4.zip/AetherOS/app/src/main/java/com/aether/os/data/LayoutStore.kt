package com.aether.os.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.layoutDataStore by preferencesDataStore(name = "aether_layout")

/**
 * Сохранённая раскладка рабочего стола.
 * dock == null — пользователь ещё не менял док, используется системный набор по умолчанию.
 */
data class LayoutPrefs(
    val dock: List<String>?,
    val hidden: Set<String>,
    val order: List<String>,
)

class LayoutStore(private val context: Context) {

    private val kDock = stringPreferencesKey("dock")
    private val kHidden = stringSetPreferencesKey("hidden")
    private val kOrder = stringPreferencesKey("order")

    val prefs: Flow<LayoutPrefs> = context.layoutDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            LayoutPrefs(
                dock = p[kDock]?.let(::decode),
                hidden = p[kHidden] ?: emptySet(),
                order = p[kOrder]?.let(::decode) ?: emptyList(),
            )
        }

    suspend fun setDock(list: List<String>?) {
        context.layoutDataStore.edit { p ->
            if (list == null) p.remove(kDock) else p[kDock] = encode(list)
        }
    }

    suspend fun setHidden(set: Set<String>) {
        context.layoutDataStore.edit { p -> p[kHidden] = set }
    }

    suspend fun setOrder(list: List<String>) {
        context.layoutDataStore.edit { p -> p[kOrder] = encode(list) }
    }

    private fun encode(list: List<String>) = list.joinToString("\n")
    private fun decode(s: String) = s.split("\n").filter { it.isNotBlank() }
}
