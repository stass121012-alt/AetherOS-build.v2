package com.aether.os.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.os.data.WidgetType
import com.aether.os.data.describeWeatherCode
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private const val MAX_VISIBLE_NOTES = 8

/** Заметки: локальный список, сохраняется в DataStore, добавление и удаление на месте. */
@Composable
internal fun NotesWidget(notes: List<String>, actions: HomeActions) {
    val p = LocalAetherPalette.current
    var text by rememberSaveable { mutableStateOf("") }
    val submit = {
        if (text.isNotBlank()) {
            actions.onAddNote(text)
            text = ""
        }
    }

    WidgetCard("Заметки", { actions.onRemoveWidget(WidgetType.NOTES) }) {
        if (notes.isEmpty()) {
            Text("Пока пусто.", style = AetherType.caption, color = p.textSecondary)
        }
        notes.take(MAX_VISIBLE_NOTES).forEachIndexed { index, note ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    note,
                    style = AetherType.body,
                    color = p.textPrimary,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "×",
                    style = AetherType.title,
                    color = p.textSecondary,
                    modifier = Modifier
                        .clickable { actions.onDeleteNote(index) }
                        .padding(horizontal = 12.dp),
                )
            }
        }
        if (notes.size > MAX_VISIBLE_NOTES) {
            Text(
                "и ещё ${notes.size - MAX_VISIBLE_NOTES}",
                style = AetherType.caption,
                color = p.textSecondary,
            )
        }
        Spacer(Modifier.height(8.dp))
        InputRow(
            value = text,
            onValueChange = { text = it.take(120) },
            placeholder = "Новая заметка",
            action = "Добавить",
            onSubmit = submit,
        )
    }
}

/** Погода Open-Meteo. Нужен интернет; город вводится вручную, геолокация не используется. */
@Composable
internal fun WeatherWidget(state: WidgetsState, actions: HomeActions) {
    val p = LocalAetherPalette.current
    val weather = state.weather
    var cityInput by rememberSaveable { mutableStateOf("") }
    var editing by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(weather?.city) {
        editing = false
        if (weather != null) actions.onRefreshWeather(false)
    }

    WidgetCard("Погода", { actions.onRemoveWidget(WidgetType.WEATHER) }) {
        if (weather == null || editing) {
            InputRow(
                value = cityInput,
                onValueChange = { cityInput = it.take(60) },
                placeholder = "Город",
                action = "Найти",
                onSubmit = { actions.onSetWeatherCity(cityInput) },
            )
            WeatherStatusLine(state.weatherStatus, hasData = false)
            Text(
                "Данные Open-Meteo. Интернет используется только когда вы смотрите этот виджет или нажимаете «Найти» и «Обновить».",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(top = 8.dp),
            )
        } else {
            val temp = weather.tempC
            Text(weather.city, style = AetherType.body, color = p.textPrimary)
            if (temp != null) {
                Text(
                    "${temp.roundToInt()}°",
                    style = AetherType.clock.copy(fontSize = 56.sp),
                    color = p.textPrimary,
                )
                Text(
                    describeWeatherCode(weather.code ?: -1) +
                        (weather.windKmh?.let { " · ветер ${it.roundToInt()} км/ч" } ?: ""),
                    style = AetherType.caption,
                    color = p.textSecondary,
                )
                if (weather.updatedAt > 0L) {
                    val time = Instant.ofEpochMilli(weather.updatedAt)
                        .atZone(ZoneId.systemDefault())
                        .format(DateTimeFormatter.ofPattern("HH:mm"))
                    Text("Обновлено в $time", style = AetherType.caption, color = p.textSecondary)
                }
            }
            WeatherStatusLine(state.weatherStatus, hasData = temp != null)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Обновить") { actions.onRefreshWeather(true) }
                Chip("Сменить город") { editing = true }
            }
        }
    }
}

@Composable
private fun WeatherStatusLine(status: WeatherStatus, hasData: Boolean) {
    val p = LocalAetherPalette.current
    val message = when (status) {
        WeatherStatus.IDLE -> null
        WeatherStatus.LOADING -> "Загрузка…"
        WeatherStatus.OFFLINE ->
            if (hasData) "Нет сети — показаны последние данные." else "Нет сети или сервис недоступен."
        WeatherStatus.NOT_FOUND -> "Город не найден."
    }
    if (message != null) {
        Text(
            message,
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun InputRow(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    action: String,
    onSubmit: () -> Unit,
) {
    val p = LocalAetherPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(16.dp))
            .padding(start = 14.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = AetherType.body.copy(color = p.textPrimary),
            cursorBrush = SolidColor(p.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onSubmit() }),
            modifier = Modifier.weight(1f).padding(vertical = 12.dp),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) {
                        Text(placeholder, style = AetherType.body, color = p.textSecondary)
                    }
                    inner()
                }
            },
        )
        TextButton(onClick = onSubmit) { Text(action, color = p.accent) }
    }
}
