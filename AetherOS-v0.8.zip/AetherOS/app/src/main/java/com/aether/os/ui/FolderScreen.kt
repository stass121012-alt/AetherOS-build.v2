package com.aether.os.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aether.os.data.AppInfo
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.design.pressScale

private const val FOLDER_COLUMNS = 4

/** Иконка папки на рабочем столе: стеклянный квадрат с миниатюрами до четырёх приложений. */
@Composable
internal fun FolderIcon(apps: List<AppInfo>, size: Dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(size * 0.24f)
    val inner = size * 0.76f
    val mini = inner / 2 - 2.dp
    Box(modifier.size(size).aetherGlass(shape).padding(size * 0.12f)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            for (r in 0..1) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (c in 0..1) {
                        val app = apps.getOrNull(r * 2 + c)
                        if (app != null) {
                            Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(mini))
                        } else {
                            Spacer(Modifier.size(mini))
                        }
                    }
                }
            }
        }
    }
}

/** Открытая папка: переименование, запуск приложений, меню «Убрать из папки», расформирование. */
@Composable
fun FolderScreen(folder: GridItem.Folder, actions: HomeActions, onClose: () -> Unit) {
    val p = LocalAetherPalette.current
    val focusManager = LocalFocusManager.current
    var name by remember(folder.id) { mutableStateOf(folder.name) }
    val latestName by rememberUpdatedState(name)
    val scrimSource = remember { MutableInteractionSource() }
    val cardSource = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(AetherDimens.radiusCard + 4.dp)

    // Название сохраняется при закрытии папки.
    DisposableEffect(folder.id) {
        onDispose { actions.onRenameFolder(folder.id, latestName) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .imePadding()
            .clickable(interactionSource = scrimSource, indication = null, onClick = onClose),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .clip(shape)
                .background(p.panel)
                .border(1.dp, Brush.verticalGradient(listOf(p.glassEdgeLight, p.glassEdgeDim)), shape)
                .clickable(interactionSource = cardSource, indication = null) { }
                .padding(horizontal = 16.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            BasicTextField(
                value = name,
                onValueChange = { name = it.take(24).replace('\n', ' ') },
                singleLine = true,
                textStyle = AetherType.title.copy(color = p.textPrimary, textAlign = TextAlign.Center),
                cursorBrush = SolidColor(p.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Нажмите на название, чтобы переименовать",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(top = 2.dp, bottom = 16.dp),
            )

            folder.apps.chunked(FOLDER_COLUMNS).forEach { rowApps ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    rowApps.forEach { app ->
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            FolderMember(app, folder.id, actions)
                        }
                    }
                    repeat(FOLDER_COLUMNS - rowApps.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { actions.onDissolveFolder(folder.id) }) {
                Text("Расформировать папку", color = p.accent)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderMember(app: AppInfo, folderId: String, actions: HomeActions) {
    val p = LocalAetherPalette.current
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    var expanded by remember { mutableStateOf(false) }

    Box {
        Column(
            Modifier
                .pressScale(interaction)
                .combinedClickable(
                    interactionSource = interaction,
                    indication = null,
                    onClick = { actions.onLaunch(app) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        expanded = true
                    },
                )
                .padding(2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(52.dp))
            Text(
                app.label,
                style = AetherType.appLabel,
                color = p.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        AppMenu(
            expanded = expanded,
            onDismiss = { expanded = false },
            app = app,
            actions = actions,
            menu = CellMenu(inDock = false, dockFull = true, folderId = folderId),
        )
    }
}
