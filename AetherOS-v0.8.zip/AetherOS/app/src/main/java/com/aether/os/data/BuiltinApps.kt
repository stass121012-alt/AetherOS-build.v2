package com.aether.os.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Встроенные приложения AETHER. Они живут внутри оболочки (не отдельные APK),
 * но участвуют в сетке, доке, папках и поиске как обычные приложения.
 */
object BuiltinApps {
    const val PREFIX = "aether.builtin."
    const val NOTES = PREFIX + "notes"
    const val CALCULATOR = PREFIX + "calculator"

    fun isBuiltin(packageName: String) = packageName.startsWith(PREFIX)

    @Suppress("UNUSED_PARAMETER")
    fun create(context: Context): List<AppInfo> = listOf(
        AppInfo("Заметки", NOTES, "notes", notesIcon()),
        AppInfo("Калькулятор", CALCULATOR, "calculator", calculatorIcon()),
    )

    private const val SIZE = 144

    private fun newCanvas(top: Int, bottom: Int): Pair<Bitmap, Canvas> {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, SIZE.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(RectF(0f, 0f, SIZE.toFloat(), SIZE.toFloat()), SIZE * 0.22f, SIZE * 0.22f, paint)
        return bmp to canvas
    }

    private fun notesIcon(): ImageBitmap {
        val (bmp, canvas) = newCanvas(0xFFFFC857.toInt(), 0xFFFF8F3D.toInt())
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6FFFFFF.toInt() }
        for (i in 0..2) {
            val top = 40f + i * 28f
            val right = if (i == 2) 84f else 114f
            canvas.drawRoundRect(RectF(30f, top, right, top + 11f), 5.5f, 5.5f, line)
        }
        return bmp.asImageBitmap()
    }

    private fun calculatorIcon(): ImageBitmap {
        val (bmp, canvas) = newCanvas(0xFF3A3F4B.toInt(), 0xFF14161C.toInt())
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 52f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }
        canvas.drawText("+", 46f, 66f, paint)
        canvas.drawText("−", 98f, 66f, paint)
        canvas.drawText("×", 46f, 116f, paint)
        paint.color = 0xFFFF9F43.toInt()
        canvas.drawText("=", 98f, 116f, paint)
        return bmp.asImageBitmap()
    }
}
