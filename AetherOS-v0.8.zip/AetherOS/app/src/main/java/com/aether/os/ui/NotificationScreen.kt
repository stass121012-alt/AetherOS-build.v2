package com.aether.os.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass
import com.aether.os.system.NotifItem
import com.aether.os.system.NotificationHub
import com.aether.os.system.SystemTarget
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Центр уведомлений AETHER. Работает только после явного согласия пользователя
 * (доступ к уведомлениям в системных настройках). Уведомления — только в памяти.
 */
@Composable
fun NotificationScreen(hasAccess: Boolean, actions: HomeActions, onClose: () -> Unit) {
    val p = LocalAetherPalette.current
    val notifications by NotificationHub.items.collectAsStateWithLifecycle()
    val groups = remember(notifications) {
        notifications.groupBy { it.pkg }.values.sortedByDescending { g -> g.maxOf { it.postTime } }
    }
    val backdropSource = remember { MutableInteractionSource() }
    val cardSource = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.35f))
            .clickable(interactionSource = backdropSource, indication = null, onClick = onClose)
    ) {
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clip(shape)
                .background(p.panel)
                .border(1.dp, Brush.verticalGradient(listOf(p.glassEdgeLight, p.glassEdgeDim)), shape)
                .clickable(interactionSource = cardSource, indication = null) { }
                .statusBarsPadding()
                .padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 12.dp)
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Уведомления", style = AetherType.title, color = p.textPrimary)
                if (hasAccess && notifications.isNotEmpty()) {
                    Chip("Очистить все") { NotificationHub.clearAll() }
                }
            }
            Spacer(Modifier.height(8.dp))

            when {
                !hasAccess -> ConsentBlock(actions)
                notifications.isEmpty() -> Text(
                    "Нет уведомлений.",
                    style = AetherType.caption,
                    color = p.textSecondary,
                )
                else -> LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    groups.forEach { group ->
                        val pkg = group.first().pkg
                        item(key = "group:$pkg") {
                            GroupHeader(group.first().appLabel, group.size) {
                                NotificationHub.dismissGroup(pkg)
                            }
                        }
                        items(group, key = { it.key }) { n ->
                            NotificationRow(
                                item = n,
                                onDismiss = { NotificationHub.dismiss(n.key) },
                                onOpen = {
                                    if (NotificationHub.open(n)) onClose()
                                },
                            )
                        }
                    }
                }
            }

            if (hasAccess) {
                TextButton(onClick = { actions.onOpenSystem(SystemTarget.NOTIFICATION_ACCESS) }) {
                    Text("Отозвать доступ в настройках", color = p.accent)
                }
            }
        }
    }
}

@Composable
private fun ConsentBlock(actions: HomeActions) {
    val p = LocalAetherPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            "Центр уведомлений показывает уведомления других приложений. " +
                "Для этого Android требует вашего отдельного согласия.",
            style = AetherType.body,
            color = p.textPrimary,
        )
        Text(
            "• Уведомления хранятся только в памяти и исчезают при отзыве доступа.\n" +
                "• Они не сохраняются на диск и не передаются по сети.\n" +
                "• Вы можете отозвать доступ в любой момент.",
            style = AetherType.caption,
            color = p.textSecondary,
        )
        Chip("Выдать доступ") { actions.onOpenSystem(SystemTarget.NOTIFICATION_ACCESS) }
        Text(
            "Если переключатель неактивен (Android 13+, приложение установлено из APK): " +
                "Настройки → Приложения → AETHER OS → меню ⋮ → «Разрешить ограниченные настройки».",
            style = AetherType.caption,
            color = p.textSecondary,
        )
    }
}

@Composable
private fun GroupHeader(label: String, count: Int, onClear: () -> Unit) {
    val p = LocalAetherPalette.current
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "${label.uppercase(Locale.getDefault())} · $count",
            style = AetherType.section,
            color = p.accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Text(
            "Очистить",
            style = AetherType.caption,
            color = p.textSecondary,
            modifier = Modifier.clickable(onClick = onClear).padding(4.dp),
        )
    }
}

private val TimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

@Composable
private fun NotificationRow(item: NotifItem, onDismiss: () -> Unit, onOpen: () -> Unit) {
    val p = LocalAetherPalette.current
    var dx by remember(item.key) { mutableFloatStateOf(0f) }
    val time = remember(item.postTime) {
        Instant.ofEpochMilli(item.postTime).atZone(ZoneId.systemDefault()).format(TimeFormatter)
    }

    Row(
        Modifier
            .fillMaxWidth()
            .offset { IntOffset(dx.roundToInt(), 0) }
            .graphicsLayer { alpha = (1f - abs(dx) / 700f).coerceIn(0.2f, 1f) }
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .pointerInput(item.key) {
                val threshold = size.width * 0.35f
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (abs(dx) > threshold && item.clearable) onDismiss() else dx = 0f
                    },
                    onDragCancel = { dx = 0f },
                ) { change, amount ->
                    change.consume()
                    dx += amount
                }
            }
            .clickable(onClick = onOpen)
            .padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                item.title.ifBlank { item.appLabel },
                style = AetherType.body,
                color = p.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (item.text.isNotBlank()) {
                Text(
                    item.text,
                    style = AetherType.caption,
                    color = p.textSecondary,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(time, style = AetherType.caption, color = p.textSecondary.copy(alpha = 0.7f))
        }
        if (item.clearable) {
            Text(
                "×",
                style = AetherType.title,
                color = p.textSecondary,
                modifier = Modifier.clickable(onClick = onDismiss).padding(horizontal = 12.dp, vertical = 4.dp),
            )
        }
    }
}
