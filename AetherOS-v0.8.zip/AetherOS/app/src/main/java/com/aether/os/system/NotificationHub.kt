package com.aether.os.system

import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Одно уведомление. Хранится только в памяти и не передаётся нигде за пределы приложения. */
data class NotifItem(
    val key: String,
    val pkg: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val postTime: Long,
    val clearable: Boolean,
    val intent: PendingIntent?,
)

/**
 * Память центра уведомлений. Данные поступают из [AetherNotificationListener]
 * только после того, как пользователь сам выдал доступ в системных настройках.
 * При отключении сервиса (в том числе при отзыве доступа) список очищается.
 */
object NotificationHub {

    private val _items = MutableStateFlow<List<NotifItem>>(emptyList())
    val items: StateFlow<List<NotifItem>> = _items.asStateFlow()

    private var service: NotificationListenerService? = null

    fun attach(s: NotificationListenerService) {
        service = s
    }

    fun detach(s: NotificationListenerService) {
        if (service === s) service = null
        _items.value = emptyList()
    }

    fun replaceAll(list: List<NotifItem>) {
        _items.value = list.sortedByDescending { it.postTime }
    }

    fun upsert(item: NotifItem) {
        _items.update { list ->
            (list.filter { it.key != item.key } + item).sortedByDescending { it.postTime }
        }
    }

    fun remove(key: String) {
        _items.update { list -> list.filter { it.key != key } }
    }

    fun dismiss(key: String) {
        service?.cancelNotification(key)
        remove(key)
    }

    fun dismissGroup(pkg: String) {
        val keys = _items.value.filter { it.pkg == pkg && it.clearable }.map { it.key }
        if (keys.isEmpty()) return
        service?.cancelNotifications(keys.toTypedArray())
        _items.update { list -> list.filter { it.key !in keys } }
    }

    fun clearAll() {
        service?.cancelAllNotifications()
        _items.update { list -> list.filter { !it.clearable } }
    }

    /** Открывает приложение уведомления. Возвращает false, если действие уже недоступно. */
    fun open(item: NotifItem): Boolean {
        val pi = item.intent ?: return false
        return try {
            pi.send()
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }
}
