package com.aether.os.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.aetherGlass

private val HelpItems = listOf(
    "Нажатие на иконку" to "Открывает приложение или папку.",
    "Долгое нажатие, отпустить" to "Меню: добавить в док, сдвинуть, скрыть, «О приложении». У папки: открыть, сдвинуть, расформировать.",
    "Долгое нажатие и перетаскивание" to "Переставляет иконку в пределах страницы. Отпустите на крае ячейки — иконка встанет на это место.",
    "Перетащить в центр другой иконки" to "Создаёт папку из двух приложений. Если отпустить в центре папки — приложение добавится в неё.",
    "Свайп влево или вправо" to "Переключает страницы рабочего стола.",
    "Между страницами" to "Перетаскивание работает внутри одной страницы. Чтобы перенести иконку на другую страницу, используйте «Сдвинуть влево/вправо» в меню.",
    "Свайп вниз по часам или кнопка «Поиск»" to "Открывает AETHER Search: приложения (в том числе скрытые и в папках) и настройки оболочки.",
    "Свайп вниз под строкой состояния справа (или нажатие на правую полоску)" to "Открывает Control Center: фонарик, громкость, яркость, Wi‑Fi, Bluetooth, авиарежим, «Не беспокоить», будильник. Самый верхний край экрана обрабатывает Android — там открывается шторка уведомлений.",
    "Закрыть Control Center" to "Свайп вверх по панели, нажатие вне панели или кнопка «Назад».",
    "Страница виджетов" to "Свайп вправо от первой страницы приложений. Там часы с таймером, календарь, заметки и погода. «Убрать» скрывает виджет, ниже можно добавить его снова.",
    "Таймер и остров" to "В виджете «Часы» нажмите 1, 5, 10 или 25 мин. Вверху появится остров: нажмите, чтобы раскрыть; «Отмена» останавливает таймер. Звук и вибрация сработают, пока AETHER запущен.",
    "Уведомления (левая часть полоски вверху)" to "Свайп вниз от левой полоски под строкой состояния или нажатие на неё. Нужно ваше согласие: кнопка «Выдать доступ» ведёт в системные настройки. Свайп по уведомлению вбок или «×» — убрать, нажатие — открыть, «Очистить» — группа, «Очистить все» — всё.",
    "Заметки и Калькулятор" to "Встроенные приложения AETHER лежат в сетке как обычные: нажмите на иконку. В «Заметках» первая строка — заголовок, «Готово» сохраняет, пустая заметка удаляется.",
    "Долгое нажатие на часы" to "Открывает настройки AETHER.",
    "Внутри папки" to "Нажмите на название, чтобы переименовать. Долгое нажатие на иконку — «Убрать из папки». Папка из одного приложения расформировывается сама.",
    "Кнопка «Назад»" to "Закрывает папку, поиск или окно настроек. На самом рабочем столе ничего не делает.",
    "Док" to "До 4 приложений. Добавить: долгое нажатие на иконку → «Добавить в док». Убрать: долгое нажатие на иконку в доке.",
)

@Composable
fun HelpScreen(onBack: () -> Unit) {
    SheetScaffold(
        title = "Управление",
        subtitle = "Жесты и действия AETHER OS",
        onClose = onBack,
    ) {
        item { SectionTitle("ЖЕСТЫ") }
        HelpItems.forEach { (title, text) ->
            item(key = title) { HelpRow(title, text) }
        }
        item { ActionRow("Назад", null, onBack) }
    }
}

@Composable
private fun HelpRow(title: String, text: String) {
    val p = LocalAetherPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusSmall))
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(title, style = AetherType.body, color = p.textPrimary)
        Text(text, style = AetherType.caption, color = p.textSecondary, modifier = Modifier.padding(top = 2.dp))
    }
}
