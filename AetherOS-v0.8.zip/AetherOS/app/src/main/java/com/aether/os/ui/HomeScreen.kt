package com.aether.os.ui

import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aether.os.data.AppInfo
import com.aether.os.data.BuiltinApps
import com.aether.os.data.Note
import com.aether.os.data.AppSettings
import com.aether.os.data.ThemeMode
import com.aether.os.data.WallpaperKind
import com.aether.os.data.WidgetType
import com.aether.os.design.AetherDimens
import com.aether.os.design.AetherType
import com.aether.os.design.AetherWallpaper
import com.aether.os.design.LocalAetherPalette
import com.aether.os.design.LocalReduceMotion
import com.aether.os.design.aetherGlass
import com.aether.os.design.aetherSpring
import com.aether.os.design.pressScale
import com.aether.os.design.rememberNow
import com.aether.os.system.NotificationHub
import com.aether.os.system.SystemControls
import com.aether.os.system.SystemTarget
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

/** Все действия, которые UI может запросить у оболочки. */
@Immutable
data class HomeActions(
    val onLaunch: (AppInfo) -> Unit,
    val onToggleDock: (String) -> Unit,
    val onHide: (String) -> Unit,
    val onUnhide: (String) -> Unit,
    val onUnhideAll: () -> Unit,
    val onResetDock: () -> Unit,
    val onMove: (String, Int) -> Unit,
    val onAppInfo: (String) -> Unit,
    val onThemeMode: (ThemeMode) -> Unit,
    val onReduceMotion: (Boolean) -> Unit,
    val onIconSize: (Int) -> Unit,
    val onColumns: (Int) -> Unit,
    val onRows: (Int) -> Unit,
    val onShowLabels: (Boolean) -> Unit,
    val onWallpaper: (WallpaperKind, Int) -> Unit,
    val onPickWallpaper: () -> Unit,
    val onRemoveWallpaperImage: () -> Unit,
    val onResetPersonalization: () -> Unit,
    val onReorder: (String, Int) -> Unit,
    val onCreateFolder: (String, String) -> Unit,
    val onAddToFolder: (String, String) -> Unit,
    val onRemoveFromFolder: (String, String) -> Unit,
    val onRenameFolder: (String, String) -> Unit,
    val onDissolveFolder: (String) -> Unit,
    val onOpenSystem: (SystemTarget) -> Unit,
    val onSetBrightness: (Float) -> Unit,
    val onResetBrightness: () -> Unit,
    val onAddWidget: (WidgetType) -> Unit,
    val onRemoveWidget: (WidgetType) -> Unit,
    val onAddNote: (String) -> Unit,
    val onDeleteNote: (Int) -> Unit,
    val onSetWeatherCity: (String) -> Unit,
    val onRefreshWeather: (Boolean) -> Unit,
    val onStartTimer: (Int) -> Unit,
    val onCancelTimer: () -> Unit,
    val onOpenCalendarDay: (Long) -> Unit,
    val onSaveAppNote: (Long?, String) -> Unit,
    val onDeleteAppNote: (Long) -> Unit,
)

private enum class Panel { NONE, SETTINGS, PERSONALIZATION, SEARCH, HELP, CONTROL, NOTIFICATIONS, NOTES_APP, CALCULATOR }

private const val MAX_DOCK_ICON_DP = 64
private const val SWIPE_DOWN_THRESHOLD_PX = 90f

@Composable
fun HomeScreen(
    state: HomeState,
    settings: AppSettings,
    wallpaperImage: ImageBitmap?,
    controls: SystemControls,
    brightness: Float?,
    widgets: WidgetsState,
    appNotes: List<Note>,
    notificationAccess: Boolean,
    baseActions: HomeActions,
) {
    var panel by rememberSaveable { mutableStateOf(Panel.NONE) }
    var openFolderId by rememberSaveable { mutableStateOf<String?>(null) }
    // Встроенные приложения AETHER открываются внутри оболочки, остальные — через систему.
    val actions = remember(baseActions) {
        baseActions.copy(
            onLaunch = { app ->
                if (app.packageName == BuiltinApps.NOTES) {
                    panel = Panel.NOTES_APP
                } else if (app.packageName == BuiltinApps.CALCULATOR) {
                    panel = Panel.CALCULATOR
                } else {
                    baseActions.onLaunch(app)
                }
            }
        )
    }
    val notifications by NotificationHub.items.collectAsStateWithLifecycle()
    val reduce = LocalReduceMotion.current

    val openFolder = state.items
        .filterIsInstance<GridItem.Folder>()
        .firstOrNull { it.id == openFolderId }
    // Если папка исчезла (расформирована), закрываем её окно.
    LaunchedEffect(openFolder, state.loading) {
        if (openFolderId != null && openFolder == null && !state.loading) openFolderId = null
    }

    BackHandler(enabled = panel != Panel.NONE) {
        panel = when (panel) {
            Panel.PERSONALIZATION, Panel.HELP -> Panel.SETTINGS
            else -> Panel.NONE
        }
    }
    // Объявлен позже — имеет приоритет над обработчиком панелей.
    BackHandler(enabled = openFolder != null) { openFolderId = null }

    val panelEnter = if (reduce) fadeIn(tween(120)) else fadeIn() + slideInVertically { it / 8 }
    val panelExit = if (reduce) fadeOut(tween(120)) else fadeOut() + slideOutVertically { it / 8 }

    Box(Modifier.fillMaxSize()) {
        AetherWallpaper(
            kind = settings.wallpaperKind,
            presetIndex = settings.wallpaperPreset,
            image = wallpaperImage,
        )
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = AetherDimens.screenPadding)
        ) {
            ClockBlock(
                modifier = Modifier.fillMaxWidth().padding(top = 44.dp, bottom = 8.dp),
                onLongPress = { panel = Panel.SETTINGS },
                onSwipeDown = { panel = Panel.SEARCH },
            )
            SearchPill(
                onClick = { panel = Panel.SEARCH },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            )
            AppPager(
                items = state.items,
                settings = settings,
                dockFull = state.dock.size >= AetherDimens.dockSize,
                widgets = widgets,
                actions = actions,
                onOpenFolder = { openFolderId = it },
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )
            Dock(
                dock = state.dock,
                iconSize = minOf(settings.iconSizeDp, MAX_DOCK_ICON_DP).dp,
                actions = actions,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp),
            )
        }

        TopHandles(
            count = if (notificationAccess) notifications.size else 0,
            onOpenNotifications = { panel = Panel.NOTIFICATIONS },
            onOpenControl = { panel = Panel.CONTROL },
        )
        DynamicIsland(timer = widgets.timer, onCancel = actions.onCancelTimer)

        AnimatedVisibility(
            visible = openFolder != null,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + scaleIn(initialScale = 0.85f),
            exit = fadeOut(),
        ) {
            if (openFolder != null) {
                FolderScreen(folder = openFolder, actions = actions, onClose = { openFolderId = null })
            }
        }
        AnimatedVisibility(visible = panel == Panel.SEARCH, enter = fadeIn(), exit = fadeOut()) {
            SearchScreen(
                all = state.all,
                hiddenPackages = state.hidden.map { it.packageName }.toSet(),
                onLaunch = { app ->
                    panel = Panel.NONE
                    actions.onLaunch(app)
                },
                onOpenSettings = { panel = Panel.SETTINGS },
                onOpenControl = { panel = Panel.CONTROL },
                onOpenNotifications = { panel = Panel.NOTIFICATIONS },
                onOpenPersonalization = { panel = Panel.PERSONALIZATION },
                onClose = { panel = Panel.NONE },
            )
        }
        AnimatedVisibility(visible = panel == Panel.SETTINGS, enter = panelEnter, exit = panelExit) {
            SettingsScreen(
                settings = settings,
                hidden = state.hidden,
                actions = actions,
                onOpenPersonalization = { panel = Panel.PERSONALIZATION },
                onOpenHelp = { panel = Panel.HELP },
                onClose = { panel = Panel.NONE },
            )
        }
        AnimatedVisibility(visible = panel == Panel.PERSONALIZATION, enter = panelEnter, exit = panelExit) {
            PersonalizationScreen(
                settings = settings,
                wallpaperImage = wallpaperImage,
                actions = actions,
                onBack = { panel = Panel.SETTINGS },
            )
        }
        AnimatedVisibility(visible = panel == Panel.HELP, enter = panelEnter, exit = panelExit) {
            HelpScreen(onBack = { panel = Panel.SETTINGS })
        }
        AnimatedVisibility(
            visible = panel == Panel.CONTROL,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + slideInVertically { -it / 2 },
            exit = if (reduce) fadeOut(tween(120)) else fadeOut() + slideOutVertically { -it / 2 },
        ) {
            ControlCenterScreen(
                controls = controls,
                brightness = brightness,
                actions = actions,
                onClose = { panel = Panel.NONE },
            )
        }
        AnimatedVisibility(
            visible = panel == Panel.NOTIFICATIONS,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + slideInVertically { -it / 2 },
            exit = if (reduce) fadeOut(tween(120)) else fadeOut() + slideOutVertically { -it / 2 },
        ) {
            NotificationScreen(
                hasAccess = notificationAccess,
                actions = actions,
                onClose = { panel = Panel.NONE },
            )
        }
        AnimatedVisibility(
            visible = panel == Panel.NOTES_APP,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + scaleIn(initialScale = 0.92f),
            exit = fadeOut(),
        ) {
            NotesApp(notes = appNotes, actions = actions, onClose = { panel = Panel.NONE })
        }
        AnimatedVisibility(
            visible = panel == Panel.CALCULATOR,
            enter = if (reduce) fadeIn(tween(120)) else fadeIn() + scaleIn(initialScale = 0.92f),
            exit = fadeOut(),
        ) {
            CalculatorApp(onClose = { panel = Panel.NONE })
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ClockBlock(
    modifier: Modifier = Modifier,
    onLongPress: () -> Unit,
    onSwipeDown: () -> Unit,
) {
    val p = LocalAetherPalette.current
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val now by rememberNow()
    val is24 = DateFormat.is24HourFormat(context)
    val timeFormatter = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm") }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault()) }
    val softShadow = Shadow(Color.Black.copy(alpha = 0.22f), blurRadius = 24f)
    val source = remember { MutableInteractionSource() }
    val swipe by rememberUpdatedState(onSwipeDown)

    Column(
        modifier = modifier
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = { if (total > SWIPE_DOWN_THRESHOLD_PX) swipe() },
                )
            }
            .combinedClickable(
                interactionSource = source,
                indication = null,
                onClick = { },
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongPress()
                },
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = now.format(timeFormatter),
            style = AetherType.clock.copy(shadow = softShadow),
            color = p.textPrimary,
        )
        Text(
            text = now.format(dateFormatter).replaceFirstChar { it.titlecase(Locale.getDefault()) },
            style = AetherType.date,
            color = p.textSecondary,
        )
    }
}

@Composable
private fun SearchPill(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalAetherPalette.current
    Row(
        modifier
            .aetherGlass(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Поиск", style = AetherType.body, color = p.textSecondary)
    }
}

@Composable
private fun AppPager(
    items: List<GridItem>,
    settings: AppSettings,
    dockFull: Boolean,
    widgets: WidgetsState,
    actions: HomeActions,
    onOpenFolder: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val perPage = settings.columns * settings.rows
    val pages = remember(items, perPage) { items.chunked(perPage) }
    val appPageCount = maxOf(1, pages.size)
    // Страница 0 — виджеты; приложения начинаются со страницы 1, она и показывается при старте.
    val pagerState = rememberPagerState(initialPage = 1, pageCount = { 1 + appPageCount })

    Column(modifier) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) { index ->
            if (index == 0) {
                WidgetsPage(state = widgets, actions = actions)
            } else {
                AppGridPage(
                    items = pages.getOrElse(index - 1) { emptyList() },
                    startIndex = (index - 1) * perPage,
                    total = items.size,
                    settings = settings,
                    dockFull = dockFull,
                    actions = actions,
                    onOpenFolder = onOpenFolder,
                )
            }
        }
        PageIndicator(count = 1 + appPageCount, current = pagerState.currentPage)
    }
}

private data class DragInfo(val key: String, val start: Offset, val pointer: Offset)

private data class DropTarget(val localIndex: Int, val center: Boolean)

private fun dropTarget(p: Offset, cellW: Float, cellH: Float, columns: Int, rows: Int): DropTarget? {
    if (cellW <= 0f || cellH <= 0f) return null
    val col = (p.x / cellW).toInt().coerceIn(0, columns - 1)
    val row = (p.y / cellH).toInt().coerceIn(0, rows - 1)
    val fx = (p.x - col * cellW) / cellW
    val fy = (p.y - row * cellH) / cellH
    return DropTarget(row * columns + col, fx in 0.25f..0.75f && fy in 0.25f..0.75f)
}

/**
 * Страница сетки с перетаскиванием.
 * Долгое нажатие + движение — перенос; отпустить без движения — меню.
 * Центр чужой ячейки — создание папки или добавление в папку; край — перестановка.
 */
@Composable
private fun AppGridPage(
    items: List<GridItem>,
    startIndex: Int,
    total: Int,
    settings: AppSettings,
    dockFull: Boolean,
    actions: HomeActions,
    onOpenFolder: (String) -> Unit,
) {
    val columns = settings.columns
    val rows = settings.rows
    val density = LocalDensity.current
    val haptics = LocalHapticFeedback.current
    val slop = LocalViewConfiguration.current.touchSlop
    var drag by remember { mutableStateOf<DragInfo?>(null) }
    var menuKey by remember { mutableStateOf<String?>(null) }
    var pressedKey by remember { mutableStateOf<String?>(null) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val cellW = widthPx / columns
        val cellH = heightPx / rows
        val cellWDp = maxWidth / columns
        val cellHDp = maxHeight / rows
        // Иконка не больше ячейки: на узких экранах и больших сетках размер уменьшается автоматически.
        val labelSpace = if (settings.showLabels) 32.dp else 10.dp
        val icon = minOf(settings.iconSizeDp.dp, cellWDp - 8.dp, cellHDp - labelSpace)
            .coerceAtLeast(28.dp)

        val cellSize by rememberUpdatedState(Offset(cellW, cellH))
        val finishDrag by rememberUpdatedState<(DragInfo) -> Unit> { d ->
            val moved = (d.pointer - d.start).getDistance() > slop
            if (!moved) {
                menuKey = d.key
            } else {
                val t = dropTarget(d.pointer, cellW, cellH, columns, rows)
                val dragged = items.firstOrNull { it.key == d.key }
                if (t != null && dragged != null) {
                    val target = items.getOrNull(t.localIndex)
                    when {
                        target == null -> actions.onReorder(d.key, startIndex + items.size - 1)
                        target.key == d.key -> Unit
                        t.center && dragged is GridItem.App && target is GridItem.App ->
                            actions.onCreateFolder(dragged.app.packageName, target.app.packageName)
                        t.center && dragged is GridItem.App && target is GridItem.Folder ->
                            actions.onAddToFolder(dragged.app.packageName, target.id)
                        else -> actions.onReorder(d.key, startIndex + t.localIndex)
                    }
                }
            }
        }

        val d = drag
        val moving = d != null && (d.pointer - d.start).getDistance() > slop
        val target = if (d != null && moving) dropTarget(d.pointer, cellW, cellH, columns, rows) else null
        val targetItem = target?.let { items.getOrNull(it.localIndex) }

        // Подсветка ячейки-цели (папка будет создана или пополнена).
        if (target != null && target.center && targetItem != null && targetItem.key != d?.key) {
            val tCol = target.localIndex % columns
            val tRow = target.localIndex / columns
            Box(
                Modifier
                    .offset { IntOffset((tCol * cellW).roundToInt(), (tRow * cellH).roundToInt()) }
                    .size(cellWDp, cellHDp)
                    .padding(4.dp)
                    .aetherGlass(RoundedCornerShape(22.dp))
            )
        }

        Column(Modifier.fillMaxSize()) {
            repeat(rows) { row ->
                Row(Modifier.fillMaxWidth().weight(1f)) {
                    repeat(columns) { col ->
                        val local = row * columns + col
                        val item = items.getOrNull(local)
                        val global = startIndex + local
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .pointerInput(item?.key) {
                                    val current = item ?: return@pointerInput
                                    detectTapGestures(
                                        onPress = {
                                            pressedKey = current.key
                                            tryAwaitRelease()
                                            pressedKey = null
                                        },
                                        onTap = {
                                            when (current) {
                                                is GridItem.App -> actions.onLaunch(current.app)
                                                is GridItem.Folder -> onOpenFolder(current.id)
                                            }
                                        },
                                    )
                                }
                                .pointerInput(item?.key, col, row) {
                                    val current = item ?: return@pointerInput
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = { offset ->
                                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                            val origin = Offset(col * cellSize.x, row * cellSize.y) + offset
                                            drag = DragInfo(current.key, origin, origin)
                                        },
                                        onDrag = { change, amount ->
                                            change.consume()
                                            drag = drag?.let { it.copy(pointer = it.pointer + amount) }
                                        },
                                        onDragEnd = {
                                            drag?.let { finishDrag(it) }
                                            drag = null
                                        },
                                        onDragCancel = { drag = null },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (item != null) {
                                val dimmed = moving && d?.key == item.key
                                Box(Modifier.graphicsLayer { alpha = if (dimmed) 0.25f else 1f }) {
                                    GridCellVisual(
                                        item = item,
                                        iconSize = icon,
                                        showLabel = settings.showLabels,
                                        pressed = pressedKey == item.key,
                                    )
                                }
                                val canLeft = global > 0
                                val canRight = global < total - 1
                                when (item) {
                                    is GridItem.App -> AppMenu(
                                        expanded = menuKey == item.key,
                                        onDismiss = { menuKey = null },
                                        app = item.app,
                                        actions = actions,
                                        menu = CellMenu(
                                            inDock = false,
                                            dockFull = dockFull,
                                            canMoveLeft = canLeft,
                                            canMoveRight = canRight,
                                        ),
                                    )
                                    is GridItem.Folder -> FolderMenu(
                                        expanded = menuKey == item.key,
                                        onDismiss = { menuKey = null },
                                        folder = item,
                                        canMoveLeft = canLeft,
                                        canMoveRight = canRight,
                                        onOpen = { onOpenFolder(item.id) },
                                        actions = actions,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // «Призрак» переносимого элемента следует за пальцем поверх сетки.
        if (d != null && moving) {
            val dragged = items.firstOrNull { it.key == d.key }
            if (dragged != null) {
                val halfPx = with(density) { icon.toPx() } / 2f
                Box(
                    Modifier
                        .offset {
                            IntOffset(
                                (d.pointer.x - halfPx).roundToInt(),
                                (d.pointer.y - halfPx).roundToInt(),
                            )
                        }
                        .size(icon)
                        .graphicsLayer {
                            scaleX = 1.15f
                            scaleY = 1.15f
                            alpha = 0.92f
                        }
                ) {
                    when (dragged) {
                        is GridItem.App -> Image(
                            bitmap = dragged.app.icon,
                            contentDescription = null,
                            modifier = Modifier.size(icon),
                        )
                        is GridItem.Folder -> FolderIcon(dragged.apps, icon)
                    }
                }
            }
        }
    }
}

@Composable
private fun GridCellVisual(item: GridItem, iconSize: Dp, showLabel: Boolean, pressed: Boolean) {
    val p = LocalAetherPalette.current
    Column(
        modifier = Modifier.pressScale(pressed).padding(horizontal = 2.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        when (item) {
            is GridItem.App -> Image(
                bitmap = item.app.icon,
                contentDescription = item.app.label,
                modifier = Modifier.size(iconSize),
            )
            is GridItem.Folder -> FolderIcon(item.apps, iconSize)
        }
        if (showLabel) {
            Text(
                text = when (item) {
                    is GridItem.App -> item.app.label
                    is GridItem.Folder -> item.name
                },
                style = AetherType.appLabel,
                color = p.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}

/** Ячейка дока: нажатие — запуск, долгое нажатие — меню. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DockCell(
    app: AppInfo,
    iconSize: Dp,
    actions: HomeActions,
) {
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    var expanded by remember { mutableStateOf(false) }

    Box {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .pressScale(interaction)
                .combinedClickable(
                    interactionSource = interaction,
                    indication = null,
                    onClick = { actions.onLaunch(app) },
                    onLongClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        expanded = true
                    },
                )
                .padding(2.dp)
                .size(iconSize),
        )
        AppMenu(
            expanded = expanded,
            onDismiss = { expanded = false },
            app = app,
            actions = actions,
            menu = CellMenu(inDock = true, dockFull = true),
        )
    }
}

@Composable
private fun PageIndicator(count: Int, current: Int) {
    val p = LocalAetherPalette.current
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(count) { i ->
            val selected = i == current
            val width by animateDpAsState(
                targetValue = if (selected) 18.dp else 6.dp,
                animationSpec = aetherSpring(dampingRatio = 0.7f),
                label = "dotW",
            )
            val color by animateColorAsState(
                targetValue = if (selected) p.textPrimary else p.textSecondary.copy(alpha = 0.4f),
                animationSpec = aetherSpring(),
                label = "dotC",
            )
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(width = width, height = 6.dp)
                    .background(color, CircleShape)
            )
        }
    }
}

@Composable
private fun Dock(
    dock: List<AppInfo>,
    iconSize: Dp,
    actions: HomeActions,
    modifier: Modifier = Modifier,
) {
    val p = LocalAetherPalette.current
    Row(
        modifier = modifier
            .aetherGlass(RoundedCornerShape(AetherDimens.radiusDock))
            .padding(horizontal = 12.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (dock.isEmpty()) {
            Text(
                "Долгое нажатие на иконку → «Добавить в док»",
                style = AetherType.caption,
                color = p.textSecondary,
                modifier = Modifier.padding(vertical = 20.dp),
            )
        }
        dock.forEach { app -> DockCell(app, iconSize, actions) }
    }
}

/**
 * Две полоски у верхнего края под строкой состояния: левая — центр уведомлений,
 * правая — Control Center. Свайп вниз или нажатие. Самый верхний край экрана
 * принадлежит системной шторке Android.
 */
@Composable
private fun BoxScope.TopHandles(
    count: Int,
    onOpenNotifications: () -> Unit,
    onOpenControl: () -> Unit,
) {
    Row(
        Modifier
            .align(Alignment.TopCenter)
            .statusBarsPadding()
            .fillMaxWidth()
            .height(36.dp)
    ) {
        HandleHalf(Modifier.weight(1f), badge = count, onOpen = onOpenNotifications)
        HandleHalf(Modifier.weight(1f), badge = 0, onOpen = onOpenControl)
    }
}

@Composable
private fun HandleHalf(modifier: Modifier, badge: Int, onOpen: () -> Unit) {
    val p = LocalAetherPalette.current
    val open by rememberUpdatedState(onOpen)
    Box(
        modifier
            .fillMaxHeight()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = { if (total > 40f) open() },
                )
            }
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onOpen,
            ),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .padding(top = 8.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .background(
                        if (badge > 0) p.accent else p.textSecondary.copy(alpha = 0.5f),
                        CircleShape,
                    )
            )
            if (badge > 0) {
                Text("$badge", style = AetherType.caption, color = p.accent)
            }
        }
    }
}
